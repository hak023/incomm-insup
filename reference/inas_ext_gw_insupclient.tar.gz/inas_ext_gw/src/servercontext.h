#ifndef _SERVER_CONTEXT__H_
#define _SERVER_CONTEXT__H_

#include "common.h"

typedef struct _t_srv_ctx t_srv_ctx;
typedef struct _t_cli_ctx t_cli_ctx;
typedef struct _t_cli_traverse_item t_cli_traverse_item;

/**
* @brief A accept callback function type
*/
typedef int (*t_srv_ctx_accept_callback)(t_srv_ctx *srv);

/**
 * @brief A structure that server context
 */
struct _t_srv_ctx {
    char name[D_NAME_SIZE];
    apr_socket_t * sock;
    apr_thread_pool_t * thd_pool;
    apr_thread_mutex_t * mymutex;
    apr_pool_t * pool;
    apr_os_thread_t mythd;
    apr_uint16_t port;
    apr_int32_t max_connection;
    t_srv_ctx_accept_callback on_accept;
    apr_uint32_t st_tot_accept_count;
    apr_int32_t clis_count;
    t_cli_traverse_item * clis;
    int rr_index;
    int re_index;
};

/**
 * in_create_srv_ctx
 * @return
 */
IN_DECLARE(t_srv_ctx *) in_create_srv_ctx(apr_pollset_t * pollset,
        const char * name, apr_uint16_t port, apr_int32_t max_connection, t_srv_ctx_accept_callback on_accept, apr_pool_t * pool);

/**
 * in_create_cli_ctx_pool
 * @return
 */
IN_DECLARE(t_srv_ctx *) in_create_cli_ctx_pool(const char * name, apr_int32_t max_connection, apr_pool_t * pool);

/**
 * in_destory_warm_srv_ctx
 * @return
 */
IN_DECLARE(void) in_destory_warm_srv_ctx(apr_pollset_t * pollset, t_srv_ctx * srv);

/**
 * in_destory_srv_ctx
 * @return
 */
IN_DECLARE(void) in_destory_srv_ctx(apr_pollset_t * pollset, t_srv_ctx * srv, bool include_warm);

/**
 * in_debug_desc_reg_clis
 * @return
 */
IN_DECLARE(void) in_debug_desc_reg_clis(t_srv_ctx * srv);

/**
 * in_reg_cli_to_srv_ctx
 * @return
 */
IN_DECLARE(int) in_reg_cli_to_srv_ctx(t_srv_ctx * srv, t_cli_ctx * cli);

/**
 * in_update_cli_reg_info_to_srv_ctx_with_client_mode
 * @return
 */
IN_DECLARE(int) in_update_cli_reg_info_to_srv_ctx_with_client_mode(t_srv_ctx * srv, t_cli_ctx * cli, apr_uint16_t sid);

/**
 * in_update_cli_reg_info_to_srv_ctx
 * @return
 */
IN_DECLARE(int) in_update_cli_reg_info_to_srv_ctx(t_srv_ctx * srv, t_cli_ctx * cli, apr_uint16_t sid);

/**
 * in_unreg_cli_to_srv_ctx
 * @return
 */
IN_DECLARE(int) in_unreg_cli_to_srv_ctx(t_srv_ctx * srv, t_cli_ctx * cli);

/**
 * in_find_and_send_cli
 * @return
 */
IN_DECLARE(int) in_find_and_send_cli(t_srv_ctx * srv, apr_uint16_t sid, const char * buf, apr_size_t size);

/**
 * in_broadcast_send_cli
 * @return
 */
IN_DECLARE(int) in_broadcast_send_cli(t_srv_ctx * srv, const char * buf, apr_size_t size);

#endif /* _SERVER_CONTEXT__H_ */


#ifndef _CONFIG__H_
#define _CONFIG__H_

#include "common.h"

//#define FEATURE_CLI_POLLSET
#define FEATURE_REUSE_ADDR
//#define FEATURE_SO_LINGER
//#define FEATURE_NONE_BLOCK_MODE
#define FEATURE_NO_WAIT_SRV_DESTROY
//#define FEATURE_DETAIL_ALARM

typedef struct _t_conf t_conf;

/**
 * @brief A structure that conf
 */
struct _t_conf {
    char path[D_PATH_SIZE];
    struct {
        char srcid[4+1]; /**< Length to be 4 */
        char state[1+1]; /**< A, B, D + \0 */
    }proc;
    struct {
        apr_uint16_t port;
        apr_int32_t max_connection;
    }server;
    struct {
        char name[D_NAME_SIZE];
        char path[D_PATH_SIZE];
    }plugin;
    struct {
        apr_uint32_t check_interval;
        apr_uint32_t login_timeout;
        apr_uint32_t heartbeat_timeout;
        apr_uint32_t supported_max_tps;
    }manage;
    struct {
        apr_int32_t disp_status;
        apr_int32_t disp_status_inbound;
        apr_int32_t disp_status_outbound;
        apr_int32_t disp_status_fail_count;
    }status;
    struct {
        char log_path[D_PATH_SIZE];
        apr_int32_t log_level;
        apr_int32_t rolling;
        apr_int32_t max_count;
        apr_off_t max_size;
    }logger;
    struct {
        char name[D_NAME_SIZE]; /**< System name */
        char state[2]; /**< A, B, D + \0 */
    }sys;
    int inbound_num;
    struct {
        bool used;
        char name[D_NAME_SIZE]; /**< Session name */
        char state[2];
        char ipaddr[D_STR_IPv4_SIZE];
    }inbound[D_MAX_SESSION+1]; /**< Inbound session info. index is session signature. */
    int outbound_num;
    struct {
        bool used;
        char name[D_NAME_SIZE]; /**< Session name */
        char ipaddr[D_STR_IPv4_SIZE];
        apr_uint16_t port;
    }outbound[D_MAX_SESSION+1]; /**< Outbound session info. index is session signature. */
    struct {
        char info[256];
    }outbound_plugin[D_MAX_SESSION+1]; /**< Outbound session info. index is session signature. for plugin. */
    struct {
        int use_login_feature;
        int use_oam_info_file;
        int use_send_dgram_feature;
        char oam_info_file[D_PATH_SIZE];
        char oam_dgram_ip[D_STR_IPv4_SIZE];
        apr_uint16_t oam_dgram_port;
        char sys_info_file[D_PATH_SIZE];
    }oam;
    apr_pool_t * pool;
    apr_os_thread_t mythd;
    apr_thread_mutex_t * mymutex;
};

/**
 * in_create_conf
 * @return
 */
IN_DECLARE(t_conf *) in_create_conf(const char * path, apr_pool_t * pool);

/**
 * in_create_conf_global
 * @return
 */
IN_DECLARE(t_conf *) in_create_conf_global(const char * path, apr_pool_t * pool);

/**
 * in_destroy_conf
 * @return
 */
IN_DECLARE(void) in_destroy_conf(t_conf * conf);

/**
 * in_destroy_conf_global
 * @return
 */
IN_DECLARE(void) in_destroy_conf_global(void);

/**
 * in_reload_conf_info
 * @return
 */
IN_DECLARE(int) in_reload_conf_info(t_conf * conf);

/**
 * in_reload_conf_info_global
 * @return
 */
IN_DECLARE(int) in_reload_conf_info_global(void);

/**
 * in_get_conf
 * @return
 */
IN_DECLARE(int) in_get_conf(t_conf * OUT dst, t_conf * IN src);

/**
 * in_get_conf_global_ref
 * @return
 */
IN_DECLARE(t_conf *) in_get_conf_global_ref(void);

/**
 * in_get_conf_logger_level
 * @return
 */
IN_DECLARE(apr_int32_t) in_get_conf_logger_level(t_conf * conf);

/**
 * in_get_conf_logger_level_global
 * @return
 */
IN_DECLARE(apr_int32_t) in_get_conf_logger_level_global(void);

/**
 * in_get_conf_state_global
 * @return
 */
IN_DECLARE(char) in_get_conf_state_global(void);

/**
 * in_desc_conf
 * @return
 */
IN_DECLARE(void) in_desc_conf(t_conf * conf);

#endif /* _CONFIG__H_ */

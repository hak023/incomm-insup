#ifndef _OUTBOUND_CLIENT__H_
#define _OUTBOUND_CLIENT__H_

#include "common.h"
#include "config.h"
#include "clientcontext.h"

typedef struct _t_outbounf_cli_ctx t_outbound_cli_ctx;

struct _t_outbounf_cli_ctx {
    t_cli_ctx cli;
    char state[2];
    apr_time_t last_heartbeat_time;
};

/**
* on_outbound_cli_attach
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_attach(t_outbound_cli_ctx * icli);

/**
* on_outbound_cli_detach
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_detach(t_outbound_cli_ctx * icli);

/**
* on_outbound_cli_idle
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_idle(t_outbound_cli_ctx * icli, apr_time_t elasped_time);

/**
* on_outbound_cli_recv
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_recv(t_outbound_cli_ctx * icli, apr_socket_t * csock);

/**
* on_outbound_cli_send
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_send(t_outbound_cli_ctx * icli, const char * buf, apr_size_t size);

/**
* Outbound sending
*/
IN_DECLARE(int) outbound_send(t_outbound_cli_ctx * cli, const char IN * buf, apr_size_t IN size, int IN wantStatistics);

/**
* Outbound sending round-robin
*/
IN_DECLARE(int) outbound_send_rr(char * buf, apr_size_t size, int IN wantStatistics, int (*on_modify_data) (t_cli_ctx * cli, char IN OUT * buf, apr_size_t IN size));

/**
* Outbound update state
*/
IN_DECLARE(int) update_state(t_outbound_cli_ctx * cli, char state);

#endif /* _INBOUND_CLIENT__H_ */

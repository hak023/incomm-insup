#include "common.h"
#include "version.h"

#if defined(__DATE__) && defined(__TIME__)
static char g_pkg_built[32] = {0,} /*__DATE__ " " __TIME__*/;
#else
static char g_pkg_built[32] = "Unknown";
#endif

/**
 * Get the date a time that the pkg was built
 * @return The server build time string
 */
IN_DECLARE(const char *) get_pkg_built(void)
{
    if(!g_pkg_built[0]) 
        snprintf(g_pkg_built, sizeof(g_pkg_built), "%04d%02d%02d%02d%02d%02d", BUILD_YEAR, BUILD_MONTH, BUILD_DAY, BUILD_HOUR, BUILD_MIN, BUILD_SEC);
    return g_pkg_built;
}

/**
 * It returns the package version
 * @return
 */
IN_DECLARE(const char *) get_pkg_version(void)
{
    return PKG_VERSION;
}

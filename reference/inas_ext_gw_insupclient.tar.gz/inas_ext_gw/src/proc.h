#ifndef _PROCESS__H_
#define _PROCESS__H_

#include "common.h"
#include "config.h"
#include "proc.h"
#include "oam.h"
#include "status.h"
#include "plugin.h"
#include "servercontext.h"

typedef struct _t_proc_rec t_proc_rec;

/**
 * @brief A structure that represents one proc
 */
struct _t_proc_rec {
    apr_pool_t * pool;
    int pid;
    apr_uint32_t isrun;
    char name[D_NAME_SIZE];
    char conf_path[D_PATH_SIZE];
    char begin_time[D_STR_TIME_SIZE];
    apr_pollset_t * pollset;
    t_srv_ctx * isrv;
    t_srv_ctx * osrv;
    t_status * status;
    t_conf * conf;
    t_plugin_handle * hplug;
    t_oam_info oam;
    apr_thread_mutex_t * accept_mutex;
    void(* destroy_process)(int exit_value);
};

/**
 * in_get_running_old_pid
 * @return
 */
IN_DECLARE(int) in_get_running_old_pid(t_proc_rec * proc);

/**
 * in_generate_pid_info
 * @return
 */
IN_DECLARE(bool) in_generate_pid_info(t_proc_rec * proc);

/**
 * in_remove_pid_info
 * @return
 */
IN_DECLARE(void) in_remove_pid_info(t_proc_rec * proc);


/**
* get_proc_rec
* @return
*/
IN_DECLARE(t_proc_rec *) get_proc_rec(void);

/**
* get_proc_rec_ref
* @return
*/
IN_DECLARE(t_proc_rec *) get_proc_rec_ref(void);

#endif /* _PROCESS__H_ */

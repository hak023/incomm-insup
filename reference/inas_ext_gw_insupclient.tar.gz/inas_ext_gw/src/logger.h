#ifndef _LOGGER__H_
#define _LOGGER__H_

#include "common.h"

#define LOGGER_STACK_BUFFER_SIZE    (10240)

#define LOG_DISPLAY_KEY_LENGTH      (20)

#define LOG_LV_ERR                  0
#define LOG_LV_WARNING              1
#define LOG_LV_SYS                  2
#define LOG_LV_INF                  3
#define LOG_LV_DBG                  5
#define LOG_LV_DBG_VERBOSE          6

#define LOGE(...)                   in_write_log_global(LOG_LV_ERR,   __FILE__, __LINE__, "ERR", __VA_ARGS__)
#define LOGEK(_KEY_, ...)           in_write_log_global(LOG_LV_ERR,   __FILE__, __LINE__, _KEY_, __VA_ARGS__)
#define LOGW(...)                   in_write_log_global(LOG_LV_WARNING,   __FILE__, __LINE__, "WARN", __VA_ARGS__)
#define LOGS(...)                   in_write_log_global(LOG_LV_SYS,   __FILE__, __LINE__, "SYS"  , __VA_ARGS__)
#define LOGI(...)                   in_write_log_global(LOG_LV_INF,   __FILE__, __LINE__, "INFO" , __VA_ARGS__)
#define LOGI0(...)                  in_write_log_global(LOG_LV_INF+0,  __FILE__, __LINE__, "INFO"  , __VA_ARGS__)
#define LOGI1(...)                  in_write_log_global(LOG_LV_INF+1,  __FILE__, __LINE__, "INFO"  , __VA_ARGS__)
#define LOGI0K(_KEY_, ...)          in_write_log_global(LOG_LV_INF+0,  __FILE__, __LINE__, _KEY_  , __VA_ARGS__)
#define LOGI1K(_KEY_, ...)          in_write_log_global(LOG_LV_INF+1,  __FILE__, __LINE__, _KEY_  , __VA_ARGS__)
#define LOGD(...)                   in_write_log_global(LOG_LV_DBG,   __FILE__, __LINE__, "DEBUG", __VA_ARGS__)
#define LOGV(...)                   in_write_log_global(LOG_LV_DBG_VERBOSE, __FILE__, __LINE__, "VERBOS", __VA_ARGS__)

typedef struct _t_logger t_logger;

/**
 * @brief A structure that logger
 */
struct _t_logger {
    char path[D_PATH_SIZE];
    char last_date[D_STR_TIME_SIZE];
    apr_file_t * fd;
    apr_pool_t * pool;
    apr_os_thread_t mythd;
    apr_thread_mutex_t * mymutex;
    volatile int level;
    int rolling;
    apr_uint32_t curr_count;
    apr_uint32_t max_count;
    apr_off_t max_size;
};

/**
 * in_create_logger
 * @return
 */
IN_DECLARE(t_logger *) in_create_logger(const char * path, int is_rolling, int level, apr_uint32_t max_count, apr_off_t max_size, apr_pool_t * pool);

/**
 * in_destory_logger
 * @return
 */
IN_DECLARE(void) in_destroy_logger(t_logger * log);

/**
 * in_destroy_logger_global
 * @return
 */
IN_DECLARE(void) in_destroy_logger_global(void);

/**
 * in_set_global_logger
 * @return
 */
IN_DECLARE(void) in_set_global_logger(t_logger * log);

/**
 * in_set_logger_info
 * @return
 */
IN_DECLARE(int) in_set_logger_info(t_logger * log, int level, apr_uint32_t max_count, apr_off_t max_size);

/**
 * in_set_logger_info
 * @return
 */
IN_DECLARE(int) in_set_logger_info_global(int level, apr_uint32_t max_count, apr_off_t max_size);

/**
 * in_check_and_rolling_logger
 * @return
 */
IN_DECLARE(void) in_check_and_rolling_logger(t_logger * log);

/**
 * in_check_and_rolling_logger_global
 * @return
 */
IN_DECLARE(void) in_check_and_rolling_logger_global(void);

/**
 * in_write_log
 * @return
 */
IN_DECLARE(int) in_write_log(t_logger * log, const int lv, const char * fname, const int line, const char * key, const char *fmt, ...);

/**
 * in_write_log_global
 * @return
 */
IN_DECLARE(int) in_write_log_global(const int lv, const char * fname, const int line, const char * key, const char *fmt, ...);

/**
 * in_write_log_global_for_plugin
 * @return
 */
IN_DECLARE(int) in_write_log_global_for_plugin(const int lv, const char * fname, const int line, const char * key, const char *fmt, ...);

/**
 * in_generate_string_with_binary
 * @return
 */
IN_DECLARE(void) in_generate_string_with_binary(char * dst, int dstsize, const char * src, int srcsize);

#endif /* _LOGGER__H_ */

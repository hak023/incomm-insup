#ifndef _STATISTICS__H_
#define _STATISTICS__H_

#include "common.h"
#include "config.h"

#define ST_FAIL_REASON_ETC                      0
#define ST_FAIL_REASON_SOCKET                   1
#define ST_FAIL_REASON_INVALID_FORMAT           2
#define ST_FAIL_REASON_CANT_FIND_SESSION        3
#define ST_FAIL_REASON_TIME_UP                  4
#define ST_FAIL_REASON_OVERLOADED               5
#define ST_FAIL_REASON_NOT_LOGINED              6
#define ST_FAIL_REASON_PLUGIN                   7
#define ST_FAIL_MAX_REASONs                     8

typedef struct {
    apr_uint64_t recv_count;
    apr_uint64_t recv_succ_count;
    apr_uint64_t recv_fail_count;
    apr_uint64_t recv_fail_reasons[ST_FAIL_MAX_REASONs];
    apr_uint64_t send_count;
    apr_uint64_t send_succ_count;
    apr_uint64_t send_fail_count;
    apr_uint64_t send_fail_reasons[ST_FAIL_MAX_REASONs];    
}t_stat_client_item;

typedef struct _t_stat {
    _t_stat() {
        mymutex = NULL;
        memset(iclis, 0, sizeof(iclis));
        memset(oclis, 0, sizeof(oclis));
        memset(recv_fail_reasons, 0, sizeof(recv_fail_reasons));
        memset(send_fail_reasons, 0, sizeof(send_fail_reasons));
    }
    apr_thread_mutex_t * mymutex;
    t_stat_client_item iclis[D_MAX_SESSION+1];
    t_stat_client_item oclis[D_MAX_SESSION+1];
    apr_uint64_t recv_fail_reasons[ST_FAIL_MAX_REASONs];
    apr_uint64_t send_fail_reasons[ST_FAIL_MAX_REASONs];
}t_stat;

int init_stat(apr_pool_t * pool);
void exit_stat(void);
const t_stat * stat_get(void);

void stat_i_inc_recv(const apr_uint16_t sid);
void stat_i_inc_recv_succ(const apr_uint16_t sid);
void stat_i_inc_recv_fail(const apr_uint16_t sid, const int reason);
void stat_i_inc_send(const apr_uint16_t sid);
void stat_i_inc_send_succ(const apr_uint16_t sid);
void stat_i_inc_send_fail(const apr_uint16_t sid, const int reason);
void stat_o_inc_recv(const apr_uint16_t sid);
void stat_o_inc_recv_succ(const apr_uint16_t sid);
void stat_o_inc_recv_fail(const apr_uint16_t sid, const int reason);
void stat_o_inc_send(const apr_uint16_t sid);
void stat_o_inc_send_succ(const apr_uint16_t sid);
void stat_o_inc_send_fail(const apr_uint16_t sid, const int reason);

#endif /* _STATISTICS__H_ */

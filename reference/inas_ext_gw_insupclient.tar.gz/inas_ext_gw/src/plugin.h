#ifndef _PLUGIN__H_
#define _PLUGIN__H_

#include "common.h"
#include "clientcontext.h"
#include <json/json.h>

typedef struct _t_plugin_handle t_plugin_handle;

struct _t_plugin_handle {
    char name[64]; /**< Plugin name */
    char conf_path[256]; /**< Conf file */

    /* Inbound session */
    int (*on_iconnect)(t_cli_ctx * cli);
    int (*on_idisconnect)(t_cli_ctx * cli);
    int (*on_iidle)(t_cli_ctx * cli, apr_time_t elasped_time);
    int (*on_irecv)(t_cli_ctx * cli, apr_time_t rtime, const char * op, const char * tid, const apr_uint16_t sid, const char * svcid, const char * srcid, Json::Value & root);
    int (*isend)(t_cli_ctx * cli, const char * tid, const char * IN buf, apr_size_t IN size);
    int (*isend_sig)(apr_uint16_t sid, const char * tid, const char * IN buf, apr_size_t IN size);

    /* Outbound session */
    int (*on_oconnect)(t_cli_ctx * cli, char * conf);
    int (*on_odisconnect)(t_cli_ctx * cli);
    int (*on_oidle)(t_cli_ctx * cli, apr_time_t elasped_time);
    int (*on_orecv_tokenize)(t_cli_ctx * cli, apr_socket_t * csock, char * OUT buf, apr_size_t * IN OUT psize);
    int (*on_orecv)(t_cli_ctx * cli, apr_time_t rtime, char * IN buf, apr_size_t IN size, int & OUT wantStatistics);
    int (*osend)(t_cli_ctx * cli, const char IN * buf, apr_size_t IN size, int IN wantStatistics);
    int (*osend_rr)(char IN * buf, apr_size_t IN size, int IN wantStatistics, int (*on_modify_data) (t_cli_ctx * cli, char IN OUT * buf, apr_size_t IN size));

    /* Common session */
    int (*update_state)(t_cli_ctx * cli, char state);
};

/**
 * in_load_plugin_dso
 * @return 
 */
IN_DECLARE(int) in_load_plugin_dso(const char * path, const char * plug_name, t_plugin_handle ** OUT phplug, t_plugin_handle * IN hplug, apr_pool_t * pool);

/**
 * in_unload_plugin_dso
 * @return 
 */
IN_DECLARE(void) in_unload_plugin_dso(t_plugin_handle * IN OUT hplug);

/**
 * Get the date a time that the pkg was built
 * @return The server build time string
 */
IN_EXPORT_REFERENCE(const char *, get_plugin_built)(void);

/**
 * get_plugin_version
 * @return
 */
IN_EXPORT_REFERENCE(const char *, get_plugin_version)(void);

#endif /* _PLUGIN__H_ */

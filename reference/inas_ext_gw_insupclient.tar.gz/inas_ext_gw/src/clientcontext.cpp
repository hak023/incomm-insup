#include "common.h"
#include "logger.h"
#include "clientcontext.h"

/**
 * Periodic sleep event processing
 * @param cli
 * @param elasped_time
 * @return result 
 */
static inline int on_cli_idle(t_cli_ctx * cli, apr_time_t elasped_time) {
    if(cli == NULL)
        return IN_FAIL;
    cli->lived_time += elasped_time;
    if(cli->sid == 0) {
        if(cli->lived_time > cli->reg_sig_timeout) {
            return IN_ERR_LOGIN_TIME_UP;
        }
    }
    int rv = IN_SUCCESS;
    if(cli->on_idle)
        rv = cli->on_idle(cli, elasped_time);
    LOGV("[%s|%04d] In:%lu, Out:%lu, Live:%lu(sec)\n", cli->name, cli->sid, cli->st_in_tot_count, cli->st_out_tot_count, apr_time_sec(cli->lived_time));
    return rv;
}

/**
 * Client event processing
 * @param thd
 * @param buf
 * @return result
 */
void * APR_THREAD_FUNC in_on_task_cli_ctx(apr_thread_t *thd, void *buf) {
    in_assert(thd);
    in_assert(buf);
    t_cli_ctx * cli = (t_cli_ctx *)buf;
    apr_socket_t * sock = cli->sock;
    char err[128];
    int rv, rv_timeup;
    apr_time_t curr_time, last_time = apr_time_now();
#ifdef FEATURE_CLI_POLLSET
    apr_pollset_t * pollset = NULL;
    apr_socket_t * sock_as_pollset = sock;
    if(sock_as_pollset) {
        rv = apr_pollset_create(&pollset, 1, cli->pool, 0);
        apr_pollfd_t pfd = { cli->pool, APR_POLL_SOCKET, APR_POLLIN, 0, { NULL }, NULL };
        pfd.desc.s = sock_as_pollset;
        rv = apr_pollset_add(pollset, &pfd);
    }
#endif
    LOGS("[%s|%04d] Start '%s'\n", cli->name, cli->sid, cli->bind_ip_addr);
    if(!sock) {
        LOGE("[%s|%04d] Invalid sock\n", cli->name, cli->sid);
        goto GT_EXIT;
    }
    if(cli->on_attach) {
        rv = cli->on_attach(cli);
        if(IN_ERR_IS_CLOSING_SOCKET(rv)) {
            in_get_error_string(err, sizeof(err), rv);
            LOGE("[%s|%04d] Attach processing error. last error(%s)\n", cli->name, cli->sid, err);
            goto GT_EXIT;
        }
    }    
    for(;apr_atomic_read32(&cli->isrun);)
    {
        apr_int32_t num = 0;
        rv_timeup = IN_SUCCESS;        
        if(!IN_ERR_IS_CLOSING_SOCKET(cli->last_error_code)) {
            cli->last_error_code = IN_SUCCESS;
        }
#ifdef FEATURE_CLI_POLLSET
        const apr_pollfd_t *retfd;
        rv = apr_pollset_poll(pollset, cli->check_interval, &num, &retfd);
#else
        rv = in_socket_atreadeof(sock, cli->check_interval, &num); /* Bug : Somtimes occur kernel error */
#endif
        if (rv == APR_SUCCESS) {
#ifdef FEATURE_CLI_POLLSET
            if(num == 0) {
                LOGE("[%s|%04d] EOF and destroying\n", cli->name, cli->sid);
                break;
            }
            else {
                bool needtoexit = false;
                for (int i = 0; i < num; ++i)
                {
                    const apr_pollfd_t * fd = retfd + i;
                    apr_int16_t rtnevents = fd->rtnevents;
                    if ((rtnevents & APR_POLLIN) || (rtnevents & APR_POLLPRI) || (rtnevents & APR_POLLHUP)) {
                        rv = cli->on_recv(cli, sock);
                        if(IN_ERR_IS_CLOSING_SOCKET(rv)) {
                            needtoexit = true;
                            in_get_error_string(err, sizeof(err), rv);
                            LOGE("[%s|%04d] Recv fail. cause(%s)\n", cli->name, cli->sid, err);
                            break;
                        }
                        else {
                            ++cli->st_in_tot_count;
                        }
                    }
                    else if ((rtnevents & APR_POLLERR) || (rtnevents & APR_POLLNVAL)) {
                        needtoexit = true;
                        LOGE("[%s|%04d] Poll terminated result(%d)\n", cli->name, cli->sid, rv);
                        break;
                    }
                }
                if(needtoexit) {
                    break;
                }
            }
#else
            if(num == 1) {
                LOGE("[%s|%04d] EOF and destroying\n", cli->name, cli->sid);
                break;
            }
            else {
                rv = cli->on_recv(cli, sock);
                if(IN_ERR_IS_CLOSING_SOCKET(rv)) {
                    in_get_error_string(err, sizeof(err), rv);
                    LOGE("[%s|%04d] Recv fail. cause(%s)\n", cli->name, cli->sid, err);
                    break;
                }
                else {
                    ++cli->st_in_tot_count;
                }
            }
#endif                
        }
        else if(APR_STATUS_IS_TIMEUP(rv)) {
            curr_time = apr_time_now();
            rv_timeup = on_cli_idle(cli, curr_time - last_time);
            last_time = curr_time;
            goto GT_CONT;
        }
        else if(APR_STATUS_IS_EINTR(rv) || rv == APR_EGENERAL) {
            in_get_error_string(err, sizeof(err), cli->last_error_code);
            LOGE("[%s|%04d] Poll terminated result(%d). last error(%s)\n", cli->name, cli->sid, rv, err);
            break;
        }
        else {
            in_get_error_string(err, sizeof(err), cli->last_error_code);
            LOGE("[%s|%04d] Poll terminated result(%d). last error(%s)\n", cli->name, cli->sid, rv, err);
            break;
        }
        curr_time = apr_time_now();
        if(curr_time - last_time > cli->check_interval) {
            rv_timeup = on_cli_idle(cli, curr_time - last_time);
            last_time = curr_time;
        }
GT_CONT:
        if(IN_ERR_IS_CLOSING_SOCKET(rv_timeup)) {
            in_get_error_string(err, sizeof(err), rv_timeup);
            LOGE("[%s|%04d] Idle processing error. last error(%s)\n", cli->name, cli->sid, err);
            break;
        }        
        if(IN_ERR_IS_CLOSING_SOCKET(cli->last_error_code)) {
            in_get_error_string(err, sizeof(err), cli->last_error_code);
            LOGE("[%s|%04d] Force stopped. last error(%s)\n", cli->name, cli->sid, err);
			goto GT_EXIT;			
        }
#ifdef _DEBUG        
        LOGV("[%s|%04d] Result(%d), Poll(%d)\n", cli->name, cli->sid, rv, num);
#endif
    }
GT_EXIT:
#ifdef FEATURE_CLI_POLLSET
    if(pollset) {
        if(sock_as_pollset) {
            apr_pollfd_t pfd = { cli->pool, APR_POLL_SOCKET, APR_POLLIN, 0, { NULL }, NULL };
            pfd.desc.s = sock_as_pollset;
            rv = apr_pollset_remove(pollset, &pfd);
        }
        apr_pollset_destroy(pollset);
    }
#endif
    in_destroy_cli_ctx(cli);
    return 0;
}

/**
 * Create client context ipv4
 * @param name
 * @param sid
 * @param alloc_size
 * @param csock
 * @param conn_pool
 * @param conn_pool_allocator
 * @param srv
 * @param on_attach
 * @param on_detach
 * @param on_recv
 * @param on_send
 * @param pool
 * @return Client context
 */
IN_DECLARE(t_cli_ctx *) in_create_cli_ctx(
        const char * name, 
        apr_uint16_t sid, /* Not use this time, need to login packet */
        apr_size_t alloc_size, 
        apr_socket_t * csock, 
        apr_pool_t * conn_pool, 
        apr_allocator_t * conn_pool_allocator, 
        t_srv_ctx * srv, 
        t_cli_ctx_attach_callback on_attach, 
        t_cli_ctx_detach_callback on_detach, 
        t_cli_ctx_recv_callback on_recv, 
        t_cli_ctx_send_callback on_send, 
        t_cli_ctx_idle_callback on_idle, 
        apr_pool_t * pool) {
    t_cli_ctx * cli = (t_cli_ctx *)calloc(1, (alloc_size) ? alloc_size : sizeof(t_cli_ctx));
    apr_pool_t * cli_pool = NULL;
    apr_allocator_t * cli_pool_allocator = NULL;
    apr_thread_mutex_t * mymutex = NULL;    
    if(cli == NULL) {
        goto GT_ERR;
    }
    {
        apr_status_t rv = IN_SUCCESS;
        rv = in_pool_create(&cli_pool, NULL, pool);
        if(rv != APR_SUCCESS) {
            LOGE("Could not create pool client context\n");
            goto GT_ERR;
        }
        if(name != NULL && strlen(name) != 0)
            in_strncpy(cli->name, name, sizeof(cli->name));
        else
            in_strncpy(cli->name, "Unknown", sizeof(cli->name));
        apr_pool_tag(cli_pool, cli->name);
        rv = apr_thread_mutex_create(&mymutex, APR_THREAD_MUTEX_NESTED, cli_pool);
        if(rv != APR_SUCCESS) {
            goto GT_ERR;
        }
        char * addr = NULL;
        apr_sockaddr_t * sa = NULL;
        apr_socket_addr_get(&sa, APR_REMOTE, csock);
        apr_sockaddr_ip_get(&addr, sa);
        in_strncpy(cli->bind_ip_addr, (addr) ? addr : "", sizeof(cli->bind_ip_addr));        
#ifndef FEATURE_SO_LINGER
        rv = apr_socket_opt_set(csock, APR_SO_LINGER, 0);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_LINGER on client socket\n");
#endif
#ifdef FEATURE_NONE_BLOCK_MODE
        rv = apr_socket_opt_set(csock, APR_SO_NONBLOCK, 1);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_NONBLOCK on client socket\n");
        rv = apr_socket_timeout_set(csock, 0);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_TIMEOUT on client socket\n");
#else
        rv = apr_socket_opt_set(csock, APR_SO_NONBLOCK, 0);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_NONBLOCK on client socket\n");
        rv = apr_socket_timeout_set(csock, apr_time_from_msec(CLIENT_COMM_TIME_OUT));
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_TIMEOUT on client socket\n");
#endif
        cli->srv = srv;
        cli->srv_port = srv?srv->port:0;
        cli->mythd = apr_os_thread_current();
        cli->last_error_code = IN_SUCCESS;
        cli->begin_time = apr_time_now();
        char str_begin_time[D_STR_TIME_SIZE];
        in_time_to_string(str_begin_time, sizeof(str_begin_time), "%Y/%m/%d-%H:%M:%S", cli->begin_time);
        strncpy(cli->str_begin_time, str_begin_time+2, sizeof(cli->str_begin_time));
        cli->lived_time = 0;
        cli->check_interval = apr_time_from_msec(CLIENT_CHECK_INTERVAL);
        cli->reg_sig_timeout = apr_time_from_msec(CLIENT_CHECK_INTERVAL);
        cli->pool = cli_pool;
        cli->pool_allocator = cli_pool_allocator;
        cli->conn_pool = conn_pool;
        cli->conn_pool_allocator = conn_pool_allocator;
        cli->sock = csock;
        cli->mymutex = mymutex;                
        cli->on_attach = on_attach;
        cli->on_detach = on_detach;
        cli->on_idle = on_idle;
        cli->on_recv = on_recv;
        cli->on_send = on_send;
        cli->st_in_tot_count = cli->st_out_tot_count = 0;
        if(cli->srv && in_reg_cli_to_srv_ctx(cli->srv, cli) != IN_SUCCESS) {
            goto GT_ERR;
        }
        apr_atomic_set32(&cli->isrun, 1);
    }
    return cli;
GT_ERR:
    if(mymutex != NULL)
        apr_thread_mutex_destroy(mymutex);
    in_pool_destroy(cli_pool, cli_pool_allocator);
    SAFE_FREE(cli);
    return NULL;
}

/**
 * Connect client context ipv4
 * @param name
 * @param sid
 * @param alloc_size
 * @param bind_ip_addr
 * @param bind_port 
 * @param srv
 * @param on_attach
 * @param on_detach
 * @param on_recv
 * @param on_send
 * @param pool
 * @return Client context
 */
IN_DECLARE(t_cli_ctx *) in_create_cli_ctx_with_connect(
        const char * name, 
        apr_uint16_t sid, 
        apr_size_t alloc_size,
        const char * bind_ip_addr,
        const apr_uint16_t bind_port,
        t_srv_ctx * srv, 
        t_cli_ctx_attach_callback on_attach, 
        t_cli_ctx_detach_callback on_detach, 
        t_cli_ctx_recv_callback on_recv, 
        t_cli_ctx_send_callback on_send, 
        t_cli_ctx_idle_callback on_idle, 
        apr_pool_t * pool) {
    t_cli_ctx * cli = (t_cli_ctx *)calloc(1, (alloc_size) ? alloc_size : sizeof(t_cli_ctx));
    apr_socket_t * csock = NULL;
    apr_pool_t * cli_pool = NULL, * conn_pool = NULL;
    apr_allocator_t * cli_pool_allocator = NULL, * conn_pool_allocator = NULL;
    apr_thread_mutex_t * mymutex = NULL;
    if(cli == NULL) {
        goto GT_ERR;
    }    
    {
        apr_status_t rv = IN_SUCCESS;
        rv = in_pool_create(&cli_pool, NULL, pool);
        if(rv != APR_SUCCESS) {
            LOGE("Could not create pool client context (%s:%d)\n", bind_ip_addr, bind_port);
            goto GT_ERR;
        }
        apr_sockaddr_t *sa = NULL;
        rv = apr_sockaddr_info_get(&sa, bind_ip_addr, APR_INET, bind_port, 0, cli_pool);
        if (rv != APR_SUCCESS) {
            LOGE("Could not generating sockaddr client context (%s:%d)\n", bind_ip_addr, bind_port);
            goto GT_ERR;
        }
        rv = apr_socket_create(&csock, sa->family, SOCK_STREAM, APR_PROTO_TCP, cli_pool);
        if (rv != APR_SUCCESS) {
            LOGE("Could not creating client context (%s:%d)\n", bind_ip_addr, bind_port);
            goto GT_ERR;
        }
#ifndef FEATURE_SO_LINGER
        rv = apr_socket_opt_set(csock, APR_SO_LINGER, 0);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_LINGER on client socket\n");
#endif
#ifdef FEATURE_NONE_BLOCK_MODE
        rv = apr_socket_opt_set(csock, APR_SO_NONBLOCK, 1);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_NONBLOCK on client socket\n");
        rv = apr_socket_timeout_set(csock, 0);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_TIMEOUT on client socket\n");
#else
        rv = apr_socket_opt_set(csock, APR_SO_NONBLOCK, 0);
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_NONBLOCK on client socket\n");
        rv = apr_socket_timeout_set(csock, apr_time_from_msec(CLIENT_COMM_TIME_OUT));
        if(rv != APR_SUCCESS)
            LOGE("Could not set SO_TIMEOUT on client socket\n");
#endif
        rv = apr_socket_connect(csock, sa);
        if (rv != APR_SUCCESS) {
            LOGE("Could not connecting client context (%s:%d)\n", bind_ip_addr, bind_port);
            goto GT_ERR;
        }
        if(name != NULL && strlen(name) != 0)
            in_strncpy(cli->name, name, sizeof(cli->name));
        else
            in_strncpy(cli->name, "Unknown", sizeof(cli->name));
        apr_pool_tag(cli_pool, cli->name);
        rv = apr_thread_mutex_create(&mymutex, APR_THREAD_MUTEX_NESTED, cli_pool);
        if(rv != APR_SUCCESS) {
            goto GT_ERR;
        }
        cli->sid = sid;
        in_strncpy(cli->bind_ip_addr, bind_ip_addr, sizeof(cli->bind_ip_addr));        
        cli->srv = srv;
        cli->srv_port = bind_port;
        cli->mythd = apr_os_thread_current();
        cli->last_error_code = IN_SUCCESS;
        cli->begin_time = apr_time_now();
        char str_begin_time[D_STR_TIME_SIZE];
        in_time_to_string(str_begin_time, sizeof(str_begin_time), "%Y/%m/%d-%H:%M:%S", cli->begin_time);
        strncpy(cli->str_begin_time, str_begin_time+2, sizeof(cli->str_begin_time));
        cli->lived_time = 0;
        cli->check_interval = apr_time_from_msec(CLIENT_CHECK_INTERVAL);
        cli->reg_sig_timeout = apr_time_from_msec(CLIENT_CHECK_INTERVAL);
        cli->pool = cli_pool;
        cli->pool_allocator = cli_pool_allocator;
        cli->conn_pool = conn_pool;
        cli->conn_pool_allocator = conn_pool_allocator;
        cli->sock = csock;
        cli->mymutex = mymutex;
        cli->on_attach = on_attach;
        cli->on_detach = on_detach;
        cli->on_idle = on_idle;
        cli->on_recv = on_recv;
        cli->on_send = on_send;
        cli->st_in_tot_count = cli->st_out_tot_count = 0;
        if(cli->srv && in_reg_cli_to_srv_ctx(cli->srv, cli) != IN_SUCCESS) {
            goto GT_ERR;
        }
        apr_atomic_set32(&cli->isrun, 1);
    }
    return cli;
GT_ERR:
    if(mymutex != NULL)
        apr_thread_mutex_destroy(mymutex);
    APR_SAFE_CLOSE_SOCKET(csock);
    in_pool_destroy(conn_pool, conn_pool_allocator);
    in_pool_destroy(cli_pool, cli_pool_allocator);
    SAFE_FREE(cli);
    return NULL;
}

/**
 * Destory client context
 * @param cli
 * @return void
 */
IN_DECLARE(void) in_destroy_cli_ctx(t_cli_ctx * cli) {
    if(cli) {        
        if(cli->on_detach)
            cli->on_detach(cli);
        LOGV("[%s|%04d] Destroy client context\n", cli->name, cli->sid);
        apr_atomic_set32(&cli->isrun, 0);
        t_srv_ctx * srv = cli->srv;
        if(srv) in_unreg_cli_to_srv_ctx(srv,  cli);
        LOCK(cli->mymutex);
        cli->last_error_code = IN_ERR_FORCE_CLOSE;        
        IN_SAFE_CLOSE_SOCKET(cli->sock);
        in_pool_destroy(cli->conn_pool, cli->conn_pool_allocator);
        cli->conn_pool = NULL;
        cli->conn_pool_allocator = NULL;
        UNLOCK(cli->mymutex);
        if(cli->mymutex != NULL)
            apr_thread_mutex_destroy(cli->mymutex);
        cli->mymutex = NULL;        
        in_pool_destroy(cli->pool, cli->pool_allocator);
        cli->pool = NULL;
        cli->pool_allocator = NULL;
        SAFE_FREE(cli);
    }
}

/**
 * Invoke destory client context
 * @param cli
 * @return void
 */
IN_DECLARE(void) in_invoke_destroy_cli_ctx(t_cli_ctx * cli) {
    if(cli) {
        LOGV("[%s|%04d] Invoke destorying client context\n", cli->name, cli->sid);
        LOCK(cli->mymutex);
        cli->last_error_code = IN_ERR_FORCE_CLOSE;
        apr_atomic_set32(&cli->isrun, 0);
        IN_SAFE_CLOSE_SOCKET(cli->sock);
        UNLOCK(cli->mymutex);
    }
}

/**
 * Send data with client context
 * @param cli
 * @param buf
 * @param size
 * @return size
 */
IN_DECLARE(int) in_send_cli_ctx(t_cli_ctx * cli, const char * buf, apr_size_t size) {
    if(cli && buf && size) {
        if(!apr_atomic_read32(&cli->isrun)) {
            LOGE("[%s|%04d] Send fail already stopped. Size=%d\n", cli->name, cli->sid, size);
            return IN_ERR_UNAVAILABLE_RES;
        }
        LOCK(cli->mymutex);
        if(cli->sock == NULL) {
			if(!IN_ERR_IS_CLOSING_SOCKET(cli->last_error_code))
            	cli->last_error_code = IN_ERR_SOCK_SEND;
            apr_atomic_set32(&cli->isrun, 0);
            UNLOCK(cli->mymutex);
            LOGE("[%s|%04d] Send fail sock is null. Size=%d\n", cli->name, cli->sid, size);
            return IN_ERR_SOCK_SEND;
        }
        apr_status_t rv = in_socket_send(cli->sock, buf, &size);
        if(rv != APR_SUCCESS) {
            cli->last_error_code = IN_ERR_SOCK_SEND;
            apr_atomic_set32(&cli->isrun, 0);
            IN_SAFE_CLOSE_SOCKET(cli->sock);
            UNLOCK(cli->mymutex);
            LOGE("[%s|%04d] Send fail '%d' result. Size=%d\n", cli->name, cli->sid, rv, size);
            return IN_ERR_SOCK_SEND;
        }
        UNLOCK(cli->mymutex);
        ++cli->st_out_tot_count;
    }
    return IN_SUCCESS;
}

/**
 * Set last error code and terminate client context
 * @param cli
 * @param last_error_code
 * @return void
 */
IN_DECLARE(void) in_set_last_error_code_cli_ctx(t_cli_ctx * cli, apr_int32_t last_error_code) {
    if(cli) {
        LOCK(cli->mymutex);
        cli->last_error_code = last_error_code;
        if(IN_ERR_IS_CLOSING_SOCKET(last_error_code)) {
            apr_atomic_set32(&cli->isrun, 0);
            IN_SAFE_CLOSE_SOCKET(cli->sock);
            UNLOCK(cli->mymutex);
            char err[128] = {0,};
            in_get_error_string(err, sizeof(err), last_error_code);
            LOGE("[%s|%04d] Mark closing. cause(%s)\n", cli->name, cli->sid, err);
        }
        else {
            UNLOCK(cli->mymutex);
        }
    }
}

/**
 * Check client context
 * @param cli
 * @return true/false
 */
IN_DECLARE(bool) in_is_run_cli_ctx(t_cli_ctx * cli) {
    if(cli) {
        return (apr_atomic_read32(&cli->isrun) == 2) ? true : false;
    }
    return false;
}

#include "common.h"
#include "logger.h"
#include "config.h"
#include "oam.h"
#include "proc.h"
#include "statistics.h"
#include <inas/inas_internal_proto.h>
#include <json/json.h>
#include "oclient.h"

/**
* on_outbound_cli_process
*/
static inline apr_int32_t on_outbound_cli_process(t_outbound_cli_ctx * ocli, char * buf, apr_size_t size) {
    const t_proc_rec * rec = get_proc_rec();
    apr_int32_t rv = IN_SUCCESS;
    if(rec && ocli) {
        t_cli_ctx * cli = &ocli->cli;
        const apr_time_t rtime = apr_time_now();        
        ocli->last_heartbeat_time = rtime;
        if(rec->hplug && rec->hplug->on_orecv) {
            int wantStatistics = 0;
            rv = rec->hplug->on_orecv(cli, rtime, buf, size, wantStatistics);
            if(wantStatistics) {
                stat_o_inc_recv(cli->sid);
                if(rv == IN_SUCCESS) {
                    stat_o_inc_recv_succ(cli->sid);
                }
                else {
                    stat_o_inc_recv_fail(cli->sid, ST_FAIL_REASON_PLUGIN);
                }
            }
        }
    }
    return rv;
}

/**
* on_outbound_cli_attach
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_attach(t_outbound_cli_ctx * ocli) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec && ocli) {
        t_cli_ctx * cli = &ocli->cli;
        t_conf * conf = in_get_conf_global_ref();
        ocli->state[0] = 'B';
        oam_update_osession_state(&rec->oam, cli->sid, cli->bind_ip_addr, true);
        if(rec->hplug && rec->hplug->on_oconnect) {
            return rec->hplug->on_oconnect(cli, conf->outbound_plugin[cli->sid].info);
        }
    }
    return IN_SUCCESS;
}

/**
* on_outbound_cli_detach
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_detach(t_outbound_cli_ctx * ocli) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec && ocli) {    
        t_cli_ctx * cli = &ocli->cli;
        oam_update_osession_state(&rec->oam, cli->sid, cli->bind_ip_addr, false);
        if(rec->hplug && rec->hplug->on_odisconnect) {
            rec->hplug->on_odisconnect(cli);
        }
    }
    return IN_SUCCESS;
}

/**
* on_outbound_cli_idle
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_idle(t_outbound_cli_ctx * ocli, apr_time_t elasped_time) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec && ocli) {    
        t_cli_ctx * cli = &ocli->cli;
        t_conf * conf = in_get_conf_global_ref();
        cli->check_interval = apr_time_from_msec(conf->manage.check_interval);
        cli->reg_sig_timeout = apr_time_from_msec(conf->manage.login_timeout);
        if(rec->hplug && rec->hplug->on_oidle) {
            rec->hplug->on_oidle(&ocli->cli, elasped_time);
        }
    }
    return IN_SUCCESS;
}

/**
* on_outbound_cli_recv
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_recv(t_outbound_cli_ctx * ocli, apr_socket_t * csock) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return IN_FAIL;
    }
    t_cli_ctx * cli = &ocli->cli;
    char buf[P_BUFFER_SIZE] = {0,};
    apr_size_t buf_size = 0;
    apr_int32_t rv = IN_SUCCESS;
    if(rec && rec->hplug && rec->hplug->on_orecv_tokenize) {
        rv = rec->hplug->on_orecv_tokenize(cli, csock, buf, &buf_size);
    }
    if(rv != IN_SUCCESS) {
        LOGE("[%s|%04] Recv error result(%d)\n", cli->name, cli->sid, rv);
        rv = IN_ERR_SOCK_RECV; goto GT_EXIT;
    }
    buf[buf_size] = 0;
    if((rv = on_outbound_cli_process(ocli, buf, buf_size)) != IN_SUCCESS) {
        goto GT_EXIT;
    }
    return rv;
GT_EXIT:
    if(cli) {
        LOCK(cli->mymutex);
        cli->last_error_code = rv;
        UNLOCK(cli->mymutex);
    }
    return rv;
}

/**
* on_outbound_cli_send
*/
IN_DECLARE(apr_int32_t) on_outbound_cli_send(t_outbound_cli_ctx * ocli, const char * buf, apr_size_t size) {
    return in_send_cli_ctx(&ocli->cli, buf, size);
}

/**
* Outbound sending
*/
IN_DECLARE(int) outbound_send(t_outbound_cli_ctx * cli, const char IN * buf, apr_size_t IN size, int IN wantStatistics) {
    if(wantStatistics) stat_o_inc_send(cli->cli.sid);
    int rv = on_outbound_cli_send(cli, buf, size);
    if(wantStatistics) {
        if(rv == IN_SUCCESS) {
            stat_o_inc_send_succ(cli->cli.sid);
        }
        else {
            stat_o_inc_send_fail(cli->cli.sid, ST_FAIL_REASON_SOCKET);
        }
    }
    return rv;
}

/**
* Outbound sending round-robin
*/
IN_DECLARE(int) outbound_send_rr(char * buf, apr_size_t size, int IN wantStatistics, int (*on_modify_data) (t_cli_ctx * cli, char IN OUT * buf, apr_size_t IN size)) {    
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return IN_FAIL;
    }
    t_srv_ctx * srv = rec->osrv;
    int result = IN_FAIL;
    if(srv) {        
        t_cli_ctx * find_ctx = NULL;
        LOCK(srv->mymutex);
        int rr_index = srv->rr_index;
        if(srv->clis_count == 0) {
            goto GT_EXIT;
        }
        if(rr_index >= srv->clis_count) {
            rr_index = 0;
        }
        for(int i = rr_index; i < srv->clis_count; ++i) {
            const t_cli_traverse_item * curr = srv->clis + i;
            if(curr) {
                const t_outbound_cli_ctx * ocli = (t_outbound_cli_ctx *)curr->cli;
                if(ocli && ocli->state[0] == 'A' && in_is_run_cli_ctx(curr->cli)) {
                    find_ctx =  curr->cli;
                    LOCK(find_ctx->mymutex);
                    rr_index = i+1;
                    goto GT_EXIT;
                }
            }
        }
        for(int i = 0; i < rr_index; ++i) {
            const t_cli_traverse_item * curr = srv->clis + i;
            if(curr) {
                const t_outbound_cli_ctx * ocli = (t_outbound_cli_ctx *)curr->cli;
                if(ocli && ocli->state[0] == 'A' && in_is_run_cli_ctx(curr->cli)) {
                    find_ctx =  curr->cli;
                    LOCK(find_ctx->mymutex);
                    rr_index = i+1;
                    goto GT_EXIT;
                }
            }
        }
        for(int i = rr_index; i < srv->clis_count; ++i) {
            const t_cli_traverse_item * curr = srv->clis + i;
            if(curr) {
                const t_outbound_cli_ctx * ocli = (t_outbound_cli_ctx *)curr->cli;
                if(ocli && ocli->state[0] == 'D' && in_is_run_cli_ctx(curr->cli)) {
                    find_ctx =  curr->cli;
                    LOCK(find_ctx->mymutex);
                    rr_index = i+1;
                    goto GT_EXIT;
                }
            }
        }
        for(int i = 0; i < rr_index; ++i) {
            const t_cli_traverse_item * curr = srv->clis + i;
            if(curr) {
                const t_outbound_cli_ctx * ocli = (t_outbound_cli_ctx *)curr->cli;
                if(ocli && ocli->state[0] == 'D' && in_is_run_cli_ctx(curr->cli)) {
                    find_ctx =  curr->cli;
                    LOCK(find_ctx->mymutex);
                    rr_index = i+1;
                    goto GT_EXIT;
                }
            }
        }
GT_EXIT:
        srv->rr_index = rr_index;
        UNLOCK(srv->mymutex);
        if(find_ctx) {
			int send_size = size;
			if(on_modify_data)
				send_size = on_modify_data(find_ctx, buf, size);
            if(wantStatistics) stat_o_inc_send(find_ctx->sid);
            if(find_ctx->on_send(find_ctx, buf, send_size) == IN_SUCCESS) {
                result = IN_SUCCESS;
                if(wantStatistics) stat_o_inc_send_succ(find_ctx->sid);
            }
            else {
                alarm_socket_error(&rec->oam, find_ctx->sid);
                result = IN_ERR_SOCK_SEND;                
                if(wantStatistics) stat_o_inc_send_fail(find_ctx->sid, ST_FAIL_REASON_SOCKET);
            }
            UNLOCK(find_ctx->mymutex);
        }
        else {
            LOGE("Can't find outnode session and not send. [%d]\n%s\n", size, buf);
            if(wantStatistics) {
                stat_o_inc_send_fail(0, ST_FAIL_REASON_CANT_FIND_SESSION);
            }
        }
    }
    return result;
}

/**
* Outbound update state
*/
IN_DECLARE(int) update_state(t_outbound_cli_ctx * cli, char state) {
    if(cli) {
        apr_atomic_cas32(&cli->cli.isrun, 2, 1);
        cli->state[0] = state;
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

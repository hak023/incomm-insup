#include "status.h"

typedef struct _t_status_rec t_status_rec;

struct _t_status_rec {
    char msg[MAX_STATUS_MSG];
};

/**
 * in_create_status_file
 * @return
 */
IN_DECLARE(t_status *) in_create_status_file(const char * name, apr_pool_t * pool) {
#ifdef FEATURE_STATUS_AS_SHM
    apr_status_t rv = apr_shm_remove(name, pool);
    apr_shm_t *shm = NULL;
    rv = apr_shm_create(&shm, sizeof(t_status_rec), name, pool);
    if (rv != APR_SUCCESS) {
        return NULL;
    }
    return (t_status *)shm;
#else
    apr_file_t * fd = NULL;
    apr_status_t rv = apr_file_open(&fd, name,
        APR_FOPEN_WRITE|APR_FOPEN_CREATE|APR_FOPEN_TRUNCATE, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE|APR_WREAD|APR_WWRITE, pool);
    if (rv != APR_SUCCESS) {
        return NULL;
    }
    return (t_status *)fd;
#endif
}

/**
 * in_destroy_status_file
 * @return
 */
IN_DECLARE(void) in_destroy_status_file(t_status * s, const char * name, apr_pool_t * pool) {
#ifdef FEATURE_STATUS_AS_SHM
    apr_shm_t * shm = (apr_shm_t *)s;
    if(shm)
        apr_shm_destroy(shm);
    apr_shm_remove(name, pool);
#else
    apr_file_t * fd = (apr_file_t *)s;
    if(fd)
        apr_file_close(fd);
    apr_file_remove(name, NULL);
#endif
}

/**
 * in_get_status_file
 * @return
 */
IN_DECLARE(int) in_get_status_file(const char * name, char * out, int out_size, apr_pool_t * pool) {
    out[0] = 0;
#ifdef FEATURE_STATUS_AS_SHM
    apr_shm_t *shm = NULL;
    apr_status_t rv = apr_shm_attach(&shm, name, pool);
    if (rv == APR_SUCCESS) {
        t_status_rec * rec = (t_status_rec *)apr_shm_baseaddr_get(shm);
        if(rec) {
            in_strncpy(out, rec->msg, out_size);
        }
        rv = apr_shm_detach(shm);
        return IN_SUCCESS;
    }    
#else
    apr_file_t * fd = NULL;
    apr_status_t rv = apr_file_open(&fd, name, APR_FOPEN_READ, APR_UREAD|APR_GREAD|APR_WREAD, pool);
    if(rv == APR_SUCCESS && fd) {
        apr_size_t nbytes = out_size;
        apr_file_read(fd, out, &nbytes);
        rv = apr_file_close(fd);
    }
#endif
    return IN_FAIL;
}

/**
 * in_set_status_file
 * @return
 */
IN_DECLARE(int) in_set_status_file(t_status * s, char * buf, int buf_size) {
#ifdef FEATURE_STATUS_AS_SHM
    apr_shm_t * shm = (apr_shm_t *)s;
    if(shm) {
        t_status_rec * rec = (t_status_rec *)apr_shm_baseaddr_get(shm);
        if(rec && sizeof(rec->msg) >= (unsigned)buf_size) {
            in_strncpy(rec->msg, buf, buf_size);
            return IN_SUCCESS;
        }
    }
#else
    apr_file_t * fd = (apr_file_t *)s;
    if(fd) {
        apr_off_t offset = 0;
        apr_file_seek(fd, APR_SET, &offset);
        apr_file_puts(buf, fd);
        apr_file_putc(0, fd);
    }
#endif
    return IN_FAIL;
}


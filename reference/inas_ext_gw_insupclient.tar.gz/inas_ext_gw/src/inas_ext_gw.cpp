#include "common.h"
#include "config.h"
#include "proc.h"
#include "logger.h"
#include "status.h"
#include "oam.h"
#include "statistics.h"
#include "plugin.h"
#include "iclient.h"
#include "oclient.h"
#include "servercontext.h"
#include "inas_ext_gw.h"

static void destroy_and_exit_process(int process_exit_value) {
    if(process_exit_value) {
        t_proc_rec * rec = get_proc_rec();
        if(rec == NULL) {
            printf("Already called exiting processing. [%d]\n", process_exit_value);
            return;        
        }
        apr_atomic_set32(&rec->isrun, 0);
        const t_conf * conf = in_get_conf_global_ref();            
        LOGS("Destroying '%s', exiting value is '%d'\n", rec->name, process_exit_value);
        LOGD("#- Destroying inbound\n");
        in_destory_warm_srv_ctx(rec->pollset, rec->isrv);
        LOGD("#- Destroy poolset\n");
        if(rec->pollset != NULL)
            apr_pollset_destroy(rec->pollset);
        rec->pollset = NULL;
        LOGD("#- Destroying outbound\n");
        in_destory_warm_srv_ctx(NULL, rec->osrv);
        LOGD("#- Destroy status\n");
        {
            char temporary_fd_name[D_PATH_SIZE] = {0,};
            in_strncpy(temporary_fd_name, rec->name, sizeof(temporary_fd_name));
            strcat(temporary_fd_name, ".rc");
            apr_file_remove(temporary_fd_name, NULL);
        }
        {
            char shm_name[D_PATH_SIZE] = {0,};
            in_strncpy(shm_name, rec->name, sizeof(shm_name));
            strcat(shm_name, ".status");
            in_destroy_status_file(rec->status, shm_name, rec->pool);
            rec->status = NULL;
        }
        LOGD("#- Destroy inbound server\n");
        in_destory_srv_ctx(rec->pollset, rec->isrv, false);
        LOGD("#- Destroy outbound server\n");
        in_destory_srv_ctx(NULL, rec->osrv, false);
        LOGD("#- Destroy accept lock\n");
        if(rec->accept_mutex)
            apr_thread_mutex_destroy(rec->accept_mutex);
        rec->accept_mutex = NULL;
        LOGD("#- Destroy conf\n");
        in_destroy_conf_global();
        LOGD("#- Unload plugin DSO\n");
        in_unload_plugin_dso(rec->hplug);
        rec->hplug = NULL;
        LOGD("#- Clear OAM\n");
        oam_send_info(&rec->oam, "{\"Op\":\"Shutdown\",\"Sys\":\"%s\",\"Proc\":\"%s\"}\r\n", conf->sys.name, rec->name);
        oam_clean_info(&rec->oam);
        LOGS("#- Destroy logger and exited\n");
        in_destroy_logger_global();
        in_remove_pid_info(rec);
        exit_stat();
        if(rec && rec->pool)  {
            apr_pool_destroy(rec->pool); 
            rec->pool = NULL;
        }
        /* apr_terminate(); */
        if(process_exit_value != 0) {
            printf("Exited %s\n", (rec && rec->name) ? rec->name : "");
        }    
#ifdef _DEBUG /* Dump allocator statistics to stderr. */
        malloc_stats_print(NULL, NULL, NULL);
#endif
    }
    exit(0);
}

static void atexit_cb(void) {
    destroy_and_exit_process(2);
}

static void usage(t_proc_rec * rec) {
    printf("usage: %s [-c=conf path]\n"
            "\toptions:\n"
            "\t\t-c=conf path   : start\n"
            "\t\t-s=status file : print status\n"
            "\t\t-r=pid         : reload config\n"
            "\t\t-h             : list available command line options\n"
            "\t\t-v=plugin file : show version number\n",
            rec->name);
    destroy_and_exit_process(0);
}

static void sig_soft_stop(int sig)
{
    printf("Invoked soft stop signal\n");
    LOGE("Invoked soft stop signal\n");
    destroy_and_exit_process(1);
    apr_signal(sig, SIG_IGN);
}

static void sig_term(int sig)
{
    char clog[128] = {0,};
    snprintf(clog, sizeof(clog), "Invoked '%d' Stop Signal\n", sig);
    puts(clog);
    LOGE("Invoked '%d' stop signal\n", sig);
    destroy_and_exit_process(1);
    apr_signal(sig, SIG_DFL);
}

static void sig_term_and_dump(int sig)
{
    sig_term(sig);
}

/**
* on_main_idle
* @oaram rec
* @return result
*/
static int IN_CALLBACK on_main_idle(t_proc_rec * rec, struct timespec curr_time) {
    static struct timespec last_check_time = {0,0};    
    apr_time_t elasped_time = (last_check_time.tv_sec) ? in_elasped_time2(last_check_time, curr_time) : 0;
    t_conf * conf = in_get_conf_global_ref();
    const t_stat * stat = stat_get();
    {
        int IN_CALLBACK on_outbound_connect(t_srv_ctx * osrv, bool is_all);
        on_outbound_connect(rec->osrv, false);
    }
    if(elasped_time < apr_time_from_msec(conf->manage.check_interval)) {
        if(last_check_time.tv_sec == 0)
            last_check_time = curr_time;
        return -1;
    }
    last_check_time = curr_time;
    apr_pool_t * temporary_pool = NULL;
    {
        apr_status_t rv = apr_pool_create(&temporary_pool, NULL);
        if (rv != APR_SUCCESS) {
            LOGE("Can't create temporary pool\n");
            return -1;
        }
    }          
    bool want_set_logger_info = false;
    { /* Reload config */
        char temporary_fd_name[D_PATH_SIZE] = {0,};
        in_strncpy(temporary_fd_name, rec->name, sizeof(temporary_fd_name));
        strcat(temporary_fd_name, ".rc");
        apr_file_t * fd = NULL;
        apr_status_t rv = apr_file_open(&fd, temporary_fd_name,
            APR_FOPEN_READ, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE, temporary_pool);
        if (rv == APR_SUCCESS && fd) {
            char cpid[64] = {0,};
            apr_file_gets(cpid, sizeof(cpid)-1, fd);
            apr_file_close(fd);
            apr_file_remove(temporary_fd_name, NULL);
            if(rec->pid == in_atoi(cpid)) {
                LOGS("Reload configuration '%s'\n", conf->path);
                in_reload_conf_info_global();
                want_set_logger_info = true;
            }
        }        
    }
    const t_srv_ctx * isrv = rec->isrv;
    static apr_uint64_t inbound_last_in_tot_count = 0, inbound_last_out_tot_count = 0;
    apr_int32_t inbound_cli_infos_num = 0;
    struct _inbound_cli_info {
        char name[D_NAME_SIZE];
        char state[2];
        apr_uint16_t sid;
        char str_begin_time[D_STR_TIME_SIZE];
        char ip_addr[D_STR_IPv4_SIZE];
        apr_uint64_t st_in_tot_count;
        apr_uint64_t st_out_tot_count;
    }inbound_cli_infos[D_MAX_SESSION+1];
    memset(inbound_cli_infos, 0, sizeof(inbound_cli_infos));
    struct {
        apr_uint64_t curr_in_tot_count;
        apr_uint64_t curr_out_tot_count;
        apr_uint64_t elasped_in_tot_count;
        apr_uint64_t elasped_out_tot_count;
    }inbound_cli_count = {0,0,0,0};
    apr_int32_t inbound_running_count = 0;
    if (isrv && isrv->mymutex) {
        LOCK(isrv->mymutex);
        for (int i = 0; i < isrv->clis_count; ++i) {
            const t_cli_traverse_item * curr = isrv->clis + i;
            const t_inbound_cli_ctx * icli = (t_inbound_cli_ctx *) curr->cli;
            const t_cli_ctx * cli = curr->cli;
            if (icli) {                
                const t_stat_client_item * statcli = stat->iclis + cli->sid;
                inbound_cli_count.curr_in_tot_count += statcli->recv_count;
                inbound_cli_count.curr_out_tot_count += statcli->send_count;
                if (inbound_cli_infos_num <= D_MAX_SESSION) {
                    struct _inbound_cli_info * ptr = inbound_cli_infos + inbound_cli_infos_num;
                    strncpy(ptr->name, icli->cli.name, sizeof(ptr->name));
                    ptr->state[0] = icli->state[0];
                    ptr->state[1] = 0;
                    ptr->sid = cli->sid;
                    strncpy(ptr->str_begin_time, icli->cli.str_begin_time, sizeof(ptr->str_begin_time));
                    strncpy(ptr->ip_addr, icli->cli.bind_ip_addr, sizeof(ptr->ip_addr));
                    ptr->st_in_tot_count = statcli->recv_count;
                    ptr->st_out_tot_count = statcli->send_count;
                    ++inbound_cli_infos_num;
                }
            }
        }
        UNLOCK(isrv->mymutex);
        if (inbound_last_in_tot_count && inbound_cli_count.curr_in_tot_count > inbound_last_in_tot_count) {
            inbound_cli_count.elasped_in_tot_count = inbound_cli_count.curr_in_tot_count - inbound_last_in_tot_count;
        }
        inbound_last_in_tot_count = inbound_cli_count.curr_in_tot_count;
        if (inbound_last_out_tot_count && inbound_cli_count.curr_out_tot_count > inbound_last_out_tot_count) {
            inbound_cli_count.elasped_out_tot_count = inbound_cli_count.curr_out_tot_count - inbound_last_out_tot_count;
        }
        inbound_last_out_tot_count = inbound_cli_count.curr_out_tot_count;
        inbound_running_count = (apr_int32_t)apr_thread_pool_busy_count(isrv->thd_pool);
    }
    const t_srv_ctx * osrv = rec->osrv;
    static apr_uint64_t outbound_last_in_tot_count = 0, outbound_last_out_tot_count = 0;
    apr_int32_t outbound_cli_infos_num = 0;
    struct _outbound_cli_info {
        bool used, running;
        char name[D_NAME_SIZE];
        char state[2];
        char str_begin_time[D_STR_TIME_SIZE];
        char ip_addr[D_STR_IPv4_SIZE];
        apr_uint16_t port;
        apr_uint64_t st_in_tot_count;
        apr_uint64_t st_out_tot_count;
    }outbound_cli_infos[D_MAX_SESSION+1];
    memset(outbound_cli_infos, 0, sizeof(outbound_cli_infos));
    struct {
        apr_uint64_t curr_in_tot_count;
        apr_uint64_t curr_out_tot_count;
        apr_uint64_t elasped_in_tot_count;
        apr_uint64_t elasped_out_tot_count;
    }outbound_cli_count = {0,0,0,0};
    apr_int32_t outbound_running_count = 0;
    if (osrv && osrv->mymutex) {
        for(int i = 0; i <= D_MAX_SESSION; ++ i) {
            outbound_cli_infos[i].used = conf->outbound[i].used;
            outbound_cli_infos[i].running = FALSE;
            if(conf->outbound[i].used) {
                const t_stat_client_item * statcli = stat->oclis + i;
                struct _outbound_cli_info * ptr = &outbound_cli_infos[i];
                strncpy(ptr->name, conf->outbound[i].name, sizeof(ptr->name));
                ptr->state[0] = 'N';
                ptr->state[1] = 0;
                ptr->str_begin_time[0] = 0;
                strncpy(ptr->ip_addr, conf->outbound[i].ipaddr, sizeof(ptr->ip_addr));
                ptr->port = conf->outbound[i].port;
                ptr->st_in_tot_count = statcli->recv_count;
                ptr->st_out_tot_count = statcli->send_count;
            }
        }
        LOCK(osrv->mymutex);
        for (int i = 0; i < osrv->clis_count; ++i) {
            const t_cli_traverse_item * curr = osrv->clis + i;
            const t_outbound_cli_ctx * ocli = (t_outbound_cli_ctx *) curr->cli;
            const t_cli_ctx * cli = curr->cli;
            if (ocli) {
                const t_stat_client_item * statcli = stat->oclis + cli->sid;
                outbound_cli_count.curr_in_tot_count += statcli->recv_succ_count;
                outbound_cli_count.curr_out_tot_count += statcli->send_succ_count;
                struct _outbound_cli_info * ptr = &outbound_cli_infos[cli->sid];
                ptr->running = TRUE;
                ptr->state[0] = ocli->state[0];
                ptr->state[1] = 0;
                strncpy(ptr->str_begin_time, ocli->cli.str_begin_time, sizeof(ptr->str_begin_time));                
                ++outbound_cli_infos_num;
            }
        }
        UNLOCK(osrv->mymutex);
        if (outbound_last_in_tot_count && outbound_cli_count.curr_in_tot_count > outbound_last_in_tot_count) {
            outbound_cli_count.elasped_in_tot_count = outbound_cli_count.curr_in_tot_count - outbound_last_in_tot_count;
        }
        outbound_last_in_tot_count = outbound_cli_count.curr_in_tot_count;
        if (outbound_last_out_tot_count && outbound_cli_count.curr_out_tot_count > outbound_last_out_tot_count) {
            outbound_cli_count.elasped_out_tot_count = outbound_cli_count.curr_out_tot_count - outbound_last_out_tot_count;
        }
        outbound_last_out_tot_count = outbound_cli_count.curr_out_tot_count;
        outbound_running_count = (apr_int32_t)apr_thread_pool_busy_count(osrv->thd_pool);
    }
    // Update status
    if(conf->status.disp_status)
    {
        char msg[MAX_STATUS_MSG] = {0,};
        char inbound_msg[(MAX_STATUS_MSG>>1)] = {0,};
        char outbound_msg[(MAX_STATUS_MSG>>1)] = {0,};
        char fault_msg[1024] = {0,};
        // Update Inbound Status
        if(conf->status.disp_status_inbound) {
            in_strncpy(inbound_msg, "| IN BOUND\n", sizeof(inbound_msg));
            char temp[512] = {0,};
            for(int i = 0; i < inbound_cli_infos_num && i <= D_MAX_SESSION; ++i) {
                snprintf(temp, sizeof(temp), ""
                        "- %-15.15s:%04d:%c | %-17s | %12lu | %12lu | %-15s\n",
                        inbound_cli_infos[i].name, inbound_cli_infos[i].sid, (inbound_cli_infos[i].state[0])?inbound_cli_infos[i].state[0]:'-',
                        (inbound_cli_infos[i].str_begin_time[0])?inbound_cli_infos[i].str_begin_time:"Unkwon",
                        inbound_cli_infos[i].st_in_tot_count, inbound_cli_infos[i].st_out_tot_count, inbound_cli_infos[i].ip_addr);
                strcat(inbound_msg, temp);
            }
        }
        // Update Outbound Status
        if(conf->status.disp_status_outbound) {
            in_strncpy(outbound_msg, "| OUTBOUND\n", sizeof(inbound_msg));
            char temp[512] = {0,};
            for(int i = 0; i <= D_MAX_SESSION; ++i) {
                if(outbound_cli_infos[i].running) {
                    snprintf(temp, sizeof(temp), ""
                            "- %-15.15s:%04d:%c | %-17s | %12lu | %12lu | %-15s:%d\n",
                            outbound_cli_infos[i].name, i, (outbound_cli_infos[i].state[0])?outbound_cli_infos[i].state[0]:'-',
                            (outbound_cli_infos[i].str_begin_time[0])?outbound_cli_infos[i].str_begin_time:"Unkwon",
                            outbound_cli_infos[i].st_in_tot_count, outbound_cli_infos[i].st_out_tot_count, outbound_cli_infos[i].ip_addr, outbound_cli_infos[i].port);
                    strcat(outbound_msg, temp);
                }
            }
        }
        // Update FAIL count
        if(conf->status.disp_status_fail_count) {
            const t_stat * st = stat_get();
            char temp[512] = {0,};
            snprintf(temp, sizeof(temp), "| FREASONS\n"
                "R %12lu | %12lu | %12lu | %12lu | %12lu | %12lu | %12lu | %12lu\n",
                st->recv_fail_reasons[0], st->recv_fail_reasons[1], st->recv_fail_reasons[2], st->recv_fail_reasons[3], st->recv_fail_reasons[4], st->recv_fail_reasons[5], st->recv_fail_reasons[6], st->recv_fail_reasons[7]);
            strcat(fault_msg, temp);
            snprintf(temp, sizeof(temp), 
                "S %12lu | %12lu | %12lu | %12lu | %12lu | %12lu | %12lu | %12lu\n",
                st->send_fail_reasons[0], st->send_fail_reasons[1], st->send_fail_reasons[2], st->send_fail_reasons[3], st->send_fail_reasons[4], st->send_fail_reasons[5], st->send_fail_reasons[6], st->send_fail_reasons[7]);            
            strcat(fault_msg, temp);
        }
        // Modulate
        static double inbound_max_rps = 0., inbound_max_tps = 0, outbound_max_rps = 0., outbound_max_tps = 0;
        const double elasped_sec = elasped_time/1000000.f;
        const double inbound_curr_rps = (elasped_time) ? inbound_cli_count.elasped_in_tot_count/elasped_sec : 0.f;
        const double inbound_curr_tps = (elasped_time) ? inbound_cli_count.elasped_out_tot_count/elasped_sec : 0.f;
        inbound_max_rps = (inbound_curr_rps > inbound_max_rps) ? inbound_curr_rps : inbound_max_rps;
        inbound_max_tps = (inbound_curr_tps > inbound_max_tps) ? inbound_curr_tps : inbound_max_tps;
        const double outbound_curr_rps = (elasped_time) ? outbound_cli_count.elasped_in_tot_count/elasped_sec : 0.f;
        const double outbound_curr_tps = (elasped_time) ? outbound_cli_count.elasped_out_tot_count/elasped_sec : 0.f;
        outbound_max_rps = (outbound_curr_rps > outbound_max_rps) ? outbound_curr_rps : outbound_max_rps;
        outbound_max_tps = (outbound_curr_tps > outbound_max_tps) ? outbound_curr_tps : outbound_max_tps;
        snprintf(msg, sizeof(msg),
                "| Proc. Name\t= %s\n"
                "| Version\t= %s\n"
                "| Built\t\t= %s\n"
                "| Plugin Ver.\t= %s\n"
                "| Plugin Blt.\t= %s\n"
                "\n"
                "| Sys Info.\t='%s'[%c]\n"
                "| Process Info.\t='%s'[%c]\n"
                "\n"
                "| Start Time\t= %s\n"
                "- Listen Port\t= %d\n"
                "| I-SIPSRV\t= %-3d / %-3d | %u Try\n"
                "- TPS\t\t= R%.2f(M%.2f) T%.2f(M%.2f)\n"
                "| O-EXTERN\t= %-3d / %-3d | %u Try\n"                
                "- TPS\t\t= R%.2f(M%.2f) T%.2f(M%.2f)\n"
                "\n",
                rec->name,
                get_pkg_version(), get_pkg_built(), 
                get_plugin_version(), get_plugin_built(),
                conf->sys.name, conf->sys.state[0],
                conf->proc.srcid, conf->proc.state[0],
                rec->begin_time,
                (isrv) ? isrv->port : 0,
                inbound_running_count, conf->inbound_num, (isrv) ? isrv->st_tot_accept_count : 0,
                inbound_curr_rps, inbound_max_rps, inbound_curr_tps, inbound_max_tps,
                outbound_running_count, conf->outbound_num, (osrv) ? osrv->st_tot_accept_count : 0,                
                outbound_curr_rps, outbound_max_rps, outbound_curr_tps, outbound_max_tps);
        if(conf->status.disp_status_fail_count) {
            strcat(msg, fault_msg);
            strcat(msg, "\n");
        }
        if(conf->status.disp_status_inbound) {
            strcat(msg, inbound_msg);
            strcat(msg, "\n");
        }
        if(conf->status.disp_status_outbound) {
            strcat(msg, outbound_msg);
            strcat(msg, "\n");
        }
        in_set_status_file(rec->status, msg, sizeof(msg));
    }
    if(conf->oam.use_send_dgram_feature) {
        char msg[2048] = {0,};
        char temp1[1024] = {0,}, temp2[1024] = {0,};
        // 1. Send Process Status
        for(int i = 0; i < inbound_cli_infos_num && i <= D_MAX_SESSION; ++i) {
            char tmp[16] = {0,};
            in_utoa(tmp, inbound_cli_infos[i].sid);
            strncat(temp1, tmp, sizeof(temp1));
            strncat(temp1, ",", sizeof(temp1));
        } in_rtrim(temp1, ',');
        for(int i = 0; i <= D_MAX_SESSION; ++i) {
            char tmp[16] = {0,};
            if(outbound_cli_infos[i].running) {
                in_utoa(tmp, i);
                strncat(temp2, tmp, sizeof(temp2));
                strncat(temp2, ",", sizeof(temp2));
            }
        } in_rtrim(temp2, ',');        
        snprintf(msg, sizeof(msg), "{\"Op\":\"Info\",\"Sys\":\"%s\",\"Proc\":\"%s\","
                                    "\"Ver\":[\"%s\",\"%s\"],"
                                    "\"Start\":\"%s\","
                                    "\"Listen\":%d,"
                                    "\"Inum\":[%u,%u],"
                                    "\"Onum\":[%u,%u],"
                                    "\"Iids\":[%s],"
                                    "\"Oids\":[%s]"
                                    "}\r\n",
                conf->sys.name, rec->name,
                get_pkg_version(), get_plugin_version(),
                rec->begin_time,
                (isrv) ? isrv->port : 0,
                inbound_running_count, conf->inbound_num,
                outbound_running_count, conf->outbound_num,
                temp1, temp2);
        oam_send_info(&rec->oam, msg);
        // 2. Send Clients Traffic
        for(int i = 0; i < inbound_cli_infos_num && i <= D_MAX_SESSION; ++i) {
            const apr_uint16_t sid = inbound_cli_infos[i].sid;
            const t_stat_client_item * statcli = stat->iclis + sid;
            snprintf(msg, sizeof(msg), "{\"Op\":\"IStat\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"State\":\"%c\",", 
                conf->sys.name, rec->name, inbound_cli_infos[i].state[0]);
            snprintf(temp1, sizeof(temp1), "\"SessId\":%d,", sid);
            strncat(msg, temp1, sizeof(msg));
            snprintf(temp1, sizeof(temp1), "\"Ip\":\"%s\",", inbound_cli_infos[i].ip_addr);
            strncat(msg, temp1, sizeof(msg));
            snprintf(temp1, sizeof(temp1), "\"Start\":\"%s\",", inbound_cli_infos[i].str_begin_time);
            strncat(msg, temp1, sizeof(msg));
            snprintf(temp1, sizeof(temp1), "\"Values\":[%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu]",
                statcli->recv_count, statcli->recv_succ_count, statcli->recv_fail_count,
                statcli->send_count, statcli->send_succ_count, statcli->send_fail_count,
                statcli->recv_fail_reasons[0],statcli->recv_fail_reasons[1],statcli->recv_fail_reasons[2],statcli->recv_fail_reasons[3],
                statcli->recv_fail_reasons[4],statcli->recv_fail_reasons[5],statcli->recv_fail_reasons[6],statcli->recv_fail_reasons[7],
                statcli->send_fail_reasons[0],statcli->send_fail_reasons[1],statcli->send_fail_reasons[2],statcli->send_fail_reasons[3],
                statcli->send_fail_reasons[4],statcli->send_fail_reasons[5],statcli->send_fail_reasons[6],statcli->send_fail_reasons[7]);
            strncat(msg, temp1, sizeof(msg));
            strncat(msg, "}\r\n", sizeof(msg));
            oam_send_info(&rec->oam, msg);
        }
        for(int i = 0; i <= D_MAX_SESSION; ++i) {
            if(outbound_cli_infos[i].used) {
                const t_stat_client_item * statcli = stat->oclis + i;
                snprintf(msg, sizeof(msg), "{\"Op\":\"OStat\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"State\":\"%c\",", 
                    conf->sys.name, rec->name, outbound_cli_infos[i].state[0]);
                snprintf(temp1, sizeof(temp1), "\"SessId\":%d,", i);
                strncat(msg, temp1, sizeof(msg));
                snprintf(temp1, sizeof(temp1), "\"Ip\":\"%s\",", outbound_cli_infos[i].ip_addr);
                strncat(msg, temp1, sizeof(msg));
                snprintf(temp1, sizeof(temp1), "\"Start\":\"%s\",", outbound_cli_infos[i].str_begin_time);
                strncat(msg, temp1, sizeof(msg));
                snprintf(temp1, sizeof(temp1), "\"Values\":[%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu]",
                    statcli->recv_count, statcli->recv_succ_count, statcli->recv_fail_count,
                    statcli->send_count, statcli->send_succ_count, statcli->send_fail_count,
                    statcli->recv_fail_reasons[0],statcli->recv_fail_reasons[1],statcli->recv_fail_reasons[2],statcli->recv_fail_reasons[3],
                    statcli->recv_fail_reasons[4],statcli->recv_fail_reasons[5],statcli->recv_fail_reasons[6],statcli->recv_fail_reasons[7],
                    statcli->send_fail_reasons[0],statcli->send_fail_reasons[1],statcli->send_fail_reasons[2],statcli->send_fail_reasons[3],
                    statcli->send_fail_reasons[4],statcli->send_fail_reasons[5],statcli->send_fail_reasons[6],statcli->send_fail_reasons[7]);
                strncat(msg, temp1, sizeof(msg));
                strncat(msg, "}\r\n", sizeof(msg));
                oam_send_info(&rec->oam, msg);
            }
        }        
    }        
    if(conf->oam.use_oam_info_file) {
        oam_load_info_file(rec->name, &rec->oam, temporary_pool, true);
    }   
    in_check_and_rolling_logger_global();
    if(want_set_logger_info) {
        in_set_logger_info_global(conf->logger.log_level, conf->logger.max_count, conf->logger.max_size);
    }
    LOGS("[%c] Inbound(%d/%d), Outbound(%d/%d)\n",
            conf->sys.state[0] == 'B' ? 'B' : conf->proc.state[0],
            inbound_running_count, conf->inbound_num, outbound_running_count, conf->outbound_num);
    if(temporary_pool) {
        apr_pool_destroy(temporary_pool); 
    } 
    return IN_SUCCESS;
}

/**
* on_inbound_accept
* @oaram t_srv_ctx *
* @oaram apr_socket_t *
*/
int IN_CALLBACK on_inbound_accept(t_srv_ctx * isrv) {
    apr_status_t rv;
    apr_socket_t * csock;
    apr_pool_t * conn_pool = NULL;
    apr_allocator_t * conn_pool_allocator = NULL;
    rv = in_pool_create(&conn_pool, &conn_pool_allocator, isrv->pool);
    rv = apr_socket_accept(&csock, isrv->sock, conn_pool);
    if (rv == APR_SUCCESS) {
        char * addr = NULL;
        apr_sockaddr_t * sa = NULL;
        ++isrv->st_tot_accept_count;
        apr_socket_addr_get(&sa, APR_REMOTE, csock);
        apr_sockaddr_ip_get(&addr, sa);
        apr_int32_t running_count = (apr_int32_t)apr_thread_pool_busy_count(isrv->thd_pool);
        if(running_count >= isrv->max_connection) {
            LOGE("Accepted[%d][Busy Thd Number=%d] over the max connection '%s'\n", isrv->port, running_count, (addr) ? addr : "");
            APR_SAFE_CLOSE_SOCKET(csock);
            in_pool_destroy(conn_pool, conn_pool_allocator);
            return IN_FAIL;
        }
        LOGI1("Accepted[%d] ip addr '%s'\n", isrv->port, (addr) ? addr : "");
        t_cli_ctx * cli = in_create_cli_ctx(
                "READY", 0, sizeof(t_inbound_cli_ctx),
                csock, conn_pool, conn_pool_allocator, isrv,
                (t_cli_ctx_attach_callback)on_inbound_cli_attach, (t_cli_ctx_detach_callback)on_inbound_cli_detach,
                (t_cli_ctx_recv_callback)on_inbound_cli_recv, (t_cli_ctx_send_callback)on_inbound_cli_send,
                (t_cli_ctx_idle_callback)on_inbound_cli_idle, isrv->pool);
        if(cli == NULL) {
            LOGE("Accepted[%d] failed create client\n", isrv->port);
            APR_SAFE_CLOSE_SOCKET(csock);
            in_pool_destroy(conn_pool, conn_pool_allocator);
            return IN_FAIL;
        }
        LOCK(isrv->mymutex); /* 2015.08.08 */
        rv = apr_thread_pool_push(isrv->thd_pool, in_on_task_cli_ctx, (void *)cli, 0, NULL);
        if(rv != APR_SUCCESS) {
            UNLOCK(isrv->mymutex);
            in_destroy_cli_ctx(cli);
            LOGE("Accepted[%d] failed attach thread\n", isrv->port);
            return IN_FAIL;
        }
        UNLOCK(isrv->mymutex);
    }
    return IN_SUCCESS;
}

/**
* on_outbound_connect
* @oaram t_srv_ctx *
* @oaram apr_socket_t *
*/
int IN_CALLBACK on_outbound_connect(t_srv_ctx * osrv, bool is_all) {
    if(osrv == NULL)
        return IN_SUCCESS;
    apr_status_t rv;
    apr_int32_t running_count = (apr_int32_t)apr_thread_pool_busy_count(osrv->thd_pool);
    if(running_count >= osrv->max_connection) {
        return IN_SUCCESS;
    }
    const t_conf * conf = in_get_conf_global_ref();
    if(is_all) {
        for(int sid = 1; sid <= D_MAX_SESSION; ++sid) {
            if(conf->outbound[sid].used) {
                ++osrv->st_tot_accept_count;
                char cname[D_NAME_SIZE];
                strncpy(cname, conf->outbound[sid].name, sizeof(cname));
                LOGI1("Connecting '%s' ip addr '%s:%d'. SID[%d]\n", cname, conf->outbound[sid].ipaddr, conf->outbound[sid].port, sid);                
                t_cli_ctx * cli = in_create_cli_ctx_with_connect(
                        cname, sid, sizeof(t_outbound_cli_ctx), conf->outbound[sid].ipaddr, conf->outbound[sid].port, osrv,
                        (t_cli_ctx_attach_callback)on_outbound_cli_attach, (t_cli_ctx_detach_callback)on_outbound_cli_detach,
                        (t_cli_ctx_recv_callback)on_outbound_cli_recv, (t_cli_ctx_send_callback)on_outbound_cli_send,
                        (t_cli_ctx_idle_callback)on_outbound_cli_idle, osrv->pool);
                if(cli == NULL) {
                    LOGE("Connecting failed create client\n");
                    continue;
                }
                LOCK(osrv->mymutex);
                rv = apr_thread_pool_push(osrv->thd_pool, in_on_task_cli_ctx, (void *)cli, 0, NULL);
                if(rv != APR_SUCCESS) {
                    UNLOCK(osrv->mymutex);
                    in_destroy_cli_ctx(cli);
                    LOGE("Connecting '%s' failed attach thread\n", cli->name);
                    continue;
                }
                UNLOCK(osrv->mymutex);
                LOGI1("Connected '%s' ip addr '%s:%d'. SID[%d]\n", cname, conf->outbound[sid].ipaddr, conf->outbound[sid].port, cli->sid);
            }
        }
    }
    else {
        int sid, i;
        LOCK(osrv->mymutex);
        sid = (osrv->re_index>D_MAX_SESSION) ? 1 : osrv->re_index;
        for(; sid <= D_MAX_SESSION; ++sid) {
            if(conf->outbound[sid].used) {
                for(i = 0; i < osrv->clis_count; ++i) {
                    t_cli_traverse_item * curr = osrv->clis + i;
                    t_outbound_cli_ctx * ocli = (t_outbound_cli_ctx *)curr->cli;
                    if(sid == ocli->cli.sid) {
                        break;
                    }
                }
                if(i == osrv->clis_count) {
                    break;
                }
            }
        }
        osrv->re_index = sid+1;
        UNLOCK(osrv->mymutex);
        if(sid <= D_MAX_SESSION) {
            ++osrv->st_tot_accept_count;
            char cname[D_NAME_SIZE];
            strncpy(cname, conf->outbound[sid].name, sizeof(cname));
            LOGI1("Reconnecting '%s' ip addr '%s:%d'. SID[%d]\n", cname, conf->outbound[sid].ipaddr, conf->outbound[sid].port, sid);
            t_cli_ctx * cli = in_create_cli_ctx_with_connect(
                    cname, sid, sizeof(t_outbound_cli_ctx), conf->outbound[sid].ipaddr, conf->outbound[sid].port, osrv,
                    (t_cli_ctx_attach_callback)on_outbound_cli_attach, (t_cli_ctx_detach_callback)on_outbound_cli_detach,
                    (t_cli_ctx_recv_callback)on_outbound_cli_recv, (t_cli_ctx_send_callback)on_outbound_cli_send,
                    (t_cli_ctx_idle_callback)on_outbound_cli_idle, osrv->pool);
            if(cli == NULL) {
                LOGE("Reconnecting failed create client\n");
                return IN_FAIL;
            }
            LOCK(osrv->mymutex);
            rv = apr_thread_pool_push(osrv->thd_pool, in_on_task_cli_ctx, (void *)cli, 0, NULL);
            if(rv != APR_SUCCESS) {
                UNLOCK(osrv->mymutex);
                in_destroy_cli_ctx(cli);
                LOGE("Reconnecting '%s' failed attach thread\n", cli->name);
                return IN_FAIL;
            }
            UNLOCK(osrv->mymutex);
            LOGI1("Reconnected '%s' ip addr '%s:%d'. SID[%d]\n", cname, conf->outbound[sid].ipaddr, conf->outbound[sid].port, cli->sid);
        }
    }
    return IN_SUCCESS;
}

/**
 * INAS EXT GW main
 * @return
 */
int main(int argc, const char * const * argv) {
    apr_pool_t * cntx;
    apr_status_t rv;
    const char * failed = "Apr_app_initialize()";

    rv = apr_app_initialize(&argc, &argv, NULL);
    if (rv == APR_SUCCESS) {
        failed = "Apr_pool_create()";
        rv = apr_pool_create(&cntx, NULL);
    }

    if (rv != APR_SUCCESS) {
        char ctimebuff[APR_CTIME_LEN];
        apr_ctime(ctimebuff, apr_time_now());
        fprintf((FILE*)stderr, "[%s] [CRIT] (%d) %s: '%s' Failed "
                "to initial context, exiting\n", ctimebuff, rv, argv[0], failed);
        apr_terminate();
        exit(1);
    }

    printf("\n");

    t_proc_rec * rec = get_proc_rec_ref();
    rec->pool = cntx;
    in_strncpy(rec->name, apr_filepath_name_get((argv)[0]), sizeof(rec->name));
    apr_pool_tag(cntx, rec->name);

#if 0
    char conf_path[D_PATH_SIZE] = "../../cfg/ext_gw_ingw.cfg";
#else
    char conf_path[D_PATH_SIZE] = {0,};
#endif
    if (argc == 2) {
        if (strncmp((argv)[1], "-v", 2) == 0) {
            char plugin_path[D_PATH_SIZE] = {0,};
            const char * cv = strchr((argv)[1], '=');
            if(cv == NULL) {
                usage(rec);
            }
            in_strncpy(plugin_path, cv+1, sizeof(plugin_path));
            in_trim(plugin_path, ' ');
            int rv = in_load_plugin_dso(plugin_path, NULL, NULL, NULL, rec->pool);
            if(rv == IN_SUCCESS) {
                printf("App - Version = '%s', Built = '%s'\n"
                       "Plugin - Version = '%s', Built = '%s'\n", 
                       get_pkg_version(), get_pkg_built(), get_plugin_version(), get_plugin_built());
                in_unload_plugin_dso(rec->hplug);
            }
            else {
                printf("App - Version = '%s', Built = '%s'\n"
                       "Plugin - Version = '%s', Built = '%s'\n", 
                       get_pkg_version(), get_pkg_built(), "Unknown", "Unknown");
            }
            destroy_and_exit_process(0);
        } else if (strncmp((argv)[1], "-r", 2) == 0) {
            char cpid[64] = {0,};
            const char * cv = strchr((argv)[1], '=');
            if(cv == NULL) {
                usage(rec);
            }
            in_strncpy(cpid, cv+1, sizeof(cpid));
            int pid = atoi(cpid);            
            if (pid) {
                char clog[128] = {0,};
                snprintf(clog, sizeof(clog), "Invoke reload config, PID=%d\n", pid);
                puts(clog);
                in_itoa(cpid, pid);
                char temporary_fd_name[D_PATH_SIZE] = {0,};
                in_strncpy(temporary_fd_name, rec->name, sizeof(temporary_fd_name));
                strcat(temporary_fd_name, ".rc");
                apr_file_t * fd = NULL;
                apr_status_t rv = apr_file_open(&fd, temporary_fd_name,
                    APR_FOPEN_WRITE|APR_FOPEN_CREATE, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE, rec->pool);
                if (rv == APR_SUCCESS && fd) {
                    apr_file_puts(cpid, fd);
                    apr_file_close(fd);
                }
            }
            destroy_and_exit_process(0);
        } else if (strncmp((argv)[1], "-h", 2) == 0) {
            usage(rec);
        } else if (strncmp((argv)[1], "-c", 2) == 0) {
            const char * cv = strchr((argv)[1], '=');
            if(cv == NULL) {
                usage(rec);
            }
            in_strncpy(conf_path, cv+1, sizeof(conf_path));
            in_trim(conf_path, ' ');
        } else if (strncmp((argv)[1], "-s", 2) == 0) {
            char cstatuspath[D_PATH_SIZE] = {0,};
            const char * cv = strchr((argv)[1], '=');
            if(cv == NULL) {
                usage(rec);
            }
            in_strncpy(cstatuspath, cv+1, sizeof(cstatuspath));
            in_trim(cstatuspath, ' ');
            char msg[MAX_STATUS_MSG] = {0,};
            in_get_status_file(cstatuspath, msg, sizeof(msg), rec->pool);
            printf("%s", msg);
            destroy_and_exit_process(0);
        }
        else {
            usage(rec);
        }
    }
    else {
#ifdef _RELEASE
        usage(rec);
#endif
    }
    if(strlen(conf_path) == 0) {
        usage(rec);
    }
    {
        const int noldpid = in_get_running_old_pid(rec);
        if(noldpid) {
            fprintf((FILE*)stderr, "Old pid('%d') is running and exiting\n", noldpid);
            destroy_and_exit_process(0);
        }
        if(in_generate_pid_info(rec) == false) {
            fprintf((FILE*)stderr, "Create pid file failed and exiting\n");
            destroy_and_exit_process(0);
        }
    }
    apr_atomic_set32(&rec->isrun, 1);
    rec->destroy_process = destroy_and_exit_process;
    t_conf * conf = NULL;
    {
        conf = in_create_conf_global(conf_path, rec->pool);
        if(conf == NULL) {
            fprintf((FILE*)stderr, "Create conf failed and exiting\n");
            destroy_and_exit_process(1);
        }
        rec->conf = conf;
    }
    {
        if(oam_init_info(&rec->oam, rec->pool) != IN_SUCCESS) {
            fprintf((FILE*)stderr, "Init OAM failed and exiting\n");
            destroy_and_exit_process(1);
        }
    }
    {
        t_logger * logger = in_create_logger(
                conf->logger.log_path, conf->logger.rolling, conf->logger.log_level, conf->logger.max_count, conf->logger.max_size, rec->pool);
        if(logger == NULL) {
            fprintf((FILE*)stderr, "Create app logger failed and exiting\n");
            destroy_and_exit_process(1);
        }
        in_set_global_logger(logger);
    }
    if(conf->oam.use_oam_info_file) {
        rv = oam_load_info_file(rec->name, &rec->oam, rec->pool, false);
        if(rv != IN_SUCCESS) {
            fprintf((FILE*)stderr, "Can not load oam setting JSON file and exiting\n");
            destroy_and_exit_process(1);
        }
    }
    {
        t_plugin_handle plug;
        memset(&plug, 0, sizeof(t_plugin_handle));
        strncpy(plug.conf_path, conf_path, sizeof(plug.conf_path));
        plug.isend = (int (*)(t_cli_ctx * , const char * , const char * , apr_size_t ))inbound_send;
        plug.isend_sig = inbound_send_sig;
        plug.osend = (int (*)(t_cli_ctx * , const char * , apr_size_t , int ))outbound_send;
        plug.osend_rr = outbound_send_rr;
        plug.update_state = (int (*)(t_cli_ctx * , char ))update_state;
        rv = in_load_plugin_dso(conf->plugin.path, conf->plugin.name, &rec->hplug, &plug, rec->pool);
        if(rv != IN_SUCCESS) {
            fprintf((FILE*)stderr, "Can not load plugin dso and exiting\n");
            destroy_and_exit_process(1);
        }
    }
    {
        char shm_name[D_PATH_SIZE] = {0,};
        in_strncpy(shm_name, rec->name, sizeof(shm_name));
        strcat(shm_name, ".status");
        rec->status = in_create_status_file(shm_name, rec->pool);
    }
    {
        if(init_stat(rec->pool) != IN_SUCCESS) {
            destroy_and_exit_process(1);
        }
    }    
    rv = apr_pollset_create(&rec->pollset, 1, rec->pool, 0);
    if(rv != APR_SUCCESS) {
        fprintf((FILE*)stderr, "Can not create main pollset and exiting\n");
        destroy_and_exit_process(1);
    }
    rv = apr_thread_mutex_create(&rec->accept_mutex, APR_THREAD_MUTEX_DEFAULT, rec->pool);
    if(rv != APR_SUCCESS) {
        fprintf((FILE*)stderr, "Can not create accept lock and exiting\n");
        destroy_and_exit_process(1);
    }
    if(rv != APR_SUCCESS) {
        fprintf((FILE*)stderr, "Can not create main pollset and exiting\n");
        destroy_and_exit_process(1);
    }
    if(conf->outbound_num) {
        rec->osrv =
            in_create_cli_ctx_pool(rec->name, conf->outbound_num, rec->pool);
        if(rec->osrv == NULL) {
            fprintf((FILE*)stderr, "Can not create main osrv and exiting\n");
            destroy_and_exit_process(1);
        }
        on_outbound_connect(rec->osrv, true);
    }
    rec->isrv =
        in_create_srv_ctx(rec->pollset, rec->name, conf->server.port, conf->server.max_connection, on_inbound_accept, rec->pool);
    if(rec->isrv == NULL) {
        fprintf((FILE*)stderr, "Can not create main isrv and exiting\n");
        destroy_and_exit_process(1);
    } 
#if defined SIGHUP
    apr_signal(SIGHUP, sig_term);
#endif
#if defined SIGINT
    apr_signal(SIGINT, sig_term);
#endif
#if defined SIGILL
    apr_signal(SIGILL, SIG_DFL);
#endif
#if defined SIGQUIT
    apr_signal(SIGQUIT, sig_term_and_dump);
#endif
#if defined SIGABRT
    apr_signal(SIGABRT, SIG_DFL);
#endif
#if defined SIGBUS
    apr_signal(SIGBUS, SIG_DFL);
#endif
#if defined SIGFPE
    apr_signal(SIGFPE, SIG_DFL);
#endif
#if defined SIGSEGV
    apr_signal(SIGSEGV, SIG_DFL);
#endif
#if defined SIGTERM
    apr_signal(SIGTERM, sig_term);
#endif
#if defined SIGUSR1
    apr_signal(SIGUSR1, sig_soft_stop);
#endif
#if defined SIGURG
    apr_signal(SIGURG, SIG_DFL);
#endif
#if defined SIGPIPE
    apr_signal(SIGPIPE, SIG_IGN);
#endif
    in_desc_conf(conf);
    printf("Start %s, Version = '%s', Built = '%s'\n", rec->name, get_pkg_version(), get_pkg_built());
    LOGS("Start '%s'\nVersion = '%s', Built = '%s'\n", rec->name, get_pkg_version(), get_pkg_built());
    oam_send_info(&rec->oam, "{\"Op\":\"Startup\",\"Sys\":\"%s\",\"Proc\":\"%s\"}\r\n", conf->sys.name, rec->name);
    struct timespec now = in_begin_time2();
    char str_begin_time[D_STR_TIME_SIZE];
    in_time_to_string(str_begin_time, sizeof(str_begin_time), "%Y/%m/%d-%H:%M:%S", apr_time_now());
    strncpy(rec->begin_time, str_begin_time+2, sizeof(rec->begin_time));
    atexit(atexit_cb);
    for(;;) {
        apr_int32_t num = 0;
        const apr_pollfd_t * retfd = NULL;
        const apr_time_t timeout = 1000000L;
        LOCK(rec->accept_mutex);
        rv = apr_pollset_poll(rec->pollset, timeout, &num, &retfd);
        if (rv == APR_SUCCESS) {
            bool want_exit = FALSE;
            for (int i = 0; i < num; i++) {
                const apr_pollfd_t * fd = retfd + i;
                apr_int16_t rtnevents = fd->rtnevents;
                if ((rtnevents & APR_POLLIN) || (rtnevents & APR_POLLPRI) || (rtnevents & APR_POLLHUP)) {
                    t_srv_ctx * srv = (t_srv_ctx *) fd->client_data;
                    if (srv == rec->isrv && rec->isrv->on_accept) {
                        rec->isrv->on_accept(srv);
                    }
                } else if ((rtnevents & APR_POLLERR) || (rtnevents & APR_POLLNVAL)) {
                    t_srv_ctx * srv = (t_srv_ctx *) fd->client_data;
                    if (srv) {
                        LOGE("[%s] Descriptor invalid or pending error\n", srv->name);
                    } else {
                        LOGE("[Unknown] Invalid descriptor or pending error\n");
                    }
                }
            }
            if (want_exit) {
                UNLOCK(rec->accept_mutex);
                break;
            }
        } else if (rv == APR_TIMEUP) {
            now = in_begin_time2();
            on_main_idle(rec, now);
            goto GT_CONT;
        }
        if (in_elasped_time2(now, in_clock_time2()) > timeout) {
            now = in_begin_time2();
            on_main_idle(rec, now);
        }
GT_CONT:
        UNLOCK(rec->accept_mutex);
#ifdef _DEBUG
        LOGV("[%c] Result(%d), Poll(%d)\n", conf->sys.state[0], rv, num);
#endif
    }    
    return 0;
}

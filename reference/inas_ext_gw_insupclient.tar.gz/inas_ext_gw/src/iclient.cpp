#include "common.h"
#include "logger.h"
#include "config.h"
#include "oam.h"
#include "proc.h"
#include "statistics.h"
#include <inas/inas_internal_proto.h>
#include <json/json.h>
#include "iclient.h"

using namespace std;
using namespace Json;

static inline apr_int32_t send_result(t_inbound_cli_ctx * icli,
        const char * op,
        const char * tid,
        const apr_uint16_t sid,        
        const char * svcid,
        const char * srcid,
        const int result,
        const char * desc,
        const bool logging = TRUE) {
    char out[P_BUFFER_SIZE] = {0, };
    char op_rsp[10+1] = {0, };
    strncpy(op_rsp, op, sizeof(op_rsp));
    strncat(op_rsp, P_HDR_OP_RSP_TAG, sizeof(op_rsp));
    apr_int32_t sendsize = make_cmd_hdr(out, sizeof(out),
            op_rsp, tid, sid, svcid, srcid,
            "{"
            "\"Stat\":\"%c\","
            "\"Result\":%d,"
            "\"Desc\":\"%s\""
            "}",
            icli->state[0], result, desc);
    int rv = IN_FAIL;
    if(sendsize > 0 && (rv = icli->cli.on_send(&icli->cli, out, sendsize)) == IN_SUCCESS) {
        if(logging)
            LOGI1K(tid, "[%s|%04d] Inbound send. [%d]\n%s\n", icli->cli.name, icli->cli.sid, sendsize, out);
        else
            LOGV("[%s|%04d] Inbound send. [%d]\n%s\n", icli->cli.name, icli->cli.sid, sendsize, out);
    }
    else {
        LOGEK(tid, "[%s|%04d] Inbound send. %d [%d]\n%s\n", icli->cli.name, icli->cli.sid, rv, sendsize, out);
    }    
    return rv;
}

/**
* on_inbound_cli_process
*/
static inline apr_int32_t on_inbound_cli_process(t_inbound_cli_ctx * icli, char * buf, apr_size_t size) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) {
        return IN_FAIL;
    }
    apr_int32_t rv = IN_SUCCESS;
    const apr_time_t rtime = apr_time_now();    
    char proto_op[P_HDR_OP_SIZE+1] = {0,};
    char proto_tid[P_HDR_TID_SIZE+1] = {0,};
    apr_uint16_t proto_sid = 0;
    char proto_svcid[P_HDR_SVC_SIZE+1] = {P_HDR_UNKWON_SVC_ID};
    char proto_srcid[P_HDR_SRC_SIZE+1] = {P_HDR_UNKWON_SRC_ID};
    const t_conf * conf = in_get_conf_global_ref();
    const t_oam_info * oam = &rec->oam;
    t_cli_ctx * cli = &icli->cli;
    if(parse_cmd_hdr(buf, size, NULL, proto_op, proto_tid, &proto_sid, proto_svcid, proto_srcid) != IN_SUCCESS) {
        goto GT_FAIL_REASON_INVALID_FORMAT;
    }        
    if(strncmp(proto_op, P_HDR_OP_LOGIN, P_HDR_OP_LOGIN_SIZE) == 0) {
        LOGI1K(proto_tid, "[%s|%04d] Inbound recv. [%d]\n%s\n", cli->name, cli->sid, size, buf);
        if(proto_sid > D_MAX_SESSION) {
            LOGEK(proto_tid, "[%s|%04d] Invalid Sid [%04d]\n", cli->name, cli->sid, proto_sid);
            goto GT_FAIL_REASON_INVALID_FORMAT;
        }
        if(cli->sid != 0) {
            LOGEK(proto_tid, "[%s|%04d] Already logined\n", cli->name, cli->sid);
            goto GT_FAIL_REASON_ALREADY_LOGINED;
        }
        bool certified = oam_certify_session(oam, proto_sid, cli->bind_ip_addr);
        if(certified) {
            if(in_update_cli_reg_info_to_srv_ctx(cli->srv, cli, proto_sid) != IN_SUCCESS) {
                LOGEK(proto_tid, "[%s|%04d] Can not update regist\n", cli->name, cli->sid);
                goto GT_ERR_INVALID_LOGIN;
            }
            if(conf->inbound[proto_sid].name[0])
                strncpy(cli->name, conf->inbound[proto_sid].name, sizeof(cli->name));
            else
                strncpy(cli->name, "Unknown", sizeof(cli->name));
            cli->sid = proto_sid;
            icli->state[0] = in_get_conf_state_global()=='B'?'B':conf->inbound[cli->sid].state[0]?conf->inbound[cli->sid].state[0]:'A';
            oam_update_isession_state(oam, proto_sid, cli->bind_ip_addr, true);
            send_result(icli, proto_op, proto_tid, proto_sid, proto_svcid, proto_srcid, IN_SUCCESS, "Success");
        }
        else {
            alarm_unauthorised_session(oam, proto_sid, cli->bind_ip_addr);
            goto GT_ERR_INVALID_LOGIN;
        }
    }
    else if(strncmp(proto_op, P_HDR_OP_HEAERTBEAT, P_HDR_OP_HEAERTBEAT_SIZE) == 0) {
        LOGV("[%s|%04d] Inbound recv. [%d]\n%s\n", cli->name, cli->sid, size, buf);
        if(cli->sid == 0) {
            LOGEK(proto_tid, "[%s|%04d] Could not logined [%04d]\n", cli->name, cli->sid, proto_sid);
            goto GT_FAIL_REASON_NOT_LOGINED;
        }
        if(cli->sid != proto_sid) {
            LOGEK(proto_tid, "[%s|%04d] Invalid Sid [%04d]\n", cli->name, cli->sid, proto_sid);
            goto GT_FAIL_REASON_INVALID_FORMAT;
        }                
        icli->state[0] = in_get_conf_state_global()=='B'?'B':conf->inbound[cli->sid].state[0]?conf->inbound[cli->sid].state[0]:'A'; 
        send_result(icli, proto_op, proto_tid, proto_sid, proto_svcid, proto_srcid, IN_SUCCESS, "Success", FALSE);
    }
    else {
        LOGI1K(proto_tid, "[%s|%04d] Inbound recv. [%d]\n%s\n", cli->name, cli->sid, size, buf);
        stat_i_inc_recv(proto_sid);
        if(cli->sid == 0) {
            LOGEK(proto_tid, "[%s|%04d] Could not logined [%04d]\n", cli->name, cli->sid, proto_sid);
            stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_NOT_LOGINED);
            goto GT_FAIL_REASON_NOT_LOGINED;
        }
        if(cli->sid != proto_sid) {
            LOGEK(proto_tid, "[%s|%04d] Invalid Sid [%04d]\n", cli->name, cli->sid, proto_sid);
            stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_INVALID_FORMAT);
            goto GT_FAIL_REASON_INVALID_FORMAT;
        }
        try {
            Json::Value root;
            Json::Reader reader;
            Json::Value temp;
            bool parsingSuccessful = reader.parse(buf+P_HDR_SIZE, buf+size, root, false);
            if (!parsingSuccessful) {
                LOGE("[%s|%04d] JSON parsing\n", cli->name, cli->sid);
                stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_INVALID_FORMAT);
                goto GT_FAIL_REASON_INVALID_FORMAT;
            }
            if(!root.isObject()) {
                LOGE("[%s|%04d] JSON root parsing\n", cli->name, cli->sid);
                stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_INVALID_FORMAT);
                goto GT_FAIL_REASON_INVALID_FORMAT;
            }
            static volatile apr_time_t begin_time = 0;
            static apr_uint32_t curr_tps = 1;
            const apr_uint32_t supported_max_tps = conf->manage.supported_max_tps;
            if(supported_max_tps != 0) {
                const apr_time_t curr_time = time(NULL);
                if(curr_time != begin_time) {
                    apr_atomic_set32(&curr_tps, 1);
                    begin_time = curr_time;
                }
                else {
                    apr_atomic_add32(&curr_tps, 1);
                }
                if(curr_tps > supported_max_tps) {
                    alarm_request_overloaded(oam, proto_sid, curr_tps);
                    LOGEK(proto_tid, "[%s|%04d] Overloaded [%d>%d]\n", cli->name, cli->sid, curr_tps, supported_max_tps);
                    stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_OVERLOADED);
                    goto GT_FAIL_REASON_OVERLOADED;
                }
            }
            if(cli && rec->hplug && rec->hplug->on_irecv) {
                rv = rec->hplug->on_irecv(cli, rtime, 
                    proto_op, proto_tid, proto_sid, proto_svcid, proto_srcid, root);
                if(rv != IN_SUCCESS) {
                    stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_PLUGIN);
                    goto GT_FAIL_REASON_PLUGIN;
                }
                stat_i_inc_recv_succ(proto_sid);
            }
            else {
                stat_i_inc_recv_fail(proto_sid, ST_FAIL_REASON_PLUGIN);
                goto GT_FAIL_REASON_PLUGIN;
            }
        }
        catch ( const std::exception &e )
        {
            LOGE("[%s|%04d] Unexpected exception caugth:%s\n", cli->name, cli->sid, e.what());
            goto GT_FAIL_REASON_INVALID_FORMAT;
        }
    }
    icli->last_heartbeat_time = rtime;
    return rv;
GT_FAIL_REASON_INVALID_FORMAT:
    send_result(icli, proto_op, proto_tid, cli->sid, proto_svcid, proto_srcid, ST_FAIL_REASON_INVALID_FORMAT, "Invalid format");
    alarm_invalid_request(oam, proto_sid);
    return IN_FAIL;
GT_FAIL_REASON_NOT_LOGINED:
    send_result(icli, proto_op, proto_tid, cli->sid, proto_svcid, proto_srcid, ST_FAIL_REASON_NOT_LOGINED, "Not logined request");
    alarm_invalid_request(oam, proto_sid);
    return IN_FAIL;
GT_FAIL_REASON_ALREADY_LOGINED:
    send_result(icli, proto_op, proto_tid, cli->sid, proto_svcid, proto_srcid, ST_FAIL_REASON_INVALID_FORMAT, "Already logined");
    alarm_invalid_request(oam, proto_sid);
    return IN_FAIL;
GT_FAIL_REASON_PLUGIN:
    send_result(icli, proto_op, proto_tid, cli->sid, proto_svcid, proto_srcid, ST_FAIL_REASON_PLUGIN, "Caused plugin");
    alarm_invalid_request(oam, proto_sid);
    return rv;
GT_FAIL_REASON_OVERLOADED:
    send_result(icli, proto_op, proto_tid, cli->sid, proto_svcid, proto_srcid, ST_FAIL_REASON_OVERLOADED, "Overloaded");
    return IN_FAIL;
GT_ERR_INVALID_LOGIN:
    send_result(icli, proto_op, proto_tid, cli->sid, proto_svcid, proto_srcid, ST_FAIL_REASON_INVALID_FORMAT, "Invalid login request");
    return IN_ERR_INVALID_LOGIN;
}

/**
* on_inbound_cli_attach
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_attach(t_inbound_cli_ctx * icli) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec && icli) {
        const t_conf * conf = in_get_conf_global_ref();
        icli->state[0] = in_get_conf_state_global()=='B'?'B':conf->inbound[icli->cli.sid].state[0]?conf->inbound[icli->cli.sid].state[0]:'A';
        if(rec->hplug && rec->hplug->on_iconnect) {
            return rec->hplug->on_iconnect(&icli->cli);
        }
    }
    return IN_SUCCESS;
}

/**
* on_inbound_cli_detach
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_detach(t_inbound_cli_ctx * icli) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec && icli) {
        oam_update_isession_state(&rec->oam, icli->cli.sid, icli->cli.bind_ip_addr, false);
        if(rec->hplug && rec->hplug->on_idisconnect) {
            rec->hplug->on_idisconnect(&icli->cli);
        }
    }
    return IN_SUCCESS;
}

/**
* on_inbound_cli_idle
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_idle(t_inbound_cli_ctx * icli, apr_time_t elasped_time) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec && icli) {
        t_cli_ctx * cli = &icli->cli;
        const t_conf * conf = in_get_conf_global_ref();
        apr_time_t curr_time = apr_time_now();
        cli->check_interval = apr_time_from_msec(conf->manage.check_interval);
        cli->reg_sig_timeout = apr_time_from_msec(conf->manage.login_timeout);
        if(icli->last_heartbeat_time == 0) {
            icli->last_heartbeat_time = curr_time;
            if(conf->manage.heartbeat_timeout && elasped_time > apr_time_from_msec(conf->manage.heartbeat_timeout)) {
                return IN_ERR_HEARTBEAT_TIMEUP;
            }
        }
        else {
            if(conf->manage.heartbeat_timeout && (curr_time - icli->last_heartbeat_time) > apr_time_from_msec(conf->manage.heartbeat_timeout)) {
                return IN_ERR_HEARTBEAT_TIMEUP;
            }
        }
        if(cli->sid != 0) {
            char curr_state = in_get_conf_state_global()=='B'?'B':conf->inbound[cli->sid].state[0]?conf->inbound[cli->sid].state[0]:'A';
            if(curr_state != icli->state[0]) {
                char backup_state = icli->state[0];
                icli->state[0] = curr_state;
                if(send_result(icli, P_HDR_OP_HEAERTBEAT, "0", cli->sid, P_HDR_UNKWON_SVC_ID, conf->proc.srcid, IN_SUCCESS, "Changed state") != IN_SUCCESS) {
                    icli->state[0] = backup_state;
                }
            }            
        }
        if(rec->hplug && rec->hplug->on_iidle) {
            rec->hplug->on_iidle(cli, elasped_time);
        }
    }
    return IN_SUCCESS;
}

/**
* on_inbound_cli_recv
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_recv(t_inbound_cli_ctx * icli, apr_socket_t * csock) {
    apr_int32_t rv = IN_SUCCESS;
    t_cli_ctx * cli = NULL;
    if(icli) {
        cli = &icli->cli;
        char buf[P_BUFFER_SIZE];
        char * buf_ptr = buf;
        apr_uint32_t want = P_HDR_SIZE_SIZE;
        apr_size_t readen = want;
        rv = in_socket_recv(csock, (char *)buf_ptr, &readen);
        if(rv != APR_SUCCESS || readen != want) {
            LOGE("[%s|%04d] Recv result(%d), Size(%d/%d)\n", cli->name, cli->sid, rv, readen, want);
            rv = IN_ERR_SOCK_RECV; goto GT_EXIT;
        }
        *(buf_ptr+P_HDR_SIZE_SIZE) = 0;
        want = in_atoi(buf_ptr);
        readen = want;
        rv = in_socket_recv(csock, buf_ptr+P_HDR_SIZE_SIZE, &readen);
        if(rv != APR_SUCCESS || readen != want) {
            LOGE("[%s|%04d] Recv result(%d), Size(%d/%d)\n", cli->name, cli->sid, rv, readen, want);
            rv = IN_ERR_SOCK_RECV; goto GT_EXIT;
        }
        buf[P_HDR_SIZE_SIZE+readen] = 0;
        if((rv = on_inbound_cli_process(icli, buf, P_HDR_SIZE_SIZE+readen)) != IN_SUCCESS) {
            goto GT_EXIT;
        }
    }
    return rv;
GT_EXIT:
    if(cli) {
        LOCK(cli->mymutex);
        cli->last_error_code = rv;
        UNLOCK(cli->mymutex);
    }
    return rv;
}

/**
* on_inbound_cli_send
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_send(t_inbound_cli_ctx * icli, const char * buf, apr_size_t size) {
    return in_send_cli_ctx(&icli->cli, buf, size);
}

/**
* inbound_send
*/
IN_DECLARE(int) inbound_send(t_inbound_cli_ctx * icli, const char * tid, const char * IN buf, apr_size_t IN size) {
    stat_i_inc_send(icli->cli.sid);
    int rv = on_inbound_cli_send(icli, buf, size);    
    if(rv == IN_SUCCESS) {
        LOGI1K(tid, "[%s|%04d] Inbound send. [%d]\n%s\n", icli->cli.name, icli->cli.sid, size, buf);
        stat_i_inc_send_succ(icli->cli.sid);
    }
    else {
        LOGEK(tid, "[%s|%04d] Inbound send. %d [%d]\n%s\n", icli->cli.name, icli->cli.sid, rv, size, buf);
        stat_i_inc_send_fail(icli->cli.sid, ST_FAIL_REASON_SOCKET);
    }
    return rv;
}

/**
* inbound_send_sig
*/
IN_DECLARE(int) inbound_send_sig(apr_uint16_t sid, const char * tid, const char * IN buf, apr_size_t IN size) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) {
        return IN_FAIL;
    }
    stat_i_inc_send(sid);
    int rv = in_find_and_send_cli(rec->isrv, sid, buf, size);
    const t_conf * conf = in_get_conf_global_ref();
    if(rv == IN_SUCCESS) {
        LOGI1K(tid, "[%s|%04d] Inbound send. [%d]\n%s\n", conf->inbound[sid].name, sid, size, buf);
        stat_i_inc_send_succ(sid);
    }
    else {
        LOGEK(tid, "[%s|%04d] Inbound send. %d [%d]\n%s\n", conf->inbound[sid].name, sid, rv, size, buf);
        stat_i_inc_send_fail(sid, ST_FAIL_REASON_SOCKET);
    }
    return rv;
}

#ifndef _STATUS__H_
#define _STATUS__H_

#include "common.h"

//#define FEATURE_STATUS_AS_SHM

#define MAX_STATUS_MSG   (102400)

typedef struct _t_status t_status;

struct _t_status {
    /* empty */
};

/**
 * in_create_status_file
 * @return
 */
IN_DECLARE(t_status *) in_create_status_file(const char * name, apr_pool_t * pool);

/**
 * in_destroy_status_file
 * @return
 */
IN_DECLARE(void) in_destroy_status_file(t_status * s, const char * name, apr_pool_t * pool);

/**
 * in_get_status_file
 * @return
 */
IN_DECLARE(int) in_get_status_file(const char * name, char * out, int out_size, apr_pool_t * pool);

/**
 * in_set_status_file
 * @return
 */
IN_DECLARE(int) in_set_status_file(t_status * s, char * buf, int buf_size);


#endif /* _STATUS__H_ */

#ifndef _INAS_EXT_GW__H_
#define _INAS_EXT_GW__H_

#ifdef __cplusplus
     extern "C" {
#endif

/**
 * Get the date a time that the pkg was built
 * 
 * @param void
 * 
 * @return The server build time string
 */
IN_DECLARE(const char *) get_pkg_built(void);

/**
 * get_pkg_version
 * @return
 */
IN_DECLARE(const char *) get_pkg_version(void);

#ifdef __cplusplus
     }
#endif
     
#endif /* _INAS_EXT_GW__H_ */


#include "statistics.h"

t_stat g_stat;

int init_stat(apr_pool_t * pool) {
    apr_status_t rv;
    rv = apr_thread_mutex_create(&g_stat.mymutex, APR_THREAD_MUTEX_DEFAULT, pool);
    if(rv != APR_SUCCESS) {
        goto GT_ERR;
    }
    return IN_SUCCESS;
GT_ERR:
    exit_stat();
    return IN_FAIL;
}

void exit_stat(void) {
    if(g_stat.mymutex != NULL)
        apr_thread_mutex_destroy(g_stat.mymutex);
    g_stat.mymutex = NULL;
}

const t_stat * stat_get(void) {
    return &g_stat;
}

void stat_i_inc_recv(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.iclis[sid].recv_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_i_inc_recv_succ(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.iclis[sid].recv_succ_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_i_inc_recv_fail(const apr_uint16_t sid, const int reason) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.iclis[sid].recv_fail_reasons[reason];
        ++g_stat.iclis[sid].recv_fail_count;
        ++g_stat.recv_fail_reasons[reason];
    }
    UNLOCK(g_stat.mymutex);
}

void stat_i_inc_send(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.iclis[sid].send_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_i_inc_send_succ(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.iclis[sid].send_succ_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_i_inc_send_fail(const apr_uint16_t sid, const int reason) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.iclis[sid].send_fail_reasons[reason];
        ++g_stat.iclis[sid].send_fail_count;
        ++g_stat.send_fail_reasons[reason];
    }
    UNLOCK(g_stat.mymutex);
}

void stat_o_inc_recv(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.oclis[sid].recv_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_o_inc_recv_succ(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.oclis[sid].recv_succ_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_o_inc_recv_fail(const apr_uint16_t sid, const int reason) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.oclis[sid].recv_fail_reasons[reason];
        ++g_stat.oclis[sid].recv_fail_count;
        ++g_stat.recv_fail_reasons[reason];
    }
    UNLOCK(g_stat.mymutex);
}

void stat_o_inc_send(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.oclis[sid].send_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_o_inc_send_succ(const apr_uint16_t sid) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.oclis[sid].send_succ_count;
    }
    UNLOCK(g_stat.mymutex);
}

void stat_o_inc_send_fail(const apr_uint16_t sid, const int reason) {
    LOCK(g_stat.mymutex);
    if(sid <= D_MAX_SESSION) {
        ++g_stat.oclis[sid].send_fail_reasons[reason];
        ++g_stat.oclis[sid].send_fail_count;
        ++g_stat.send_fail_reasons[reason];
    }
    UNLOCK(g_stat.mymutex);
}


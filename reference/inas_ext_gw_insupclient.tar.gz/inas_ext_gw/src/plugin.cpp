#include "logger.h"
#include "plugin.h"

static apr_dso_handle_t * g_plugin_dso_handle = NULL;

/**
 * @return
 */
IN_EXPORT_REFERENCE_DECLARE(int, create_plugin_handle)(const char * plug_name, t_plugin_handle ** OUT phplug, t_plugin_handle * IN hplug);

/**
 * @return
 */
IN_EXPORT_REFERENCE_DECLARE(void, destroy_plugin_handle)(t_plugin_handle * hplug);

/**
 * Get the date a time that the pkg was built
 * @return The server build time string
 */
IN_EXPORT_REFERENCE_DECLARE(const char *, get_plugin_built)(void);


/**
 * get_plugin_version
 * @return
 */
IN_EXPORT_REFERENCE_DECLARE(const char *, get_plugin_version)(void);


/**
 * in_load_plugin_dso
 * @return
 */
IN_DECLARE(int) in_load_plugin_dso(const char * path, const char * plug_name, t_plugin_handle ** OUT phplug, t_plugin_handle * IN hplug, apr_pool_t * pool) {
    char errstr[256];
    apr_dso_handle_t * h = NULL;
    apr_status_t rv;
    rv = apr_dso_load(&h, path, pool);
    if(rv != APR_SUCCESS) {
        apr_dso_error(h, errstr, 256);
        fprintf((FILE*)stderr, "%s\n", errstr);
        return IN_FAIL;
    }
    IN_EXPORT_REFERENCE_DECLARE(int, set_plugin_logging_cb)(int (*logging_cb)(const int lv, const char * fname, const int line, const char * key, const char *fmt, ...));
    rv = apr_dso_sym((apr_dso_handle_sym_t*)(void*)(&set_plugin_logging_cb), h, "set_plugin_logging_cb");
    if(rv != APR_SUCCESS) {
        apr_dso_error(h, errstr, 256);
        fprintf((FILE*)stderr, "%s\n", errstr);
        goto GT_EXIT;
    }
    set_plugin_logging_cb(in_write_log_global_for_plugin);
    if(plug_name && phplug && hplug) {
        *phplug = NULL;
        rv = apr_dso_sym((apr_dso_handle_sym_t*)(void*)(&create_plugin_handle), h, "create_plugin_handle");
        if(rv != APR_SUCCESS) {
            apr_dso_error(h, errstr, 256);
            fprintf((FILE*)stderr, "%s\n", errstr);
            goto GT_EXIT;
        }
        rv = apr_dso_sym((apr_dso_handle_sym_t*)(void*)(&destroy_plugin_handle), h, "destroy_plugin_handle");
        if(rv != APR_SUCCESS) {
            apr_dso_error(h, errstr, 256);
            fprintf((FILE*)stderr, "%s\n", errstr);
            goto GT_EXIT;
        }
        create_plugin_handle(plug_name, phplug, hplug);
        if(*phplug == NULL) {
            fprintf((FILE*)stderr, "Create plugin handle is null\n");
            goto GT_EXIT;
        }
    }
    rv = apr_dso_sym((apr_dso_handle_sym_t*)(void*)(&get_plugin_built), h, "get_plugin_built");
    if(rv != APR_SUCCESS) {
        apr_dso_error(h, errstr, 256);
        fprintf((FILE*)stderr, "%s\n", errstr);
        goto GT_EXIT;
    }
    rv = apr_dso_sym((apr_dso_handle_sym_t*)(void*)(&get_plugin_version), h, "get_plugin_version");
    if(rv != APR_SUCCESS) {
        apr_dso_error(h, errstr, 256);
        fprintf((FILE*)stderr, "%s\n", errstr);
        goto GT_EXIT;
    }
    if(g_plugin_dso_handle) 
        apr_dso_unload(g_plugin_dso_handle);
    g_plugin_dso_handle = h;
    return IN_SUCCESS;
GT_EXIT:
    if(phplug && *phplug && destroy_plugin_handle) {
        destroy_plugin_handle(*phplug);
        *phplug = NULL;
    }
    if(h) apr_dso_unload(h);
    return IN_FAIL-1;
}

/**
 * in_unload_plugin_dso
 * @return 
 */
IN_DECLARE(void) in_unload_plugin_dso(t_plugin_handle * IN OUT hplug) {
    if(hplug && destroy_plugin_handle)
        destroy_plugin_handle(hplug);
    if(g_plugin_dso_handle) 
        apr_dso_unload(g_plugin_dso_handle);
    g_plugin_dso_handle = NULL;
}

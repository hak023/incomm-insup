#include <sys/stat.h>
#include "common.h"
#include "proc.h"

static t_proc_rec g_proc_rec;

/**
 * in_get_running_old_pid
 * @return
 */
IN_DECLARE(int) in_get_running_old_pid(t_proc_rec * proc)
{
    int npid = 0;
    char pid_fname[64] = {0,};
    in_strncpy(pid_fname, proc->name, sizeof(pid_fname));
    strcat(pid_fname, ".pid");
    apr_file_t * pidfd = NULL;
    apr_status_t rv = apr_file_open(&pidfd, pid_fname, APR_FOPEN_READ, APR_UREAD, proc->pool);
    if(rv == APR_SUCCESS) {
        char oldpid[64] = {0,};
        apr_size_t nbytes = sizeof(oldpid)-1;
        rv = apr_file_read(pidfd, oldpid, &nbytes);
        if(rv == APR_SUCCESS && nbytes) {
            struct stat sts;
            char checkpid[64] = {0,};
            const int noldpid = atoi(oldpid);
            if(noldpid != getpid()) {
                snprintf(checkpid, sizeof(checkpid), "/proc/%u", noldpid);
                if (stat(checkpid, &sts) == -1 && errno == ENOENT) {}
                else
                {
                    npid = noldpid;
                }
            }
        }
        apr_file_close(pidfd);
    }
    return npid;
}

/**
 * in_generate_pid_info
 * @return
 */
IN_DECLARE(bool) in_generate_pid_info(t_proc_rec * proc) {
    in_remove_pid_info(proc);
    bool result = false;
    char pid_fname[64] = {0,};
    in_strncpy(pid_fname, proc->name, sizeof(pid_fname));
    strcat(pid_fname, ".pid");
    apr_file_t * pidfd = NULL;
    apr_status_t rv = apr_file_open(&pidfd, pid_fname, APR_FOPEN_CREATE|APR_FOPEN_WRITE|APR_FOPEN_TRUNCATE, APR_UREAD|APR_UWRITE, proc->pool);
    if(rv == APR_SUCCESS) {
        proc->pid = getpid();
        apr_file_printf(pidfd, "%d\n", proc->pid);
        apr_file_flush(pidfd);
        apr_file_close(pidfd);
        result = true;
    }
    return result;
}

/**
 * in_remove_pid_info
 * @return
 */
IN_DECLARE(void) in_remove_pid_info(t_proc_rec * proc) {
    char pid_fname[64] = {0,};
    in_strncpy(pid_fname, proc->name, sizeof(pid_fname));
    strcat(pid_fname, ".pid");
    apr_file_remove(pid_fname, NULL);
}

/**
 * get_proc_rec
 * @return
 */
IN_DECLARE(t_proc_rec *) get_proc_rec(void) {
    if(apr_atomic_read32(&g_proc_rec.isrun)) {
        return &g_proc_rec;
    }
    return NULL;
}

/**
* get_proc_rec_ref
* @return
*/
IN_DECLARE(t_proc_rec *) get_proc_rec_ref(void) {
    return &g_proc_rec;
}

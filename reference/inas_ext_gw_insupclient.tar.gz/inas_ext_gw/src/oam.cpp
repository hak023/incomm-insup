#include "common.h"
#include "logger.h"
#include "config.h"
#include "proc.h"
#include <json/json.h>
#include "oam.h"

using namespace std;
using namespace Json;

int oam_init_info(t_oam_info * IN OUT oam, apr_pool_t * IN pool) {
    const t_conf * conf = in_get_conf_global_ref();
    int rv;
    rv = apr_socket_create(&oam->oam_sock, APR_INET, SOCK_DGRAM, 0, pool);
    if(rv != APR_SUCCESS) {
        goto GT_ERR;
    }
    rv = apr_sockaddr_info_get(&oam->oam_sock_to, conf->oam.oam_dgram_ip, APR_INET, conf->oam.oam_dgram_port, 0, pool);
    if(rv != APR_SUCCESS) {
        goto GT_ERR;
    }
    rv = apr_socket_opt_set(oam->oam_sock, APR_SO_REUSEADDR, 1);
    if(rv != APR_SUCCESS) {
        goto GT_ERR;
    }
    rv = apr_thread_mutex_create(&oam->oam_mutex, APR_THREAD_MUTEX_DEFAULT, pool);
    if(rv != APR_SUCCESS) {
        goto GT_ERR;
    }
    return IN_SUCCESS;
GT_ERR:
    if(oam->oam_sock != NULL) {
        apr_socket_close(oam->oam_sock);
        oam->oam_sock = NULL;
    }
    if(oam->oam_mutex != NULL) {
        apr_thread_mutex_destroy(oam->oam_mutex);
        oam->oam_mutex = NULL;
    }
    return IN_FAIL;
}

void oam_clean_info(t_oam_info * IN OUT oam) {
    LOCK(oam->oam_mutex);
    if(oam->oam_sock != NULL) {
        apr_socket_shutdown(oam->oam_sock, APR_SHUTDOWN_WRITE);
        apr_socket_close(oam->oam_sock);
        oam->oam_sock = NULL;
    }
    UNLOCK(oam->oam_mutex);
    if(oam->oam_mutex != NULL) {
        apr_thread_mutex_destroy(oam->oam_mutex);
        oam->oam_mutex = NULL;
    }
}

static void print_json_value_tree(FILE *fout, Json::Value &value, const std::string &path = ".") {
    switch (value.type()) {
    case Json::nullValue:
        fprintf(fout, "%s=null\n", path.c_str());
        break;
    case Json::intValue:
        fprintf(fout, "%s=%s\n", path.c_str(), Json::valueToString(value.asLargestInt()).c_str());
        break;
    case Json::uintValue:
        fprintf(fout, "%s=%s\n", path.c_str(), Json::valueToString(value.asLargestUInt()).c_str());
        break;
    case Json::realValue:
        fprintf(fout, "%s=%.16g\n", path.c_str(), value.asDouble());
        break;
    case Json::stringValue:
        fprintf(fout, "%s=\"%s\"\n", path.c_str(), value.asString().c_str());
        break;
    case Json::booleanValue:
        fprintf(fout, "%s=%s\n", path.c_str(), value.asBool() ? "true" : "false");
        break;
    case Json::arrayValue: {
        fprintf(fout, "%s=[]\n", path.c_str());
        int size = value.size();
        for (int index = 0; index < size; ++index) {
            static char buffer[16];
            sprintf(buffer, "[%d]", index);
            print_json_value_tree(fout, value[index], path + buffer);
        }
    }
        break;
    case Json::objectValue: {
        fprintf(fout, "%s=objectValue\n", path.c_str());
    }
        break;
    default:
        break;
    }
}

int oam_load_info_file(char * IN proc_name, t_oam_info * IN OUT oam, apr_pool_t * IN pool, bool reload) {
    t_conf * conf = in_get_conf_global_ref();
    apr_status_t rv;
    apr_file_t * fp = NULL;
    apr_finfo_t finfo;
    char buffer[102400] = {0,};
    apr_size_t nbytes = sizeof(buffer)-1;
    const char * fname = conf->oam.oam_info_file;
    rv = apr_file_open(&fp, fname, APR_FOPEN_READ, APR_UREAD | APR_GREAD, pool);
    if(rv != APR_SUCCESS || fp == NULL) {
        LOGE("Could not open '%s' JSON file\n", fname);
        goto GT_ERR;
    }
    rv = apr_file_info_get(&finfo, APR_FINFO_NORM, fp);
    if (APR_STATUS_IS_INCOMPLETE(rv)) {
        LOGE("Could not get info '%s' JSON file\n", fname);
        goto GT_ERR;
    }

    if (oam->conf_file_modification_time == finfo.mtime) {
        LOGV("'%s' JSON file is not modification and skipped\n", fname);
        goto GT_ERR;
    }
    rv = apr_file_read(fp, buffer, &nbytes);
    if(rv != APR_SUCCESS || nbytes <= 0) {
        LOGE("Could not read '%s' JSON file\n", fname);
        goto GT_ERR;
    }
    apr_file_close(fp); fp = NULL;
    buffer[nbytes] = 0;
    try
    {
        Json::Value root;
        Json::Reader reader;
        Json::Value temp;
        Json::Value arPids, arStates;
        signed find_myconf_index = -1;
        char * oamState;
        bool parsingSuccessful = reader.parse(buffer, buffer+nbytes, root, false);
        if (!parsingSuccessful) {
            LOGE("'%s' JSON file parsing\n", fname);
            goto GT_ERR;
        }
        buffer[0] = 0;
        LOGD("'%s' JSON file parsing successful\n", fname);
        /*print_json_value_tree(stdout, root);*/
        if(!root.isObject()) {
            LOGE("'%s' JSON file parsing\n", fname);
            goto GT_ERR;
        }
        temp = root.get("State", "A");
        if(!temp.isString()) {
            LOGE("'%s' State is not string type\n", fname);
            goto GT_ERR;
        }
        oamState = (char*)temp.asCString();
        if(oamState[1] == 0) {
            if(oamState[0] == 'A' || oamState[0] == 'B' || oamState[0] == 'D')
                conf->sys.state[0] = oamState[0];
        } else if(oamState[2] == 0) {
            if(oamState[1] == 'A' || oamState[1] == 'B' || oamState[1] == 'D')
                conf->sys.state[0] = oamState[1];
        }
        arPids = root["Pids"];
        if(!arPids.isArray()) {
            LOGE("'%s' Pids is not string array type\n", fname);
            goto GT_ERR;
        }
        arStates = root["States"];
        if(!arStates.isArray()) {
            LOGE("'%s' States is not string array type\n", fname);
            goto GT_ERR;
        }        
        for(signed i = 0; i < (signed)arPids.size(); ++i) {
            if(arPids[i].isString() && strcmp(proc_name, arPids[i].asCString()) == 0) {
                find_myconf_index = i;
                break;
            }
        }
        if(find_myconf_index >= 0 && find_myconf_index < (signed)arStates.size()) {
            if(arStates[find_myconf_index].isString()) {
                oamState = (char*)arStates[find_myconf_index].asCString();
                if(oamState[0] == 'A' || oamState[0] == 'B' || oamState[0] == 'D')
                    conf->proc.state[0] = oamState[0];
            }
        }
        temp = root["OverFactor"];
        if(temp.isInt()) {
            conf->manage.supported_max_tps = temp.asInt();
        }
        LOGI("Loaded oam config. System[%c] Proc[%c] Overfactor[%d]\n",
            conf->sys.state[0], conf->proc.state[0], conf->manage.supported_max_tps);
        oam->conf_file_modification_time = finfo.mtime;
        return IN_SUCCESS;
    }
    catch ( const std::exception &e )
    {
        LOGE("Unexpected exception caugth:%s\n", e.what());
        if(fp) apr_file_close(fp);
        return IN_FAIL;
    }
    return IN_FAIL;
GT_ERR:
    if(fp) apr_file_close(fp);    
    return (reload) ? IN_FAIL : IN_SUCCESS;
}

int oam_send_info(const t_oam_info * IN OUT oam, const char * fmt, ...) {
    int rv = -1;
    apr_size_t len = 0;
    if(oam->oam_sock && oam->oam_sock_to) {
        char msg[1500] = {0,};
        va_list args;
        va_start(args, fmt);
        len = vsnprintf(msg, sizeof(msg), fmt, args);
        va_end(args);
        if(len) {
            LOCK(oam->oam_mutex);
            rv = apr_socket_sendto(oam->oam_sock, oam->oam_sock_to, 0, msg, &len);
            UNLOCK(oam->oam_mutex);
        }
        LOGV("Send OAM. [%d]\n%s\n", len, msg);
    }
    if(rv == APR_SUCCESS) {
        return len;
    }
    return IN_FAIL;
}

void oam_update_isession_state(const t_oam_info* oam, const apr_uint16_t sid, const char* ipaddr, bool onoff) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    if (sid && sid <= D_MAX_SESSION) {
        oam_send_info(oam, "{\"Op\":\"%s\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d}\r\n",
                (onoff) ? "ISessOn" : "ISessOff", rec->conf->sys.name, rec->name, sid);
    }
}

void oam_update_osession_state(const t_oam_info* oam, const apr_uint16_t sid, const char* ipaddr, bool onoff) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    if (sid && sid <= D_MAX_SESSION) {
        oam_send_info(oam, "{\"Op\":\"%s\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d}\r\n",
                (onoff) ? "OSessOn" : "OSessOff", rec->conf->sys.name, rec->name, sid);
    }
}

bool oam_certify_session(const t_oam_info * oam, const apr_uint16_t sid, const char * ipaddr) {
    const t_conf * conf = in_get_conf_global_ref();
    if(conf->oam.use_login_feature && sid <= D_MAX_SESSION) {
        if (conf->inbound[sid].used
                && strcmp(ipaddr, conf->inbound[sid].ipaddr) == 0) {
            return true;
        }
        return false;
    }
    return true;
}

void alarm_unauthorised_session(const t_oam_info * oam, const apr_uint16_t sid, const char * ipaddr) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    oam_send_info(oam, "{\"Op\":\"Alarm-Unauthorised session\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d,\"Ip\":\"%s\"}\r\n",
        rec->conf->sys.name, rec->name, sid, ipaddr);
}

void alarm_request_overloaded(const t_oam_info * oam, const apr_uint16_t sid, const int curr_tps) {
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    oam_send_info(oam, "{\"Op\":\"Alarm-Overloaded\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d,\"Tps\":%d}\r\n",
        rec->conf->sys.name, rec->name, sid, curr_tps);
}

void alarm_invalid_request(const t_oam_info * oam, const apr_uint16_t sid) {
#ifdef FEATURE_DETAIL_ALARM    
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    oam_send_info(oam, "{\"Op\":\"Alarm-Invalid request\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d}\r\n",
        rec->conf->sys.name, rec->name, sid);
#endif    
}

void alarm_request_timeout(const t_oam_info * oam, const apr_uint16_t sid, const char * tid, const char * desc) {
#ifdef FEATURE_DETAIL_ALARM    
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    oam_send_info(oam, "{\"Op\":\"Alarm-Request time up\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d,\"Tid\":\"%s\",\"Desc\":\"%s\"}\r\n",
        rec->conf->sys.name, rec->name, sid, tid, desc);
#endif    
}

void alarm_socket_error(const t_oam_info * oam, const apr_uint16_t sid) {
#ifdef FEATURE_DETAIL_ALARM    
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return;
    }
    oam_send_info(oam, "{\"Op\":\"Alarm-Socket error\",\"Sys\":\"%s\",\"Proc\":\"%s\",\"SessId\":%d}\r\n",
        rec->conf->sys.name, rec->name, sid);
#endif    
}

#ifndef _CLIENT_CONTEXT__H_
#define _CLIENT_CONTEXT__H_

#include "common.h"
#include "servercontext.h"

#define CLIENT_CHECK_INTERVAL         (5000)
#define CLIENT_COMM_TIME_OUT          (0500)

typedef struct _t_cli_ctx t_cli_ctx;
typedef struct _t_cli_traverse_item t_cli_traverse_item;

/**
* @brief A client callback function type
*/
typedef int (*t_cli_ctx_attach_callback)(t_cli_ctx * cli);
typedef int (*t_cli_ctx_detach_callback)(t_cli_ctx * cli);
typedef int (*t_cli_ctx_idle_callback)(t_cli_ctx * cli, apr_time_t elasped_time);
typedef int (*t_cli_ctx_recv_callback)(t_cli_ctx * cli, apr_socket_t * csock);
typedef int (*t_cli_ctx_send_callback)(t_cli_ctx * cli, const char * buf, apr_size_t size);

struct _t_cli_traverse_item {
    apr_uint16_t sid;    
    apr_time_t accept_time, reg_time;
    t_cli_ctx * cli;
};

struct _t_cli_ctx {
    apr_uint16_t sid;    
    char name[D_NAME_SIZE];
    char bind_ip_addr[D_STR_IPv4_SIZE];
    apr_uint16_t srv_port;
    t_srv_ctx * srv;
    apr_os_thread_t mythd;
    apr_int32_t last_error_code; /**< Need to sync */
    apr_time_t begin_time;
    char str_begin_time[D_STR_TIME_SIZE];
    apr_time_t lived_time;
    apr_time_t check_interval;
    apr_time_t reg_sig_timeout;
    apr_pool_t * pool;
    apr_allocator_t * pool_allocator;
    apr_pool_t * conn_pool;
    apr_allocator_t * conn_pool_allocator;
    apr_socket_t * sock; /**< Need to sync */
    apr_uint32_t isrun;
    apr_thread_mutex_t * mymutex;
    t_cli_ctx_attach_callback on_attach;
    t_cli_ctx_detach_callback on_detach;
    t_cli_ctx_idle_callback on_idle;
    t_cli_ctx_recv_callback on_recv;
    t_cli_ctx_send_callback on_send;
    apr_uint64_t st_in_tot_count, st_out_tot_count;
};

/**
 * Client event processing
 * @param thd
 * @param buf
 * @return result
 */
void * APR_THREAD_FUNC in_on_task_cli_ctx(apr_thread_t *thd, void *buf);

/**
 * Create client context ipv4
 * @param name
 * @param sid
 * @param alloc_size
 * @param csock
 * @param conn_pool
 * @param conn_pool_allocator
 * @param server context
 * @param on_attach
 * @param on_detach
 * @param on_recv
 * @param on_send
 * @param pool
 * @return Client context
 */
IN_DECLARE(t_cli_ctx *) in_create_cli_ctx(
        const char * name,
        apr_uint16_t sid,
        apr_size_t alloc_size,
        apr_socket_t * csock,
        apr_pool_t * conn_pool,
        apr_allocator_t * conn_pool_allocator,
        t_srv_ctx * srv,
        t_cli_ctx_attach_callback on_attach,
        t_cli_ctx_detach_callback on_detach,
        t_cli_ctx_recv_callback on_recv,
        t_cli_ctx_send_callback on_send,
        t_cli_ctx_idle_callback on_idle,
        apr_pool_t * pool);

/**
 * Connect client context ipv4
 * @param name
 * @param sid
 * @param alloc_size
 * @param bind_ip_addr
 * @param bind_port
 * @param srv
 * @param on_attach
 * @param on_detach
 * @param on_recv
 * @param on_send
 * @param pool
 * @return Client context
 */
IN_DECLARE(t_cli_ctx *) in_create_cli_ctx_with_connect(
        const char * name,
        apr_uint16_t sid,
        apr_size_t alloc_size,
        const char * bind_ip_addr,
        const apr_uint16_t bind_port,
        t_srv_ctx * srv,
        t_cli_ctx_attach_callback on_attach,
        t_cli_ctx_detach_callback on_detach,
        t_cli_ctx_recv_callback on_recv,
        t_cli_ctx_send_callback on_send,
        t_cli_ctx_idle_callback on_idle,
        apr_pool_t * pool);

/**
 * Destory client context
 * @param cli
 * @return void
 */
IN_DECLARE(void) in_destroy_cli_ctx(t_cli_ctx * cli);

/**
 * Invoke destory client context
 * @param cli
 * @return void
 */
IN_DECLARE(void) in_invoke_destroy_cli_ctx(t_cli_ctx * cli);

/**
 * Send data with client context
 * @param cli
 * @param buf
 * @param size
 * @return size
 */
IN_DECLARE(int) in_send_cli_ctx(t_cli_ctx * cli, const char * buf, apr_size_t size);

/**
 * Set last error code and terminate client context
 * @param cli
 * @param last_error_code
 * @return void
 */
IN_DECLARE(void) in_set_last_error_code_cli_ctx(t_cli_ctx * cli, apr_int32_t last_error_code);

/**
 * Check client context
 * @param cli
 * @return true/false
 */
IN_DECLARE(bool) in_is_run_cli_ctx(t_cli_ctx * cli);

#endif /* _CLIENT_CONTEXT__H_ */

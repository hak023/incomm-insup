#include "logger.h"
#include "config.h"
#include "clientcontext.h"
#include "servercontext.h"

/**
* create_listen_socket
* @return
*/
static inline apr_socket_t* create_listen_socket(const char * addr, apr_uint16_t port, apr_pool_t * pool)
{
    apr_status_t rv;
    apr_sockaddr_t * sa;
    apr_socket_t * ls;
    if(addr == NULL || strlen(addr) == 0)
        rv = apr_sockaddr_info_get(&sa, NULL, APR_INET, port, 0, pool);
    else
        rv = apr_sockaddr_info_get(&sa, addr, APR_INET, port, 0, pool);
    if(rv != APR_SUCCESS) {
        LOGE("Problem generating sockaddr : %d\n", port);
        fprintf((FILE*)stderr, "Problem generating sockaddr : %d\n", port);
    }
    rv = apr_socket_create(&ls, sa->family, SOCK_STREAM, APR_PROTO_TCP, pool);
    if(rv != APR_SUCCESS) {
        LOGE("Problem creating socket : %d\n", port);
        fprintf((FILE*)stderr, "Problem creating socket : %d\n", port);
    }
#ifndef FEATURE_SO_LINGER
    rv = apr_socket_opt_set(ls, APR_SO_LINGER, 0);
    if(rv != APR_SUCCESS) {
        LOGE("Could not set SO_LINGER on socket : %d\n", port);
        fprintf((FILE*)stderr, "Could not set SO_LINGER on socket : %d\n", port);
    }
#endif
#ifdef FEATURE_REUSE_ADDR
    rv = apr_socket_opt_set(ls, APR_SO_REUSEADDR, 1);
    if(rv != APR_SUCCESS) {
        LOGE("Could not set REUSEADDR on socket : %d\n", port);
        fprintf((FILE*)stderr, "Could not set REUSEADDR on socket : %d\n", port);
    }
#endif
    rv = apr_socket_bind(ls, sa);
    if(rv != APR_SUCCESS) {
        LOGE("Problem binding to port : %d\n", port);
        fprintf((FILE*)stderr, "Problem binding to port : %d\n", port);
        return NULL;
    }
    rv = apr_socket_listen(ls, SOMAXCONN);
    if(rv != APR_SUCCESS) {
        LOGE("Problem listening on socket : %d\n", port);
        fprintf((FILE*)stderr, "Problem listening on socket : %d\n", port);
    }
    LOGI1("INFO", "Setup listen socket=%s:%d\n", (addr == NULL || strlen(addr) == 0) ? "" : addr, port);
    if (ls != NULL)
        return ls;
    APR_SAFE_CLOSE_SOCKET(ls);
    return NULL;
}


/**
 * in_create_srv_ctx
 * @return
 */
IN_DECLARE(t_srv_ctx *) in_create_srv_ctx(apr_pollset_t * pollset,
        const char * name, apr_uint16_t port, apr_int32_t max_connection, t_srv_ctx_accept_callback on_accept, apr_pool_t * pool) {
    t_srv_ctx * srv = (t_srv_ctx *)calloc(1, sizeof(t_srv_ctx));
    in_assert(srv);
    srv->sock = create_listen_socket(NULL, port, pool);
    if(srv->sock == NULL) {
        SAFE_FREE(srv);
        return NULL;
    }
    apr_status_t rv;
    if(pollset) {
        apr_pollfd_t pfd = { pool, APR_POLL_SOCKET, APR_POLLIN, 0, { NULL }, NULL };
        pfd.desc.s = srv->sock;
        pfd.client_data = srv;
        rv = apr_pollset_add(pollset, &pfd);
        in_assert(rv == APR_SUCCESS);
    }
    in_strncpy(srv->name, name, sizeof(srv->name));
    if(max_connection) {
        rv = apr_thread_pool_create(&srv->thd_pool, 0, max_connection, pool);
        in_assert(rv == APR_SUCCESS);
        srv->clis_count = 0;
        srv->clis = (t_cli_traverse_item *)calloc(max_connection, sizeof(t_cli_traverse_item));
        in_assert(srv->clis);
    }
    rv = apr_thread_mutex_create(&srv->mymutex, APR_THREAD_MUTEX_DEFAULT, pool);
    in_assert(rv == APR_SUCCESS);
    srv->mythd = apr_os_thread_current();
    srv->pool = pool;
    srv->port = port;
    srv->max_connection = max_connection;
    srv->on_accept = on_accept;
    srv->st_tot_accept_count = 0;
    return srv;
}

/**
 * in_create_cli_ctx_pool
 * @return
 */
IN_DECLARE(t_srv_ctx *) in_create_cli_ctx_pool(const char * name, apr_int32_t max_connection, apr_pool_t * pool) {
    t_srv_ctx * srv = (t_srv_ctx *)calloc(1, sizeof(t_srv_ctx));
    in_assert(srv);
    memset(srv, 0, sizeof(t_srv_ctx));
    apr_status_t rv;
    in_strncpy(srv->name, name, sizeof(srv->name));
    if(max_connection) {
        rv = apr_thread_pool_create(&srv->thd_pool, 0, max_connection, pool);
        in_assert(rv == APR_SUCCESS);
        srv->clis_count = 0;
        srv->clis = (t_cli_traverse_item *)calloc(max_connection, sizeof(t_cli_traverse_item));
        in_assert(srv->clis);
    }
    rv = apr_thread_mutex_create(&srv->mymutex, APR_THREAD_MUTEX_DEFAULT, pool);
    in_assert(rv == APR_SUCCESS);
    srv->mythd = apr_os_thread_current();
    srv->pool = pool;
    srv->max_connection = max_connection;
    return srv;
}


/**
 * in_destory_warm_srv_ctx
 * @return
 */
IN_DECLARE(void) in_destory_warm_srv_ctx(apr_pollset_t * pollset, t_srv_ctx * srv) {
    if(srv) {
        LOGV("#- Srv - Remove Poolset\n");
        if(pollset && srv->sock) {
            apr_pollfd_t pfd = { srv->pool, APR_POLL_SOCKET, APR_POLLIN, 0, { NULL }, NULL };
            pfd.desc.s = srv->sock;
            pfd.client_data = srv;
            apr_pollset_remove(pollset, &pfd);
        }
        LOGV("#- Srv - Close Socket\n");
        LOCK(srv->mymutex);
        APR_SAFE_CLOSE_SOCKET(srv->sock);
        LOGV("#- Srv - Invoke Destroy Client\n");
        for(int i = 0; i < srv->clis_count; ++i)
            in_invoke_destroy_cli_ctx(srv->clis[i].cli);
        UNLOCK(srv->mymutex);
    }
}

/**
 * in_destory_srv_ctx
 * @return
 */
IN_DECLARE(void) in_destory_srv_ctx(apr_pollset_t * pollset, t_srv_ctx * srv, bool include_warm) {
    if(srv) {
        if(include_warm) {
            in_destory_warm_srv_ctx(pollset, srv);
        }
        LOGV("#- Srv - Destroy Thd Pool\n");
#ifndef FEATURE_NO_WAIT_SRV_DESTROY
        if(srv->thd_pool != NULL)
            apr_thread_pool_destroy(srv->thd_pool);        
        srv->thd_pool = NULL;
#endif        
        LOCK(srv->mymutex);
        srv->clis_count = 0;
        SAFE_FREE(srv->clis);
        UNLOCK(srv->mymutex);
        if(srv->mymutex != NULL)
            apr_thread_mutex_destroy(srv->mymutex);
        srv->mymutex = NULL;
        SAFE_FREE(srv);
    }
}

static inline apr_int32_t cli_traverse_order(t_cli_traverse_item * a, t_cli_traverse_item * b)
{
    if(a->sid < b->sid)
        return -1;
    else if(a->sid > b->sid)
        return +1;
    return 0;
}

static inline apr_int32_t cli_traverse_search(apr_uint16_t * a, t_cli_traverse_item * b)
{
    if(*a < b->sid)
        return -1;
    else if(*a > b->sid)
        return +1;
    return 0;
}

/**
 * in_debug_desc_reg_clis
 * @return
 */
IN_DECLARE(void) in_debug_desc_reg_clis(t_srv_ctx * srv) {
    LOCK(srv->mymutex);
    printf(D_LOG_THIN_SEPERATOR);
    for(int i = 0; i < srv->clis_count; ++i) {
        t_cli_traverse_item * curr = srv->clis + i;
        printf("[%04d/%04d] 0x%04X, a(%lu), r(%lu) hdl(%lu)\n", i, srv->clis_count, 
            curr->sid, curr->accept_time, curr->reg_time, (apr_uintptr_t)curr->cli);
    }    
    UNLOCK(srv->mymutex);
}

/**
 * in_reg_cli_to_srv_ctx
 * @return
 */
IN_DECLARE(int) in_reg_cli_to_srv_ctx(t_srv_ctx * srv, t_cli_ctx * cli) {
    if(srv && srv->clis) {
        LOCK(srv->mymutex);
        if(srv->clis_count == srv->max_connection) {
            UNLOCK(srv->mymutex);
            return IN_FAIL;
        }
        t_cli_traverse_item * empty = srv->clis + srv->clis_count++;
        empty->sid = cli->sid;
        empty->cli = cli;
        empty->accept_time = apr_time_now();
        empty->reg_time = 0;
        qsort(srv->clis, srv->clis_count, sizeof(t_cli_traverse_item), (int (*)(const void*, const void*))cli_traverse_order);
        UNLOCK(srv->mymutex);
        /*printf("Reg %lu (%d)\n", (apr_uintptr_t)cli, srv->clis_count);*/
        return IN_SUCCESS;
    }
	return IN_FAIL;
}

/**
 * in_update_cli_reg_info_to_srv_ctx_with_client_mode
 * @return
 */
IN_DECLARE(int) in_update_cli_reg_info_to_srv_ctx_with_client_mode(t_srv_ctx * srv, t_cli_ctx * cli, apr_uint16_t sid) {
    if(srv && srv->clis && sid) {
        LOCK(srv->mymutex);
        t_cli_traverse_item * find = NULL;
        for(int i = 0; i < srv->clis_count; ++i) {
            t_cli_traverse_item * curr = srv->clis + i;
            if(curr->cli == cli) {
                find = curr;
                break;
            }
        }
        if(find == NULL) {
            UNLOCK(srv->mymutex);
            return IN_FAIL;
        }
        apr_atomic_cas32(&cli->isrun, 2, 1);
        find->reg_time = apr_time_now();
        UNLOCK(srv->mymutex);
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

/**
 * in_update_cli_reg_info_to_srv_ctx
 * @return
 */
IN_DECLARE(int) in_update_cli_reg_info_to_srv_ctx(t_srv_ctx * srv, t_cli_ctx * cli, apr_uint16_t sid) {
    if(srv && srv->clis && sid) {
        LOCK(srv->mymutex);
        t_cli_traverse_item * find = NULL;
        for(int i = 0; i < srv->clis_count; ++i) {
            t_cli_traverse_item * curr = srv->clis + i;
            if(curr->cli == cli) {
                find = curr;
                break;
            }
        }
        if(find == NULL) {
            UNLOCK(srv->mymutex);
            return IN_FAIL;
        }
        /*printf("Update exist finding 0x%0X %lu (%d)\n", sid, (apr_uintptr_t)find->cli, srv->clis_count);*/
        t_cli_traverse_item * exist_find = NULL;
        exist_find = (t_cli_traverse_item *)bsearch(&sid, srv->clis, srv->clis_count,
            sizeof(t_cli_traverse_item), (int (*)(const void*, const void*))cli_traverse_search); 
        if(exist_find) {
            if(exist_find->cli) {
                in_set_last_error_code_cli_ctx(exist_find->cli, IN_ERR_LOGIN_SAME_SIG);
            }
#if 0       /* Do not need remove logic beacuse delete at destroing time */
            /*printf("=> Exist dropped 0x%0X %lu (%d)\n", exist_find->sid, (apr_uintptr_t)exist_find->cli, srv->clis_count);*/
            int currindex = (int)(((apr_uintptr_t)exist_find - (apr_uintptr_t)srv->clis)/sizeof(t_cli_traverse_item));
            int num = srv->clis_count - currindex - 1;
            if(num > 0) {
                memmove(srv->clis+currindex, srv->clis+currindex+1, num * sizeof(t_cli_traverse_item));
            }
            --srv->clis_count;
#endif
        }
        apr_atomic_cas32(&cli->isrun, 2, 1);
        find->sid = sid;
        find->reg_time = apr_time_now();
        qsort(srv->clis, srv->clis_count, sizeof(t_cli_traverse_item), (int (*)(const void*, const void*))cli_traverse_order);
        UNLOCK(srv->mymutex);
        /*in_debug_desc_reg_clis(srv);*/
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

/**
 * in_unreg_cli_to_srv_ctx
 * @return
 */
IN_DECLARE(int) in_unreg_cli_to_srv_ctx(t_srv_ctx * srv, t_cli_ctx * cli) {
    if(srv && srv->clis) {        
        LOCK(srv->mymutex);
        if(srv->clis_count == 0) {
            UNLOCK(srv->mymutex);
            return IN_FAIL;
        }
        t_cli_traverse_item * find = NULL;
        t_cli_ctx * find_lock_cli = NULL;
        for(int i = 0; i < srv->clis_count; ++i) {
            t_cli_traverse_item * curr = srv->clis + i;
            if(curr->cli == cli) {
                find = curr;
                find_lock_cli = cli;
                LOCK(find_lock_cli->mymutex);
                break;
            }
        }
        if(find) {
            /*printf("Unreg 0x%0X %lu (%d)\n", find->sid, (apr_uintptr_t)find->cli, srv->clis_count);*/
            find->sid = 0;
            find->cli = NULL;
            find->accept_time = find->reg_time = 0;
            int currindex = (int)(((apr_uintptr_t)find - (apr_uintptr_t)srv->clis)/sizeof(t_cli_traverse_item));
            int num = srv->clis_count - currindex - 1;
            if(num > 0) {
                memmove(srv->clis+currindex, srv->clis+currindex+1, num * sizeof(t_cli_traverse_item));
            }
            --srv->clis_count;
        }
        if(find_lock_cli) {
            UNLOCK(find_lock_cli->mymutex);
        }
        UNLOCK(srv->mymutex);
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

/**
 * in_find_and_send_cli
 * @return
 */
IN_DECLARE(int) in_find_and_send_cli(t_srv_ctx * srv, apr_uint16_t sid, const char * buf, apr_size_t size) {
    int result = IN_FAIL;
    if(srv && sid) {
        t_cli_ctx * cli = NULL;
        LOCK(srv->mymutex);
        if(srv->clis_count == 0) {
            UNLOCK(srv->mymutex);
            return result;
        }
        const t_cli_traverse_item * find = (const t_cli_traverse_item *)bsearch(&sid, srv->clis, srv->clis_count,
            sizeof(t_cli_traverse_item), (int (*)(const void*, const void*))cli_traverse_search);
        if(find && find->cli) {
            cli = find->cli;
            LOCK(cli->mymutex);
        }
        UNLOCK(srv->mymutex);
        if(cli) {
            if(in_is_run_cli_ctx(cli))
                result = cli->on_send(cli, buf, size);
            UNLOCK(cli->mymutex);
        }
    }
    return result;
}

/**
 * in_broadcast_send_cli
 * @return
 */
IN_DECLARE(int) in_broadcast_send_cli(t_srv_ctx * srv, const char * buf, apr_size_t size) {
    int result = IN_SUCCESS;
    if(srv) {
        t_cli_ctx * cli = NULL;
        LOCK(srv->mymutex);
        if(srv->clis_count == 0) {
            UNLOCK(srv->mymutex);
            return result;
        }
        for(int i = 0; i < srv->clis_count; ++i) {
            t_cli_traverse_item * curr = srv->clis + i;
            if(curr && curr->cli) {
                cli = curr->cli;
                LOCK(cli->mymutex);
            } 
        }
        UNLOCK(srv->mymutex);
        if(cli) {
            if(in_is_run_cli_ctx(cli)) {
                if(cli->on_send(cli, buf, size) != IN_SUCCESS) {
                    result = IN_FAIL;
                }
            }
            UNLOCK(cli->mymutex);
        }
    }
    return result;
}

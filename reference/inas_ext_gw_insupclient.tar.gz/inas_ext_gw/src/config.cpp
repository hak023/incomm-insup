#include "logger.h"
#include "iniparser.h"
#include "proc.h"
#include "config.h"

static t_conf g_conf;

static void generate_description(char * desc, int size, t_conf * conf) {
    snprintf(desc, size, ""
            "| Info\n"
            "  System\t\t='%s'[%c]\n"            
            "  Process\t\t='%s'[%c]\n"
            "| Server\n"
            "  Listen Port\t\t= %d\n"
            "  Max Connection\t= %d\n"
            "| Plugin\n"
            "  Name\t\t\t='%s'\n"
            "  Path\t\t\t='%s'\n"
            "| Manage \n"
            "  Check Interval\t= %d(ms)\n"
            "  Login Timeout\t\t= %d(ms)\n"
            "  Heartbeat Timeout\t= %d(ms)\n"
            "  Supported Max TPS\t= %d\n"
            "| Logger\n"
            "  Log Path\t\t= %s\n"
            "  Log Level\t\t= %d\n"
            "  Rolling\t\t= %d\n"
            "  Max Count\t\t= %d\n"
            "  Max Size\t\t= %lu(bytes)\n"
            "| OAM\n"
            "  Use OAM Info File\t= %d\n"
            "  Use OAM Send Info\t= %d\n"
            "  Dgram Listen Addr\t='%s:%d'\n"
            ,
            conf->sys.name, conf->sys.state[0],
            conf->proc.srcid, conf->proc.state[0],
            conf->server.port, conf->server.max_connection,
            conf->plugin.name, conf->plugin.path,
            conf->manage.check_interval,conf->manage.login_timeout,conf->manage.heartbeat_timeout, conf->manage.supported_max_tps,
            conf->logger.log_path, conf->logger.log_level, conf->logger.rolling, conf->logger.max_count, conf->logger.max_size,
            conf->oam.use_oam_info_file, conf->oam.use_send_dgram_feature,
            conf->oam.oam_dgram_ip, conf->oam.oam_dgram_port
            );
}

static char * next_tokenize(char *& out, char * ptr, char token) {
    out = NULL;
    if(ptr && *ptr) {
        char * begin = ptr;
        ptr = strchr(ptr, token); 
        if(ptr) {
            *ptr++ = 0;
            out = begin;
            return ptr;
        }
        else {
            out = begin;
        }
    }
    return NULL;
}

static int reload_conf(t_conf * conf) {
    int rv = IN_SUCCESS;
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) {
        return IN_FAIL;
    }
    dictionary * d = iniparser_load(conf->path);
    if(d == NULL) {
        fprintf((FILE*)stderr, "Can not reload configuration file : %s\n", conf->path);
        LOGE("Can not reload configuration file : %s\n", conf->path);
        rv = IN_FAIL; goto GT_EXIT;
    }
    LOCK(conf->mymutex);
    in_strncpy(conf->proc.srcid, iniparser_getstring(d, "proc:srcid", (char*)"0000"), sizeof(conf->proc.srcid));
    in_strncpy(conf->proc.state, iniparser_getstring(d, "proc:state", (char*)"A"), sizeof(conf->proc.state));
    conf->manage.check_interval = iniparser_getint(d, "manage:check_interval", 5000);
    conf->manage.login_timeout = iniparser_getint(d, "manage:login_timeout", 5000);
    conf->manage.heartbeat_timeout = iniparser_getint(d, "manage:heartbeat_timeout", 60000);
    conf->manage.supported_max_tps = iniparser_getint(d, "manage:supported_max_tps", 0);
    conf->status.disp_status = iniparser_getint(d, "status:disp_status", 0);
    conf->status.disp_status_inbound = iniparser_getint(d, "status:disp_status_inbound", 0);
    conf->status.disp_status_outbound = iniparser_getint(d, "status:disp_status_outbound", 0);
    conf->status.disp_status_fail_count = iniparser_getint(d, "status:disp_status_fail_count", 0);
    conf->logger.log_level = iniparser_getint(d, "logger:loglevel", 2);
    conf->logger.max_count = iniparser_getint(d, "logger:count", 0);
    conf->logger.max_size = iniparser_getint(d, "logger:size", 10000000);
    conf->oam.use_login_feature = iniparser_getint(d, "oam:use_login_feature", 1);
    conf->oam.use_oam_info_file = iniparser_getint(d, "oam:use_oam_info_file", 1);
    conf->oam.use_send_dgram_feature = iniparser_getint(d, "oam:use_send_dgram_feature", 1);
    {
        conf->inbound_num = 0;
        for(int i = 0; i <= D_MAX_SESSION; ++ i)
            strncpy(conf->inbound[i].name, "Unknown", sizeof(conf->inbound[i].name));
        int nkeys = iniparser_getsecnkeys(d, (char *)"inbound");
        if(nkeys) {
            char ** keys = iniparser_getseckeys(d, (char *)"inbound");
            for(int i = 0; keys && i < nkeys; ++i) {
                int sid = in_atou(strchr(keys[i], ':')+1);
                char * name = NULL, * ipaddr = NULL, * state = NULL;
                char * ptr = iniparser_getstring(d, keys[i], (char*)"");
                ptr = next_tokenize(name, ptr, ',');
                ptr = next_tokenize(ipaddr, ptr, ',');
                ptr = next_tokenize(state, ptr, ',');
                if(name && ipaddr && strlen(ipaddr) && state) {
                    conf->inbound[sid].used = true;
                    strncpy(conf->inbound[sid].name, name, sizeof(conf->inbound[sid].name));
                    conf->inbound[sid].state[0] = *state;
                    strncpy(conf->inbound[sid].ipaddr, ipaddr, sizeof(conf->inbound[sid].ipaddr));
                    ++conf->inbound_num;
                }
            }
            SAFE_FREE(keys);
        }
    }    
    UNLOCK(conf->mymutex);
    iniparser_freedict(d);
    if(conf->oam.sys_info_file[0]) {
        d = iniparser_load(conf->oam.sys_info_file);
        LOCK(conf->mymutex);
        in_strncpy(conf->sys.state, iniparser_getstring(d, "sys:state", (char*)"A"), sizeof(conf->sys.state));
        UNLOCK(conf->mymutex);
        iniparser_freedict(d);
    }
GT_EXIT:
    return rv;
}

static int load_conf(t_conf * conf) {
    int rv = IN_SUCCESS;
    const t_proc_rec * rec = get_proc_rec();
    if(rec == NULL) { 
        return IN_FAIL;
    }     
    dictionary * d = iniparser_load(conf->path);
    if(d == NULL) {
        fprintf((FILE*)stderr, "Can not load configuration file : %s\n", conf->path);
        LOGE("Can not load configuration file : %s\n", conf->path);
        rv = IN_FAIL; goto GT_EXIT;
    }
    LOCK(conf->mymutex);
    conf->server.port = iniparser_getint(d, "server:listen_port", 0);
    conf->server.max_connection = iniparser_getint(d, "server:max_connection", D_MAX_SESSION);
    if(conf->server.max_connection > D_MAX_SESSION) conf->server.max_connection = D_MAX_SESSION;
    in_strncpy(conf->plugin.name, iniparser_getstring(d, "plugin:name", (char*)"unknown.so"), sizeof(conf->plugin.name));
    in_strncpy(conf->plugin.path, iniparser_getstring(d, "plugin:path", (char*)"unknown.so"), sizeof(conf->plugin.path));
    in_strncpy(conf->logger.log_path, iniparser_getstring(d, "logger:logfile", (char*)"unknown.log"), sizeof(conf->logger.log_path));
    conf->logger.rolling = iniparser_getint(d, "logger:rolling", 1);
    in_strncpy(conf->oam.oam_info_file, iniparser_getstring(d, "oam:oam_info_file", (char*)"unknown.map"), sizeof(conf->oam.oam_info_file));
    in_strncpy(conf->oam.oam_dgram_ip, iniparser_getstring(d, "oam:oam_dgram_ip", (char*)"127.0.0.1"), sizeof(conf->oam.oam_dgram_ip));
    conf->oam.oam_dgram_port = iniparser_getint(d, "oam:oam_dgram_port", 4854);
    in_strncpy(conf->oam.sys_info_file, iniparser_getstring(d, "oam:sys_info_file", (char*)"unknown.ini"), sizeof(conf->oam.sys_info_file));
    {
        for(int i = 0; i <= D_MAX_SESSION; ++ i)
            strncpy(conf->outbound[i].name, "Unknown", sizeof(conf->outbound[i].name));
        int nkeys = iniparser_getsecnkeys(d, (char *)"outbound");
        if(nkeys) {
            char ** keys = iniparser_getseckeys(d, (char *)"outbound");
            for(int i = 0; keys && i < nkeys; ++i) {
                int sid = in_atou(strchr(keys[i], ':')+1);
                char * name = NULL, * ipaddr = NULL, * port = NULL;
                char * ptr = iniparser_getstring(d, keys[i], (char*)"");
                ptr = next_tokenize(name, ptr, ',');
                ptr = next_tokenize(ipaddr, ptr, ',');
                ptr = next_tokenize(port, ptr, ',');
                if(name && ipaddr && port && strlen(ipaddr) && strlen(port)) {
                    conf->outbound[sid].used = true;
                    strncpy(conf->outbound[sid].name, name, sizeof(conf->outbound[sid].name));
                    strncpy(conf->outbound[sid].ipaddr, ipaddr, sizeof(conf->outbound[sid].ipaddr));
                    conf->outbound[sid].port = in_atou(port);
                    ++conf->outbound_num;
                }
            }
            SAFE_FREE(keys);
        }
    }
    {
        int nkeys = iniparser_getsecnkeys(d, (char *)"outbound_plugin");
        if(nkeys) {
            char ** keys = iniparser_getseckeys(d, (char *)"outbound_plugin");
            for(int i = 0; keys && i < nkeys; ++i) {
                int sid = in_atou(strchr(keys[i], ':')+1);
                char * addinfos = iniparser_getstring(d, keys[i], (char*)"");
                if(addinfos && strlen(addinfos)) {
                    strncpy(conf->outbound_plugin[sid].info, addinfos, sizeof(conf->outbound_plugin[sid].info));
                }
            }
            SAFE_FREE(keys);
        }
    }
    UNLOCK(conf->mymutex);
    iniparser_freedict(d);
    if(conf->oam.sys_info_file[0]) {
        d = iniparser_load(conf->oam.sys_info_file);
        LOCK(conf->mymutex);
        in_strncpy(conf->sys.name, iniparser_getstring(d, "sys:name", (char*)"unknown"), sizeof(conf->sys.name));        
        {
            int namelen = strlen(rec->name);
            int nkeys = iniparser_getsecnkeys(d, (char *)"srcids");
            if(nkeys) {
                char ** keys = iniparser_getseckeys(d, (char *)"srcids");
                for(int i = 0; keys && i < nkeys; ++i) {
                    if(strncmp(rec->name, strchr(keys[i], ':')+1, namelen) == 0) {
                        in_strncpy(conf->proc.srcid, iniparser_getstring(d, keys[i], (char*)"0000"), sizeof(conf->proc.srcid));
                        break;
                    }
                }
                SAFE_FREE(keys);
            }
        }
        UNLOCK(conf->mymutex);
        iniparser_freedict(d);
    }        
    rv = reload_conf(conf);
    if(strlen(conf->proc.srcid) != 4) {
        fprintf((FILE*)stderr, "Invalid source id '%s'. length to be '4'.\n", conf->proc.srcid);
        rv = IN_FAIL; goto GT_EXIT;
    }
GT_EXIT:
    return rv;
}

/*
 * in_create_conf
 * @return
 */
IN_DECLARE(t_conf *) in_create_conf(const char * path, apr_pool_t * pool) {
    t_conf * conf = (t_conf *)calloc(1, sizeof(t_conf));
    in_assert(conf);
    apr_status_t rv = apr_thread_mutex_create(&conf->mymutex, APR_THREAD_MUTEX_DEFAULT, pool);
    in_assert(rv == APR_SUCCESS);
    in_strncpy(conf->path, path, sizeof(conf->path));
    conf->mythd = apr_os_thread_current();
    conf->pool = pool;
    rv = load_conf(conf);
    if(rv != IN_SUCCESS) {
        in_destroy_conf(conf);
        return NULL;
    }
    char clog[8192] = {0,};
    LOCK(conf->mymutex);
    generate_description(clog, sizeof(clog), conf);
    UNLOCK(conf->mymutex);
    printf( D_LOG_BOLD_SEPERATOR"Loaded configuration, Path ='%s'\n%s"
            D_LOG_BOLD_SEPERATOR, conf->path, clog);
    return conf;
}

/*
 * in_create_conf_global
 * @return
 */
IN_DECLARE(t_conf *) in_create_conf_global(const char * path, apr_pool_t * pool) {
    t_conf * conf = &g_conf;
    apr_status_t rv = apr_thread_mutex_create(&conf->mymutex, APR_THREAD_MUTEX_DEFAULT, pool);
    in_assert(rv == APR_SUCCESS);
    in_strncpy(conf->path, path, sizeof(conf->path));
    conf->mythd = apr_os_thread_current();
    conf->pool = pool;
    rv = load_conf(conf);
    if(rv != IN_SUCCESS) {
        in_destroy_conf_global();
        return NULL;
    }
    char clog[8192] = {0,};
    LOCK(conf->mymutex);
    generate_description(clog, sizeof(clog), conf);
    UNLOCK(conf->mymutex);
    printf( D_LOG_BOLD_SEPERATOR"Loaded configuration, Path ='%s'\n%s"
            D_LOG_BOLD_SEPERATOR, conf->path, clog);
    return conf;
}

/*
 * in_destroy_conf
 * @return
 */
IN_DECLARE(void) in_destroy_conf(t_conf * conf) {
    if(conf) {
        if(conf->mymutex != NULL)
            apr_thread_mutex_destroy(conf->mymutex);
        conf->mymutex = NULL;
        SAFE_FREE(conf);
    }
}

/*
 * in_destroy_conf_global
 * @return
 */
IN_DECLARE(void) in_destroy_conf_global(void) {
    t_conf * conf = &g_conf;
    if(conf->mymutex != NULL)
        apr_thread_mutex_destroy(conf->mymutex);
    conf->mymutex = NULL;
}

/*
 * in_reload_conf_info
 * @return
 */
IN_DECLARE(int) in_reload_conf_info(t_conf * conf) {
    if(conf) {
        if(reload_conf(conf) == IN_SUCCESS) {
            in_desc_conf(conf);
            return IN_SUCCESS;
        }
    }
    return IN_FAIL;
}

/*
 * in_reload_conf_info_global
 * @return
 */
IN_DECLARE(int) in_reload_conf_info_global(void) {
    t_conf * conf = &g_conf;
    if(reload_conf(conf) == IN_SUCCESS) {
        in_desc_conf(conf);
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

/*
 * in_get_conf
 * @return
 */
IN_DECLARE(int) in_get_conf(t_conf * OUT dst, t_conf * IN src) {
    if(src) {
        t_conf * conf = src;
        LOCK(conf->mymutex);
        memcpy(dst, src, sizeof(t_conf));
        UNLOCK(conf->mymutex);
        return IN_SUCCESS;
    }
    memset(dst, 0, sizeof(t_conf));
    return IN_FAIL;
}

/*
 * in_get_conf_global_ref
 * @return
 */
IN_DECLARE(t_conf *) in_get_conf_global_ref(void) {
    return &g_conf;
}

/*
 * in_get_conf_logger_level
 * @return
 */
IN_DECLARE(apr_int32_t) in_get_conf_logger_level(t_conf * conf) {
    if(conf) {
        return conf->logger.log_level;
    }
    return 2;
}

/*
 * in_get_conf_logger_level_global
 * @return
 */
IN_DECLARE(apr_int32_t) in_get_conf_logger_level_global(void) {
    return g_conf.logger.log_level;
}

/**
 * in_get_conf_state_global
 * @return
 */
IN_DECLARE(char) in_get_conf_state_global(void) {
    return g_conf.sys.state[0] == 'B' ? 'B' : g_conf.proc.state[0] ? g_conf.proc.state[0] : '-';
}


/*
 * in_desc_conf
 * @return
 */
IN_DECLARE(void) in_desc_conf(t_conf * conf) {
    char clog[8192] = {0,};
    LOCK(conf->mymutex);
    generate_description(clog, sizeof(clog), conf);
    UNLOCK(conf->mymutex);
    LOGS( "\n"D_LOG_BOLD_SEPERATOR"Desc. configuration, Path ='%s'\n%s"
          D_LOG_BOLD_SEPERATOR, conf->path, clog);
}

#include "logger.h"

static t_logger * g_logger = NULL;

static int inline generate_file_tag_time_string(char * buf, apr_size_t size, apr_time_t t) {
    apr_time_exp_t timeinfo;
    apr_time_exp_tz(&timeinfo, t, 32400);
    timeinfo.tm_year += 1900;
    timeinfo.tm_mon ++;
    buf[0] = (timeinfo.tm_year / 1000) % 10 + '0' ;
    buf[1] = (timeinfo.tm_year / 100) % 10 + '0';
    buf[2] = (timeinfo.tm_year / 10) % 10 + '0';
    buf[3] = (timeinfo.tm_year % 10) + '0';
    buf[4] = (timeinfo.tm_mon / 10) % 10 + '0';
    buf[5] = (timeinfo.tm_mon % 10) + '0';
    buf[6] = (timeinfo.tm_mday / 10) % 10 + '0';
    buf[7] = (timeinfo.tm_mday % 10) + '0';
    buf[8] = 0;
    return 8;
}

static int inline generate_log_tag_time_string(char * buf, apr_size_t size, apr_time_t t) {
    apr_time_exp_t timeinfo;
    apr_time_exp_tz(&timeinfo, t, 32400);
    timeinfo.tm_year += 1900;
    timeinfo.tm_mon ++;
    buf[0] = (timeinfo.tm_year / 1000) % 10 + '0' ;
    buf[1] = (timeinfo.tm_year / 100) % 10 + '0';
    buf[2] = (timeinfo.tm_year / 10) % 10 + '0';
    buf[3] = (timeinfo.tm_year % 10) + '0';
    buf[4] = '/';
    buf[5] = (timeinfo.tm_mon / 10) % 10 + '0';
    buf[6] = (timeinfo.tm_mon % 10) + '0';
    buf[7] = '/';
    buf[8] = (timeinfo.tm_mday / 10) % 10 + '0';
    buf[9] = (timeinfo.tm_mday % 10) + '0';
    buf[10] = ' ';
    buf[11] = (timeinfo.tm_hour / 10) % 10 + '0';
    buf[12] = (timeinfo.tm_hour % 10) + '0';
    buf[13] = ':';
    buf[14] = (timeinfo.tm_min / 10) % 10 + '0';
    buf[15] = (timeinfo.tm_min % 10) + '0';
    buf[16] = ':';
    buf[17] = (timeinfo.tm_sec / 10) % 10 + '0';
    buf[18] = (timeinfo.tm_sec % 10) + '0';
    buf[19] = '.';
    buf[20] = (t / 100000L) % 10 + '0' ;
    buf[21] = (t / 10000L) % 10 + '0' ;
    buf[22] = (t / 1000L) % 10 + '0' ;
    buf[23] = (t / 100L) % 10 + '0' ;
    buf[24] = (t / 10L) % 10 + '0' ;
    buf[25] = (t % 10L) + '0';
    buf[26] = 0;
    return 26;
}

static inline void check_and_rolling(t_logger * logger) {
    if(logger && logger->fd && logger->mythd == apr_os_thread_current()) {
        apr_off_t offset = 0;
        apr_file_seek(logger->fd, APR_END, &offset);
        bool is_changed_date = false;
        char curr_date[D_STR_TIME_SIZE] = {0,}, last_date[D_STR_TIME_SIZE] = {0,};
        if(!logger->rolling) {
            generate_file_tag_time_string(curr_date, sizeof(curr_date), apr_time_now());
            if(memcmp(logger->last_date, curr_date, 8) != 0) {
                in_strncpy(last_date, logger->last_date, sizeof(last_date));
                in_strncpy(logger->last_date, curr_date, sizeof(logger->last_date));                
                is_changed_date = true;
            }
        }
        if((logger->max_size != 0 && offset >= logger->max_size) || is_changed_date) {
            apr_file_puts("<!--####### Rolling Marker #######-->\n", logger->fd);
            apr_file_flush(logger->fd);
            char to_path[D_PATH_SIZE] = {0,};
            if(!logger->rolling) {
                const char * name = in_get_name_with_fullpath(logger->path);
                char path_only[D_PATH_SIZE] = {0,};
                in_get_path_with_fullpath(path_only, sizeof(path_only), logger->path);
                snprintf(to_path, sizeof(to_path), "%s%c%s_%s.%03u", path_only, D_PATH_SEPERATOR, last_date[0]?last_date:curr_date, name, logger->curr_count);
                if(is_changed_date) {
                    logger->curr_count = 0;
                } else {
                    ++logger->curr_count;
                }
            }
            else {
                snprintf(to_path, sizeof(to_path), "%s.%03u", logger->path, logger->curr_count);
                ++logger->curr_count;
            }            
            if((logger->max_count != 0 && logger->curr_count >= logger->max_count) || logger->curr_count >= 999) {
                logger->curr_count = 0;
            }
            apr_file_close(logger->fd); logger->fd = NULL;
            apr_file_rename(logger->path, to_path, logger->pool);
            if(apr_file_open(&logger->fd, logger->path,
                APR_FOPEN_WRITE|APR_FOPEN_CREATE|APR_FOPEN_TRUNCATE, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE|APR_WREAD|APR_WWRITE, logger->pool) != APR_SUCCESS) {
                logger->fd = NULL;
            }
            else {
                apr_file_puts("<!--####### Begin Marker #######-->\n", logger->fd);
            }
        }
    }
}

static inline int check_curr_count(const char * path, int rolling, int max_count, apr_pool_t * pool) {
    int curr_count = 0;
    apr_status_t rv;
    apr_dir_t * log_dir = NULL;
    apr_finfo_t finfo;
    apr_int32_t finfo_flags = APR_FINFO_TYPE | APR_FINFO_NAME | APR_FINFO_MTIME;
    const char * name_only = in_get_name_with_fullpath(path);
    char path_only[D_PATH_SIZE] = {0,};
    in_get_path_with_fullpath(path_only, sizeof(path_only), path);
    rv = apr_dir_open(&log_dir, path_only, pool);
    if(rv == APR_SUCCESS) {
        int name_len = strlen(name_only);
        apr_time_t last_mtime = 0;
        char last_fname[D_PATH_SIZE] = {0,};
        char curr_date[D_STR_TIME_SIZE] = {0,};
        generate_file_tag_time_string(curr_date, sizeof(curr_date), apr_time_now());
        for(;;) {
            rv = apr_dir_read(&finfo, finfo_flags, log_dir);
            if(APR_STATUS_IS_ENOENT(rv)) break;
            if(finfo.filetype == APR_REG) /* Only regular file, no dir and link */ {
                if(strcmp(name_only, finfo.name) != 0) {
                    if(rolling) {
                        if(memcmp(name_only, finfo.name, name_len) == 0) {
                            if(finfo.mtime > last_mtime) {
                                last_mtime = finfo.mtime;
                                in_strncpy(last_fname, finfo.name, sizeof(last_fname));
                            }
                        }
                    }
                    else {
                        if(memcmp(curr_date, finfo.name, 8) == 0 && memcmp(name_only, finfo.name+9, name_len) == 0) {
                            if(finfo.mtime > last_mtime) {
                                last_mtime = finfo.mtime;
                                in_strncpy(last_fname, finfo.name, sizeof(last_fname));
                            }
                        }
                    }
                }
            }
        }
        apr_dir_close(log_dir);
        const int len = strlen(last_fname);
        if(len) {
            curr_count = atoi(last_fname+(len-3))+1;
            if((max_count != 0 && curr_count >= max_count) || curr_count >= 999) {
                curr_count = 0;
            }
        }
    }
    return curr_count;
}

static inline int write_log(t_logger * logger, const int lv, const char * fname, const int line, const char * key, const char * clog) {
    if(logger) {
        LOCK(logger->mymutex);
        if(logger->fd) {
            if(apr_file_puts(clog, logger->fd) == APR_SUCCESS) {
                check_and_rolling(logger);
            }
            else {
                if(logger->mythd == apr_os_thread_current()) {
                    apr_file_close(logger->fd); logger->fd = NULL;
                }                
            }
        }
        else {
            if(logger->mythd == apr_os_thread_current()) {
                if(apr_file_open(&logger->fd, logger->path,
                    APR_FOPEN_WRITE|APR_FOPEN_CREATE|APR_FOPEN_TRUNCATE, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE|APR_WREAD|APR_WWRITE, logger->pool) != APR_SUCCESS) {
                    logger->fd = NULL;                
                }
                else {
                    apr_file_puts(clog, logger->fd);
                }
            }
        }
        UNLOCK(logger->mymutex);
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

/**
 * in_create_logger
 * @return
 */
IN_DECLARE(t_logger *) in_create_logger(const char * path, int rolling, int level, apr_uint32_t max_count, apr_off_t max_size, apr_pool_t * pool) {
    t_logger * logger = (t_logger *)calloc(1, sizeof(t_logger));
    in_assert(logger);
    apr_status_t rv;
    rv = apr_thread_mutex_create(&logger->mymutex, APR_THREAD_MUTEX_DEFAULT, pool);
    in_assert(rv == APR_SUCCESS);
    char path_only[D_PATH_SIZE] = {0,};
    in_get_path_with_fullpath(path_only, sizeof(path_only), path);
    rv = apr_dir_make_recursive(path_only, 0x0775, pool);
    in_assert(rv == APR_SUCCESS);
    int curr_count = check_curr_count(path, rolling, max_count, pool);
    rv = apr_file_open(&logger->fd, path,
        APR_FOPEN_WRITE|APR_FOPEN_CREATE|APR_FOPEN_APPEND, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE|APR_WREAD|APR_WWRITE, pool);
    in_assert(rv == APR_SUCCESS);
    in_strncpy(logger->path, path, sizeof(logger->path));
    generate_file_tag_time_string(logger->last_date, sizeof(logger->last_date), apr_time_now());
    logger->mythd = apr_os_thread_current();
    logger->level = level;
    logger->rolling = rolling;
    logger->curr_count = curr_count;
    logger->max_count = max_count;
    logger->max_size = max_size;
    logger->pool = pool;
    apr_file_printf(logger->fd, "Create Logger, Path = '%s'\n"
        "<!--####### Begin Marker = IsRolling:%d, Level:%d, Curr Count : %d, Max Count:%u, Max Size:%u #######-->\n",
        logger->path, rolling, level, curr_count, max_count, (apr_uint32_t)max_size);
    return logger;
}

/**
 * in_destory_logger
 * @return
 */
IN_DECLARE(void) in_destroy_logger(t_logger * logger) {
    if(logger) {
        LOCK(logger->mymutex);
        if(logger->fd) {
            if(logger->mythd == apr_os_thread_current()) {
                apr_file_printf(logger->fd, "Destroy Logger, Path = '%s'\n"
                        "<!--####### End Marker #######-->\n", logger->path);
            }
            else {
                apr_file_printf(logger->fd, "Destroy Logger But Difference Owner Thread, Path = '%s'\n"
                        "<!--####### End Marker #######-->\n", logger->path);
            }
            apr_file_close(logger->fd);
            logger->fd = NULL;
        }
        UNLOCK(logger->mymutex);
        if(logger->mymutex != NULL)
            apr_thread_mutex_destroy(logger->mymutex);
        logger->mymutex = NULL;
        SAFE_FREE(logger);
    }
}

/**
 * in_destroy_logger_global
 * @return
 */
IN_DECLARE(void) in_destroy_logger_global() {
    in_destroy_logger(g_logger);
    g_logger = NULL;
}

/**
 * in_set_global_logger
 * @return
 */
IN_DECLARE(void) in_set_global_logger(t_logger * logger) {
    in_destroy_logger_global();
    LOCK(logger->mymutex);
    g_logger = logger;
    UNLOCK(logger->mymutex);
}

/**
 * in_set_logger_info
 * @return
 */
IN_DECLARE(int) in_set_logger_info(t_logger * logger, int level, apr_uint32_t max_count, apr_off_t max_size) {
    if(logger) {
        LOCK(logger->mymutex);
        logger->level = level;
        logger->max_count = max_count;
        logger->max_size = max_size;
        if(logger->fd != NULL) {
            apr_file_printf(logger->fd, "<!--####### Change Config = IsRolling:%d, Level:%d, Max Count:%u, Max Size:%u #######-->\n",
                    logger->rolling, level, max_count, (apr_uint32_t)max_size);
        }
        UNLOCK(logger->mymutex);
        return IN_SUCCESS;
    }
    return IN_FAIL;
}

/**
 * in_set_logger_info_global
 * @return
 */
IN_DECLARE(int) in_set_logger_info_global(int level, apr_uint32_t max_count, apr_off_t max_size) {
    return in_set_logger_info(g_logger, level, max_count, max_size);
}

/**
 * in_check_and_rolling_logger
 * @return
 */
IN_DECLARE(void) in_check_and_rolling_logger(t_logger * logger) {
    if(logger) {
        LOCK(logger->mymutex);
        if(logger->fd) {
            check_and_rolling(logger);
        }
        else {
            if(logger->mythd == apr_os_thread_current()) {
                if(apr_file_open(&logger->fd, logger->path,
                    APR_FOPEN_WRITE|APR_FOPEN_CREATE|APR_FOPEN_TRUNCATE, APR_UREAD|APR_UWRITE|APR_GREAD|APR_GWRITE|APR_WREAD|APR_WWRITE, logger->pool) != APR_SUCCESS) {
                    logger->fd = NULL;
                }
            }
        }        
        UNLOCK(logger->mymutex);
    }
}

/**
 * in_check_and_rolling_logger_global
 * @return
 */
IN_DECLARE(void) in_check_and_rolling_logger_global(void) {
    in_check_and_rolling_logger(g_logger);
}

/**
 * in_write_log
 * @return
 */
IN_DECLARE(int) in_write_log(t_logger * logger, const int lv, const char * fname, const int line, const char * key, const char *fmt, ...) {
    if(logger && lv <= logger->level) {
        char clogtime[D_STR_TIME_SIZE] = {0,};
        char clogbody[LOGGER_STACK_BUFFER_SIZE] = {0,};
        const int time_length = generate_log_tag_time_string(clogtime, sizeof(clogtime), apr_time_now());
        const int key_length = strlen(key);
        char * ploghdr = clogbody;
        *ploghdr++ = '[';        
        if(key_length > LOG_DISPLAY_KEY_LENGTH) {
            memcpy(ploghdr, key, LOG_DISPLAY_KEY_LENGTH); ploghdr += LOG_DISPLAY_KEY_LENGTH;
        }
        else {
            const int rest_length = LOG_DISPLAY_KEY_LENGTH-key_length;
            memset(ploghdr, ' ', rest_length); ploghdr += rest_length;
            memcpy(ploghdr, key, key_length); ploghdr += key_length;
        }
        *ploghdr++ = ']';
        *ploghdr++ = ' ';
        *ploghdr++ = lv + '0';
        *ploghdr++ = ' ';
        *ploghdr++ = '|';
        *ploghdr++ = ' ';
        memcpy(ploghdr, clogtime, time_length); ploghdr += time_length;
        *ploghdr++ = ' ';
        *ploghdr++ = '|';
        *ploghdr++ = ' ';
#ifdef _DEBUG
        snprintf(ploghdr, 100, "%s:%d | ", fname, line);
        int nloghdr = strlen(clogbody);
#else
        *ploghdr = 0;
        int nloghdr = (int)((apr_uint64_t)ploghdr-(apr_uint64_t)clogbody);
#endif
        va_list args;
        va_start(args, fmt);
        vsnprintf(clogbody+nloghdr, sizeof(clogbody)-nloghdr, fmt, args);
        va_end(args);
        return write_log(logger, lv, fname, line, key, clogbody);
    }
    return IN_FAIL;
}

/**
 * in_write_log_global
 * @return
 */
IN_DECLARE(int) in_write_log_global(const int lv, const char * fname, const int line, const char * key, const char *fmt, ...) {
    if(g_logger && lv <= g_logger->level) {
        char clogtime[D_STR_TIME_SIZE] = {0,};
        char clogbody[LOGGER_STACK_BUFFER_SIZE] = {0,};
        const int time_length = generate_log_tag_time_string(clogtime, sizeof(clogtime), apr_time_now());
        const int key_length = strlen(key);
        char * ploghdr = clogbody;
        *ploghdr++ = '[';        
        if(key_length > LOG_DISPLAY_KEY_LENGTH) {
            memcpy(ploghdr, key, LOG_DISPLAY_KEY_LENGTH); ploghdr += LOG_DISPLAY_KEY_LENGTH;
        }
        else {
            const int rest_length = LOG_DISPLAY_KEY_LENGTH-key_length;
            if(lv == LOG_LV_ERR && memcmp(key, "ERR", 3) != 0) {
                *ploghdr++ = 'E';
                *ploghdr++ = 'R';
                *ploghdr++ = 'R';
                for(int i = 3; i < rest_length; ++i)
                    *ploghdr++ = ' ';
                memcpy(ploghdr, key, key_length); ploghdr += key_length;
            }
            else {
                memset(ploghdr, ' ', rest_length); ploghdr += rest_length;
                memcpy(ploghdr, key, key_length); ploghdr += key_length;
            }
        }
        *ploghdr++ = ']';
        *ploghdr++ = ' ';
        *ploghdr++ = lv + '0';
        *ploghdr++ = ' ';
        *ploghdr++ = '|';
        *ploghdr++ = ' ';
        memcpy(ploghdr, clogtime, time_length); ploghdr += time_length;
        *ploghdr++ = ' ';
        *ploghdr++ = '|';
        *ploghdr++ = ' ';
#ifdef _DEBUG
        snprintf(ploghdr, sizeof(clogbody), "%s:%d | ", fname, line);
        int nloghdr = strlen(clogbody);
#else
        *ploghdr = 0;
        int nloghdr = (int)((apr_uint64_t)ploghdr-(apr_uint64_t)clogbody);
#endif
        va_list args;
        va_start(args, fmt);
        vsnprintf(clogbody+nloghdr, sizeof(clogbody)-nloghdr, fmt, args);
        va_end(args);
        return write_log(g_logger, lv, fname, line, key, clogbody);
    }
    return IN_FAIL;
}

/**
 * in_write_log_global_for_plugin
 * @return
 */
IN_DECLARE(int) in_write_log_global_for_plugin(const int lv, const char * fname, const int line, const char * key, const char *fmt, ...) {
    if(g_logger && lv <= g_logger->level) {
        char clogtime[D_STR_TIME_SIZE] = {0,};
        char clogbody[LOGGER_STACK_BUFFER_SIZE] = {0,};
        const int time_length = generate_log_tag_time_string(clogtime, sizeof(clogtime), apr_time_now());
        const int key_length = strlen(key);
        char * ploghdr = clogbody;
        *ploghdr++ = '[';        
        if(key_length > LOG_DISPLAY_KEY_LENGTH) {
            memcpy(ploghdr, key, LOG_DISPLAY_KEY_LENGTH); ploghdr += LOG_DISPLAY_KEY_LENGTH;
        }
        else {
            const int rest_length = LOG_DISPLAY_KEY_LENGTH-key_length;
            memset(ploghdr, ' ', rest_length); ploghdr += rest_length;
            memcpy(ploghdr, key, key_length); ploghdr += key_length;
        }
        *ploghdr++ = ']';
        *ploghdr++ = ' ';
        *ploghdr++ = lv + '0';
        *ploghdr++ = ' ';
        *ploghdr++ = '|';
        *ploghdr++ = ' ';
        memcpy(ploghdr, clogtime, time_length); ploghdr += time_length;
        *ploghdr++ = ' ';
        *ploghdr++ = '|';
        *ploghdr++ = ' ';
#ifdef _DEBUG
        snprintf(ploghdr, sizeof(clogbody), "%s:%d | ", fname, line);
        int nloghdr = strlen(clogbody);
#else
        *ploghdr = 0;
        int nloghdr = (int)((apr_uint64_t)ploghdr-(apr_uint64_t)clogbody);
#endif
        va_list args;
        va_start(args, fmt);
        vsnprintf(clogbody+nloghdr, sizeof(clogbody)-nloghdr, fmt, args);
        va_end(args);
        return write_log(g_logger, lv, fname, line, key, clogbody);
    }
    return IN_FAIL;
}

/**
 * in_generate_string_with_binary
 * @return
 */
IN_DECLARE(void) in_generate_string_with_binary(char * dst, int dstsize, const char * src, int srcsize) {
    if(dst && src) {
        char line[32] = {0,};
        char temp[64] = {0,};
        dst[0] = 0;
        int i, j, l, r, len, cline = 0, cbegin = 0;
        for(i = 1, l = 0; i <= srcsize; ++i) {
            const char c = (src[i-1]&0xff);
            r = i % 10;
            if(r == 0) { /* end line */
                in_bin_to_2hex_string(temp, c);
                line[cline++] = c;
                temp[2] = ' ';
                temp[3] = '|';
                temp[4] = ' ';
                for(j = 0;j < cline; ++j) {
                    temp[5+j] = (line[j] && apr_isalnum(line[j])) ? line[j] : ' ';
                }                
                temp[5+j] = '\n';
                temp[6+j] = 0;
                len = 6+j;
                cline = 0;
            }
            else if(r == 1) { /* begin line */
                cline = 0;                
                in_utoa_lpadding(temp, 3, l++, ' ');                
                temp[3] = ' ';
                temp[4] = '|';
                temp[5] = ' ';
                in_bin_to_2hex_string(temp+6, c);
                line[cline++] = c;
                temp[8] = ',';
                temp[9] = 0;
                len = 9;
            }
            else {
                in_bin_to_2hex_string(temp, c);
                line[cline++] = c;
                temp[2] = ',';
                temp[3] = 0;
                len = 3;                
            }
            if(cbegin + len > dstsize - 1) {
                break;
            }
            memcpy(dst+cbegin, temp, len);
            cbegin += len;
            dst[cbegin] = 0;
        }
        if(cbegin) {
            dst[--cbegin] = 0;
        }
        if(cline) {
            temp[0] = ' ';
            temp[1] = '|';
            temp[2] = ' ';
            for(j = 0;j < cline; ++j) {
                temp[3+j] = (line[j] && apr_isalnum(line[j])) ? line[j] : ' ';
            }                
            temp[3+j] = 0;
            len = 3+j;
            cline = 0;
            if(cbegin + len < dstsize) {
                memcpy(dst+cbegin, temp, len);
                cbegin += len;
                dst[cbegin] = 0;
            }
        }
    }
}

#ifndef _INBOUND_CLIENT__H_
#define _INBOUND_CLIENT__H_

#include "common.h"
#include "config.h"
#include "clientcontext.h"

typedef struct _t_inbound_cli_ctx t_inbound_cli_ctx;

struct _t_inbound_cli_ctx {
    t_cli_ctx cli;
    char state[2];
    apr_time_t last_heartbeat_time;
};

/**
* on_inbound_cli_attach
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_attach(t_inbound_cli_ctx * icli);

/**
* on_inbound_cli_detach
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_detach(t_inbound_cli_ctx * icli);

/**
* on_inbound_cli_idle
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_idle(t_inbound_cli_ctx * icli, apr_time_t elasped_time);

/**
* on_inbound_cli_recv
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_recv(t_inbound_cli_ctx * icli, apr_socket_t * csock);

/**
* on_inbound_cli_send
*/
IN_DECLARE(apr_int32_t) on_inbound_cli_send(t_inbound_cli_ctx * icli, const char * buf, apr_size_t size);

/**
* inbound_send
*/
IN_DECLARE(int) inbound_send(t_inbound_cli_ctx * icli, const char * tid, const char * IN buf, apr_size_t IN size);

/**
* inbound_send_sig
*/
IN_DECLARE(int) inbound_send_sig(apr_uint16_t sid, const char * tid, const char * IN buf, apr_size_t IN size);

#endif /* _INBOUND_CLIENT__H_ */

#ifndef _OAM__H_
#define _OAM__H_

#include "common.h"
#include "config.h"

typedef struct _t_oam_info t_oam_info;

struct _t_oam_info {
    apr_socket_t * oam_sock;
    apr_sockaddr_t * oam_sock_to;
    apr_thread_mutex_t * oam_mutex;
    apr_time_t conf_file_modification_time;
};

int oam_init_info(t_oam_info * IN OUT oam, apr_pool_t * IN pool);
void oam_clean_info(t_oam_info * IN OUT oam);
int oam_load_info_file(char * IN proc_name, t_oam_info * IN OUT oam, apr_pool_t * IN pool, bool reload);
int oam_send_info(const t_oam_info * IN OUT oam, const char * fmt, ...);
void oam_update_isession_state(const t_oam_info * oam, const apr_uint16_t sid, const char * ipaddr, bool onoff);
void oam_update_osession_state(const t_oam_info * oam, const apr_uint16_t sid, const char * ipaddr, bool onoff);
bool oam_certify_session(const t_oam_info * oam, const apr_uint16_t sid, const char * ipaddr);
void alarm_unauthorised_session(const t_oam_info * oam, const apr_uint16_t sid, const char * ipaddr);
void alarm_request_overloaded(const t_oam_info * oam, const apr_uint16_t sid, const int curr_tps);
void alarm_invalid_request(const t_oam_info * oam, const apr_uint16_t sid);
void alarm_request_timeout(const t_oam_info * oam, const apr_uint16_t sid, const char * tid, const char * desc);
void alarm_socket_error(const t_oam_info * oam, const apr_uint16_t sid);

#endif /* _OAM__H_ */

#ifndef _INSUP1__H_
#define _INSUP1__H_

#include "common.h"

#ifdef __cplusplus
     extern "C" {
#endif

     t_plugin_handle * insup1_get_handle(void);

#ifdef __cplusplus
     }
#endif

#endif /* _INSUP1__H_ */

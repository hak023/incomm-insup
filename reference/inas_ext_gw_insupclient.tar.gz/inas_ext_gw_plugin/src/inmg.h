#ifndef _INMG__H_
#define _INMG__H_

#include "common.h"

#ifdef __cplusplus
     extern "C" {
#endif

     t_plugin_handle * inmg_get_handle(void);

#ifdef __cplusplus
     }
#endif

#endif /* _INMG__H_ */

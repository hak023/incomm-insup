#ifndef _INGW__H_
#define _INGW__H_

#include "common.h"

#ifdef __cplusplus
     extern "C" {
#endif

     t_plugin_handle * ingw_get_handle(void);

#ifdef __cplusplus
     }
#endif

#endif /* _INGW__H_ */

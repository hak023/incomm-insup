#ifndef _INSUP2__H_
#define _INSUP2__H_

#include "common.h"

#ifdef __cplusplus
     extern "C" {
#endif

    t_plugin_handle * insup2_get_handle(void);


#ifdef __cplusplus
     }
#endif

#endif /* _INSUP2__H_ */
